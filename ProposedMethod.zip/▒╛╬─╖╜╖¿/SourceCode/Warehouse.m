classdef Warehouse<handle
    %WAREHOUSE �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    % ע��ǰ��̨��λת����ǰ̨m����̨grid����
    %������ʾ��Ϣȫ���ڱ����д�ӡ
    properties
        
        %��̬���ԣ���ʼ��֮��Ͳ���仯��
        Accelerate
        PlotInterval
        Map
        
        TotalRobotNumber
        TotalWorkerNumber
        TotalTaskNumber
                
        h   %��ʾ����handle
        g   %��ʾ����handle
        m   %��ʾ����handle
        p   %��ʾ����handle
        q   %��ʾ����handle
        %��̬�������ԡ�        
        SystemOn  %ϵͳ��ʼ��Ϣ����GUI��ʼ������ֵ        
        WorkerArrayTimer  %��ʱ����ÿ0.5�����һ�ι��˵�λ����Ϣ
                
        RobotArray = Robot; %Robot - ������˶����������������ΪN��������
        WorkerArray = Worker; %Worker -���˶���������������ΪM��������
        TaskArray ;  %Task -�������������������2000��4*4������
          
        AllStatus   %��̬ά�������˵�״̬��Ϣ��N*1������������͹��˶�ȡ��       
        AllLocation  %��̬ά�������˵�λ����Ϣ��N*2�����˶�ȡ��        
        AllWorkerLocation %��̬ά�����˵�λ����Ϣ��M*2������ʾ��  
        AllNowRobotLocation %��̬ά������������λ�ã�����Robot�࣬��������
        ArrayNumber  %��̬ά��ÿ��С����Ļ����������������жϻص�����ʱĿ�������ѡ��
        Allworkingrobot  %�洢���ڹ����Ļ�����
        AllRobotTaskD  %�洢ÿ�����������һ���������ߵľ���
        EveryRobotCompletedT  %�洢ÿ��������������������
        LastTLocation %�洢��һ��ʱ�䲽���л����˵�λ�ã�������
        NowLocation %�洢��ǰʱ�䲽���л����˵�λ�ã�������
        
        AllPickedRobotSerial  %��̬ά��������ͣ��վ������Ʒ���úõ���Ϣ��N*1��Ĭ��Ϊ0����Ϊ1�ı�ʾ���Ѿ��źá�������ֵΪ��������š�������һ��ѭ�����û����˵�Picked״̬
        AllTaskCompleted %��̬ά�������˵�����������Ϣ��N*1��1��������ʾ��Ӧ�Ļ����ˣ�������ֵ��ʾ��ɵ���������������ֵΪ��������š�   
        AllWorkerOdom1 %���������ߵľ���
        AllWorkerOdom2
        AllRobotOdom
        TaskCounter
        
        TimeCounter
        TaskIndex %��¼��ǰ�����б�
        StatusList
        
        %��¼��ͼ�еĳ���ڣ���λ�ڵ���Ϣ
        MapNode                %��ͼ�нڵ�����ƣ���������
        MapSignalNode          %��¼��ͼ�и���ڵ㣨0-ȡ���㣬1-�Ż��㣬2-��·��ʻ�㣬3-�ϰ���/��Ե��
        AllNodeNum             %���нڵ����Ŀ
        PickupDepotNodeNum     %ȡ����ͷŻ���Ľڵ���֮�ͣ�Ϊ�ڽӾ�������
        PickUpNodeNum          %ȡ����Ľڵ���Ŀ
        DepotNodeNum           %�Ż���Ľڵ���Ŀ
        
        PickUpDepotNode        %���е�ȡ����ͷŻ���
        PickUpNode             %���е�ȡ����
        DepotNode              %���еķŻ���
        
        NodeCoordinate         %��¼���е������
        AllPickUpNode          %��¼����ȡ�������Ϣ
        AllDepotNode           %��¼���зŻ������Ϣ
        
        AllCrissOverNode       %��¼����ʮ��·�ڽڵ㣨���ڼ���K���·����   
        AllCrissOverNodeNum    %��¼����ʮ��·�ڽڵ�����
        
        NodePairEdge           %���-��,��һ�����󣬵�һ��Ϊ�ڵ�1���ڶ���Ϊ�ڵ�2��������Ϊ�ߵı��
        NodeAdjacent           %ÿ������ھӵ�
        AdjacentMatrix         %�ڽӾ���
        AdjacentMatrixNode     %�ڽӾ���ڵ�
        AdjacentMatrixNodeNum  %�ڽӾ���ڵ�
        
        DepotNearCrossNode     %���ܵ㸽���Ľ���ڵ�       
        
        K                      %K���·����K��ȡֵ
        KShortestPaths         %�������K���·��
        KShortestPathsNodePair %K���·����Ӧ�ĵ��
        
        AllRobotTW             %��¼���л����˵�·��ʱ�䴰
        AllNodeTW              %��¼���нڵ��ʱ�䴰
        
        PlanningRobotNumUp     %����滮����һ�������Թ滮�Ļ���������
        
        TaskAmount             %��������
        TaskList               %�����б�
        TaskRobot              %��¼�ӵ������Ӧ�Ļ�����
        LeftTaskList           %��¼ʣ��δ�·�������
        FinishedTaskNum        %��¼�ܹ���ɵ���������
        
        PickUpNodeOccupancy    %��̬��¼ȡ�����Ȩ��ռ��
        DepotNodeOccupancy     %��̬��¼�Ż����Ȩ��ռ��
        
        CandidateFailureNode   %���Է���������ʧЧ�Ľڵ�
        Failure                %��¼ϵͳ���Ƿ���ڻ�����ʧЧ��1-���ڣ�0-������
        FailureNumUp           %ϵͳ�������ּ��λ�����ʧЧ
        FailureRobotNum        %ʧЧ�����˵ı��
        FailureTime            %ʧЧʱ��
        FailureLength          %ʧЧʱ�䳤��
        
        
        RobotNumber1
        RobotNumber2
        RobotNumber3
        RobotNumber4
        RobotNumber5
        RobotNumber6
        CurrentT
        move1
        move2
        move3
        move4
        move5
        move6
        delay
        delayNum
        
        AllRow                 %��ͼ����
        AllColumn              %��ͼ����
        
        LocalPathNumUp         %�ֲ��켣����ʱ���������·������
        beforeFailureNodeNum   %�ֲ��켣����ʱ��ʧЧ��֮ǰ�ƶ��ٸ���(����ڽڵ�)
        afterFailureNodeNum    %�ֲ��켣����ʱ��ʧЧ��֮���ƶ��ٸ���(����ڽڵ�)
    end
    
    methods
        %�����ֿ���ĳ�ʼ��������������λ�á�״̬��ʼ�����Լ�һЩ��־λ�ĳ�ʼ��
        function obj = Warehouse()
            load('14Pick288Depot.mat');
            %load('26Pick1152Depot.mat');
            obj.Map = map;
            
            obj.TotalRobotNumber = 30;
            obj.TaskAmount = 600;
            obj.K = 5;
            obj.FailureNumUp = 10;
            obj.FailureLength = 6;
            
            
            
            
            obj.AllRow = 21;
            obj.AllColumn = 31;
            
            %obj.AllRow = 39;
            %obj.AllColumn = 59;
            
            

            obj.PickUpNodeNum = 14;
            obj.DepotNodeNum = 288;
            
            %obj.PickUpNodeNum = 26;
            %obj.DepotNodeNum = 1152;
            
            
            
            
            obj.PlanningRobotNumUp = 1;
            obj.TaskIndex = 1; 
            obj.FinishedTaskNum = 0;
            obj.Failure = 0;
            obj.FailureRobotNum = 0;
            obj.FailureTime = inf;

            if obj.TotalRobotNumber < 10
                obj.delayNum = 0;
            else
                obj.delayNum = floor(0.1*obj.TotalRobotNumber) - 1;
            end
            
            obj.move1 = 0;
            obj.move2 = 0;
            obj.move3 = 0;
            obj.move4 = 0;
            obj.move5 = 0;
            obj.move6 = 0;
            obj.delay = 0;            
            
            
            obj.LocalPathNumUp = 8;
            obj.beforeFailureNodeNum = 4;
            obj.afterFailureNodeNum = 3;
            
            obj.ReadMap(); %����ͼ����ʼ��
%             [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, 274, 274, 281, 248, 5, 5);            
%             [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, 444, 22, 29, 57, 5, 5);
            
            obj.AllRobotTW = [];
            obj.AllNodeTW = [];
            for i = 1:obj.TotalRobotNumber
                obj.AllRobotTW{i,1} = [];
            end
            for i = 1:obj.AllNodeNum
                obj.AllNodeTW{i,1} = [];
            end
            
            obj.initializeRobot();
            obj.initializeTask();
%             obj.taskAllocator();
            
            %%%%%%%%%%%���߹滮���е�·��%%%%%%%%%%����������ʱ�ã�
%             obj.KShortestPathPlanning();
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            obj.Accelerate = 1;
            
%             obj.TotalWorkerNumber = 40;
            obj.TotalTaskNumber = 30000;
            
            %GUI��������
            obj.SystemOn = true;
            
            obj.PlotInterval = 0.5*obj.Accelerate;  
            obj.WorkerArrayTimer = false;
                       
            obj.AllStatus = zeros(obj.TotalRobotNumber,1);
            obj.AllLocation = zeros(obj.TotalRobotNumber,2);
            obj.AllWorkerLocation = repmat([1.25,26.25],obj.TotalRobotNumber,1);
            obj.AllNowRobotLocation = zeros(47,47);           
     
            obj.AllPickedRobotSerial = zeros(obj.TotalRobotNumber,1);
            obj.AllTaskCompleted = zeros(obj.TotalRobotNumber,1);
            obj.AllWorkerOdom1 = 0;
            obj.AllWorkerOdom2 = 0;
            obj.AllRobotOdom = 0;
            obj.TimeCounter = 1;
            obj.TaskCounter = 0;
            obj.StatusList = zeros(43200,40);
            obj.Allworkingrobot = zeros(12,1);
            obj.AllRobotTaskD = zeros(300,10000);
            obj.EveryRobotCompletedT = zeros(300,1);
           
%             obj.initializeWorker();                    
        end  
        
        %��ȡ��ͼ�е���Ϣ
        function ReadMap(obj)
            MapMatrix = xlsread('10Pick288Depot.xlsx');
            %MapMatrix = xlsread('22Pick1152Depot.xlsx');
            
            obj.MapSignalNode = MapMatrix;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%�ڵ���Ϣ��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.AllNodeNum = 0;
            obj.PickUpNode = zeros(obj.PickUpNodeNum,1); %������е�ȡ����
            obj.DepotNode = zeros(obj.DepotNodeNum,1); %������еķŻ���
            obj.NodeCoordinate = [];
            obj.PickUpDepotNode = [];
            obj.AdjacentMatrixNode = [];
            obj.DepotNearCrossNode = [];
            obj.PickUpNodeOccupancy = [];
            obj.DepotNodeOccupancy = [];
            obj.AdjacentMatrixNodeNum = 0;
            obj.MapNode = zeros(size(MapMatrix,1),size(MapMatrix,2)); %��ͼ�нڵ�����ƣ���������
            filename = '10Pick288depotMapNode.xlsx';
            %filename = '22Pick1152depotMapNode.xlsx';
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%���ڵ���/��������/ʶ��ȡ���㡢�Ż���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(MapMatrix,1)
                for j = 1:size(MapMatrix,2)
                    if MapMatrix(i,j) ~= 3
                        obj.AllNodeNum = obj.AllNodeNum + 1;
                        obj.MapNode(i,j) = obj.AllNodeNum; %�ڵ���
                        %%%%%%%%%%%%%%%%%%��ʼ���ڵ�λ��%%%%%%%%%%%%%%%%%%
                        rows = size(obj.NodeCoordinate,1);
                        obj.NodeCoordinate(rows+1,1) = obj.MapNode(i,j);
                        obj.NodeCoordinate(rows+1,2) = i;
                        obj.NodeCoordinate(rows+1,3) = j;
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if MapMatrix(i,j) == 0 %����ڵ���ȡ����
                            obj.PickUpNodeNum = obj.PickUpNodeNum + 1;
                            ZeroElement = find(obj.PickUpNode == 0);
                            FirstZero = ZeroElement(1);
                            obj.PickUpNode(FirstZero,1) = obj.MapNode(i,j);
                            row = size(obj.PickUpNodeOccupancy,1);
                            obj.PickUpNodeOccupancy(row+1,1) = obj.MapNode(i,j);
                            obj.PickUpNodeOccupancy(row+1,2) = 0; %�Ƿ�ռ��
                            obj.PickUpNodeOccupancy(row+1,3) = 0; %ռ�øýڵ�����˵ı��
                        elseif MapMatrix(i,j) == 1 %����ڵ��ǷŻ���
                            obj.DepotNodeNum = obj.DepotNodeNum + 1;
                            ZeroElement = find(obj.DepotNode == 0);
                            FirstZero = ZeroElement(1);
                            obj.DepotNode(FirstZero,1) = obj.MapNode(i,j);
                            row = size(obj.DepotNodeOccupancy,1);
                            obj.DepotNodeOccupancy(row+1,1) = obj.MapNode(i,j);
                            obj.DepotNodeOccupancy(row+1,2) = 0; %�Ƿ�ռ��
                            obj.DepotNodeOccupancy(row+1,3) = 0; %ռ�øýڵ�����˵ı��
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            xlswrite(filename,obj.MapNode); %�����ŵ�ͼ���ɵĽڵ�����д��excel��
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%��¼���ܵ㸽���Ľ���ڽڵ�%%%%%%%%%%%%%%%%%%%%%%%%%%
            for  i = 1:size(MapMatrix,1)
                for  j = 1:size(MapMatrix,2)
                    if MapMatrix(i,j) == 1 %����
                        if MapMatrix(i-1,j) == 1 %������һ��
                            crossNode1 = obj.MapNode(i+1,j-mod(j-2,7));
                            crossNode2 = obj.MapNode(i+1,j-mod(j-2,7)+7);
                            row = size(obj.DepotNearCrossNode,1);
                            obj.DepotNearCrossNode(row+1,1) = obj.MapNode(i,j);
                            obj.DepotNearCrossNode(row+1,2) = crossNode1;
                            obj.DepotNearCrossNode(row+1,3) = crossNode2;
                        else %������һ��
                            crossNode1 = obj.MapNode(i-1,j-mod(j-2,7));
                            crossNode2 = obj.MapNode(i-1,j-mod(j-2,7)+7);
                            row = size(obj.DepotNearCrossNode,1);
                            obj.DepotNearCrossNode(row+1,1) = obj.MapNode(i,j);
                            obj.DepotNearCrossNode(row+1,2) = crossNode1;
                            obj.DepotNearCrossNode(row+1,3) = crossNode2;
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����ڽӾ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%�ҳ������ڽӾ����еĵ�%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(MapMatrix,1)
                for j = 1:size(MapMatrix,2)
                    if MapMatrix(i,j) == 0 || MapMatrix(i,j) == 4
                        obj.AdjacentMatrixNodeNum = obj.AdjacentMatrixNodeNum + 1;
                        obj.AdjacentMatrixNode(size(obj.AdjacentMatrixNode,1)+1,1) = obj.MapNode(i,j);
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.AdjacentMatrix = 1./zeros(obj.AdjacentMatrixNodeNum);
            column2 = obj.AdjacentMatrixNode(:,1);
            for i = 1:size(MapMatrix,1)
                for j = 1:size(MapMatrix,2)
                    node = obj.MapNode(i,j);
                    index = find(column2 == node); %�ҵ���ǰ��������Ӧ��obj.AdjacentMatrixNode�еı�ţ���1��ʼ��
                    if MapMatrix(i,j) == 0
                        if j == 1
                            adjacentNode = obj.MapNode(i,j+1);
                            index2 = find(column2 == adjacentNode);
                            obj.AdjacentMatrix(index,index2) = 1;
                        else
                            adjacentNode = obj.MapNode(i,j-1);
                            index2 = find(column2 == adjacentNode);
                            obj.AdjacentMatrix(index,index2) = 1;
                        end
                    elseif MapMatrix(i,j) == 4
                        if MapMatrix(i-1,j) ~= 3
                            if (i-2) > 0 %����������һ�е�4
                                adjacentNode = obj.MapNode(i-3,j);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 3;
                            end
                        end
                        if MapMatrix(i+1,j) ~= 3
                            %if (i+2) < 22 %����������һ�е�4
                            if (i+2) < (obj.AllRow + 1)    
                                adjacentNode = obj.MapNode(i+3,j);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 3;
                            end 
                        end
                        if MapMatrix(i,j-1) ~= 3
                            if j == 2 %�������һ�е�4
                                adjacentNode = obj.MapNode(i,j-1);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 1;                              
                            else
                                adjacentNode = obj.MapNode(i,j-7);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 7;                                
                            end
                        end
                        if MapMatrix(i,j+1) ~= 3
                            %if j == 30
                            if j == (obj.AllColumn - 1) %�����ұ�һ�е�4
                                adjacentNode = obj.MapNode(i,j+1);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 1;                                
                            else
                                adjacentNode = obj.MapNode(i,j+7);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 7;                                
                            end                            
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��¼���п��Է���������ʧЧ�Ľڵ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.CandidateFailureNode = [];
            for i = 1:size(obj.MapNode,1)
                for j = 1:size(obj.MapNode,2)
                    if obj.MapSignalNode(i,j) ~= 0 && obj.MapSignalNode(i,j) ~= 1 && obj.MapSignalNode(i,j) ~= 3 %ֻ���ǵ�·��
                        node = obj.MapNode(i,j);
                        atAdjacentMatrixNode = find(obj.AdjacentMatrixNode(:,1) == node);
                        if isempty(atAdjacentMatrixNode) %�����ڽӾ���ڵ�
                            if (mod(i-1,3) ~= 0 || mod(i-1,3) ~= 2) && (i ~= 2) && (i ~= 20) %��������ͨ���еĽڵ�
                                if mod(j-1,7) == 4 || mod(j-1,7) == 5
                                    row = size(obj.CandidateFailureNode,1);
                                    obj.CandidateFailureNode(row+1,1) = node;                                    
                                end
                            end
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        
        %����K���·��
        function KShortestPathPlanning(obj)
            obj.KShortestPaths = [];
            obj.KShortestPathsNodePair = [];
            for i = 1:size(obj.PickUpNode,1)
                for j = 1:size(obj.DepotNode,1)
                    column = obj.DepotNearCrossNode(:,1);
                    index = find(column == obj.DepotNode(j,1));
                    crossNode1 = obj.DepotNearCrossNode(index,2);
                    crossNode2 = obj.DepotNearCrossNode(index,3);
                    [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, obj.PickUpNode(i,1), crossNode1, crossNode2, obj.DepotNode(j,1), 5, 5);
                    row = size(obj.KShortestPaths,1);
                    obj.KShortestPaths{row+1,1} = obj.PickUpNode(i,1);
                    obj.KShortestPaths{row+1,2} = obj.DepotNode(j,1);
                    obj.KShortestPaths{row+1,3} = shortestPaths;
                    obj.KShortestPathsNodePair(row+1,1) = obj.PickUpNode(i,1);
                    obj.KShortestPathsNodePair(row+1,2) = obj.DepotNode(j,1);
                    %%%%%%%%%%%%%%%%%%������%%%%%%%%%%%%%%%%%%
                    disp(obj.PickUpNode(i,1));
                    disp('��');
                    disp(obj.DepotNode(j,1));
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                end
            end
        end

        %�����˳�ʼ���������û��������кš���ʼλ���ڻ������������ʼ��
        function initializeRobot(obj)
            obj.RobotArray(obj.TotalRobotNumber,1) = Robot;
            for i = 1:obj.TotalRobotNumber
                obj.RobotArray(i,1) = Robot;
                for j = 1:10000
                    startIndex = unidrnd(size(obj.DepotNode,1));
                    robotNode = obj.DepotNode(startIndex,1); %�ڷŻ���������ɻ����˵ĳ�ʼλ��
                    column = obj.DepotNodeOccupancy(:,1);
                    index = find(column == robotNode);
                    if obj.DepotNodeOccupancy(index,2) == 0 %û�б�Ļ�����ռ��
                        obj.DepotNodeOccupancy(index,2) = 1;
                        obj.DepotNodeOccupancy(index,3) = i;
                        break;
                    end
                end
                robotNodeR = obj.NodeCoordinate(robotNode,2);
                robotNodeC = obj.NodeCoordinate(robotNode,3);
                obj.RobotArray(i,1).setAttribute(i,robotNodeR,robotNodeC,robotNode);
            end            
        end
        
        %�����б���ʼ��
        function initializeTask(obj)
            obj.TaskList = [];
            depotNodeCopy = obj.DepotNode;
            for i = 1:obj.TaskAmount
                startIndex = unidrnd(size(obj.PickUpNode,1));
                start = obj.PickUpNode(startIndex,1);
                %%%%%%%%%%%%%��֤�����յ㲻�ظ�%%%%%%%%%%
                finalIndex = unidrnd(size(depotNodeCopy,1));
                final = depotNodeCopy(finalIndex,1);
                depotNodeCopy(finalIndex,:) = []; 
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                row = size(obj.TaskList,1);
                obj.TaskList(row+1,1) = start;
                obj.TaskList(row+1,2) = final;
            end
            obj.LeftTaskList = obj.TaskList;
        end
                
        %���˳�ʼ���������ù������кš���������Ѳ��������ʼλ���ڹ��������ʼ��
        function initializeWorker(obj)
            obj.WorkerArray(obj.TotalWorkerNumber,1) = Worker;
            for i = 1:obj.TotalWorkerNumber
                obj.WorkerArray(i,1) = Worker;
                obj.WorkerArray(i,1).setAttribute(i);
            end
        end
        
        %ȫ��������λ���趨����������Ϊ�������꣬�����ڲ�ת��Ϊդ�����ꡣ�������ã����в���Ҫ������
        function setAllRobotLocation(obj,allLocation)
            allLocation = world2grid(obj.Map,allLocation);
            for i = 1:obj.TotalRobotNumber
                obj.RobotArray(i,1).setLocation(allLocation(i,:));
            end   
        end
        
        %ȫ��������λ�ö�ȡ������������Ϊ�������꣬�ڲ���դ������ת��������
        function allLocation = getAllRobotLocation(obj)
            allLocation = zeros(obj.TotalRobotNumber,2);
            for i = 1:obj.TotalRobotNumber
                allLocation(i,:) = obj.RobotArray(i,1).getLocation();
            end
            %disp(allLocation);
            allLocation = grid2world(obj.Map,allLocation);
        end
        
        %ȫ��������gridλ�ö�ȡ������������Ϊgrid���꣬�������˴������е�λ����Ϣ��
        function allLocation = getAllRobotGridLocation(obj)
            allLocation = zeros(obj.TotalRobotNumber,2);
            for i = 1:obj.TotalRobotNumber
                allLocation(i,:) = obj.RobotArray(i,1).getLocation();
            end
        end
                
        %ȫ������λ���趨����������Ϊ�������꣬�ڲ�ת��Ϊդ�����ꡣ�������ã����в�����Ҫ������
        function setAllWorkerLocation(obj,allLocation)        
            allLocation = world2grid(obj.Map,allLocation);
            for i = 1:obj.TotalWorkerNumber
                obj.WorkerArray(i,1).setLocation(allLocation(i,:));
            end   
        end
        
        %ȫ������λ�ö�ȡ������������Ϊ�������꣬�ڲ���դ������ת��������
        function allLocation = getAllWorkerLocation(obj)  
            allLocation = zeros(obj.TotalWorkerNumber,2);
            for i = 1:obj.TotalWorkerNumber
                allLocation(i,:) = obj.WorkerArray(i,1).getLocation();
            end
            allLocation = grid2world(obj.Map,allLocation);             
        end
 
        %�����������ѯ�����˵�״̬�������������״̬��ϢΪ0������������������
        function taskAllocator(obj)
%             disp('taskAllocator');
            if obj.TaskIndex < obj.TaskAmount || obj.TaskIndex == obj.TaskAmount %�������л���δ�·�������
                freeRobot = [];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��¼���л�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                for i = 1:obj.TotalRobotNumber
                    if i ~= obj.FailureRobotNum
                        if obj.RobotArray(i,1).getStatus() == 0
                            row = size(freeRobot,1);
                            freeRobot(row+1,1) = obj.RobotArray(i,1).getNumber();
                        end
                    end
                end
%                 disp('���л�����');
%                 disp(freeRobot);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if size(freeRobot,1) ~= 0 %���ڿ��л�����
                    for j = 1:size(freeRobot,1)
%                         try
%                             endNode = obj.TaskList(obj.TaskIndex,2);
%                         catch
%                             disp('obj.TaskIndex');
%                             disp(obj.TaskIndex);
%                         end
                        endNode = obj.TaskList(obj.TaskIndex,2);
                        %%%%%%%%%%%%%%�ж����п��л����˵ĵ�ǰλ�ýڵ����Ƿ��е��������յ��%%%%%%%%%%%%%
                        for l = 1:size(freeRobot,1)
                            a = [];
                            robotNumber = freeRobot(l,1);
                            robotNode = obj.RobotArray(robotNumber,1).getNode();
                            if endNode == robotNode
                                obj.RobotArray(robotNumber,1).setStatus(1);
                                obj.RobotArray(robotNumber,1).setGoal(obj.TaskList(obj.TaskIndex,1),obj.TaskList(obj.TaskIndex,2));
                                obj.RobotArray(robotNumber,1).setPlanned(0);
                                obj.TaskRobot(obj.TaskIndex,1) = robotNumber;
                                freeRobot(find(freeRobot == robotNumber),:) = [];
                                obj.TaskIndex = obj.TaskIndex + 1; 
                                a(1,1) = robotNumber;
                                column1 = obj.PickUpNodeOccupancy(:,1);
                                column2 = obj.DepotNodeOccupancy(:,1);
                                index1 = find(column1 == obj.RobotArray(robotNumber,1).taskStartNode);
                                index2 = find(column2 == obj.RobotArray(robotNumber,1).taskEndNode);
                                if obj.PickUpNodeOccupancy(index1,2) == 0
                                    obj.PickUpNodeOccupancy(index1,2) = 1;
                                    obj.PickUpNodeOccupancy(index1,3) = robotNumber;                                    
                                end
                                if obj.DepotNodeOccupancy(index2,2) == 0
                                    obj.DepotNodeOccupancy(index2,2) = 1;
                                    obj.DepotNodeOccupancy(index2,3) = robotNumber;                                    
                                end
%                                 obj.PickUpNodeOccupancy(index1,2) = 1;
%                                 obj.PickUpNodeOccupancy(index1,3) = robotNumber;
%                                 obj.DepotNodeOccupancy(index1,2) = 1;
%                                 obj.DepotNodeOccupancy(index1,3) = robotNumber;
                                break;
                            end
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���п��л��������ڵ�λ�ö����ǵ�ǰ������յ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if isempty(a)
                            startNode = obj.TaskList(obj.TaskIndex,1);
                            distance = inf;
                            robotNumber = 0;
                            %%%%%%%%%%%%%%%%%%%%%%%�Ե�ǰ����Ѱ��freeRobot�о���������������%%%%%%%%%%%%%%%%%%%%%
                            for i = 1:size(freeRobot,1)
                                number = freeRobot(i,1);
                                robotNode = obj.RobotArray(number,1).getNode();
                                row = obj.NodeCoordinate(robotNode,2);
                                column = obj.NodeCoordinate(robotNode,3);
                                %%%%%%%%%%%%%%%%%%%������ܵ�֮ǰ��һ����%%%%%%%%%%%%%%%%%%
                                if obj.MapSignalNode(row-1,column) == 1 %������һ�еĵ�
                                    destinationNode = obj.MapNode(row+1,column);
                                else %������һ�еĵ�
                                    destinationNode = obj.MapNode(row-1,column);
                                end
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                d = abs(obj.NodeCoordinate(startNode,2) - obj.NodeCoordinate(destinationNode,2)) + abs(obj.NodeCoordinate(startNode,3) - obj.NodeCoordinate(destinationNode,3));
                                if d < distance
                                    distance = d;
                                    robotNumber = number;
                                end
                            end 
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            obj.RobotArray(robotNumber,1).setStatus(1);
                            obj.RobotArray(robotNumber,1).setGoal(obj.TaskList(obj.TaskIndex,1),obj.TaskList(obj.TaskIndex,2));
                            obj.RobotArray(robotNumber,1).setPlanned(0);
                            obj.TaskRobot(obj.TaskIndex,1) = robotNumber;
                            freeRobot(find(freeRobot == robotNumber),:) = [];
                            obj.TaskIndex = obj.TaskIndex + 1;   
                            column1 = obj.PickUpNodeOccupancy(:,1);
                            column2 = obj.DepotNodeOccupancy(:,1);
                            index1 = find(column1 == obj.RobotArray(robotNumber,1).taskStartNode);
                            index2 = find(column2 == obj.RobotArray(robotNumber,1).taskEndNode);
                            if obj.PickUpNodeOccupancy(index1,2) == 0
                                obj.PickUpNodeOccupancy(index1,2) = 1;
                                obj.PickUpNodeOccupancy(index1,3) = robotNumber;                                    
                            end
                            if obj.DepotNodeOccupancy(index2,2) == 0
                                obj.DepotNodeOccupancy(index2,2) = 1;
                                obj.DepotNodeOccupancy(index2,3) = robotNumber;                                    
                            end                                                       
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if obj.TaskIndex > obj.TaskAmount %�����Ѿ������꣬���������Ƿ��п��л����ˣ��������������ѭ��
                            break;
                        end
                    end
                end
            end
        end
        
        %���ݹ滮�õ�ʱ�䴰�жϻ������Ƿ��ƶ�,����Ȩ��ռ��
        function updateAllRobot(obj,Time)  
            disp('updateAllRobot');
            if obj.Failure == 0 %ϵͳ����ʧЧ������
                for i = 1:obj.TotalRobotNumber
                    TWSerial = obj.AllRobotTW{i,1};
                    if ~isempty(TWSerial)
                        robotNode = obj.RobotArray(i,1).getNode();
                        TWSerialC1 = TWSerial(:,1);
                        index = find(TWSerialC1 == robotNode);
                        robotNodeEndT = TWSerial(index,3);
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ж��ǲ���TWSerial�����һ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if index == size(TWSerial,1) %��TWSerial�����һ����
                            if Time == robotNodeEndT %�õ�ռ�ý���
                                setUpNode = TWSerial(end,1); %��¼�����˱���TW�滮����ʼ��
                                obj.AllRobotTW{i,1} = []; %ʱ�䴰���
                                if robotNode == obj.RobotArray(i,1).taskStartNode %���ڴ������λ�� 
                                    obj.RobotArray(i,1).setPlanned(0);
                                    column = obj.DepotNodeOccupancy(:,1);
                                    index1 = find(column == obj.RobotArray(i,1).taskEndNode);                                
                                    if obj.DepotNodeOccupancy(index1,2) == 0 || ((obj.DepotNodeOccupancy(index1,2) == 1)&&(obj.DepotNodeOccupancy(index1,3) == i))
                                        startNode = obj.RobotArray(i,1).taskStartNode;
                                        endNode = obj.RobotArray(i,1).taskEndNode;                                
                                        obj.TWPathPlanning(i,(Time+1),startNode,endNode,1);
                                        obj.DepotNodeOccupancy(index1,2) = 1;
                                        obj.DepotNodeOccupancy(index1,3) = i;   
                                        obj.RobotArray(i,1).setPlanned(1);
                                    end                                 
                                elseif robotNode == obj.RobotArray(i,1).taskEndNode %���ڴ����յ�λ��
                                    obj.RobotArray(i,1).setStatus(0);
                                    obj.RobotArray(i,1).setPlanned(0);
                                    obj.FinishedTaskNum = obj.FinishedTaskNum + 1;
                                else %����λ����ʱͣ����
                                    if ~isempty(find(obj.DepotNode == setUpNode)) %����ȥ��ȡ����
                                        obj.TWPathPlanning(i,(Time+1),obj.RobotArray(i,1).taskStartNode,robotNode,-1);
                                    else %����ȥ�����ܵ�
                                        if obj.NodeCoordinate(robotNode,3) < obj.NodeCoordinate(obj.RobotArray(i,1).taskEndNode,3)
                                            planStartNode = obj.DepotNearCrossNode(find(obj.DepotNearCrossNode(:,1) == robotNode),3);
                                        else
                                            planStartNode = obj.DepotNearCrossNode(find(obj.DepotNearCrossNode(:,1) == robotNode),2);
                                        end
                                        obj.TWPathPlanning(i,(Time+1),planStartNode,obj.RobotArray(i,1).taskEndNode,1);
                                    end
                                end
                            end
                        else %����TWSerial�����һ����
                            if Time == (robotNodeEndT + 1)
                                %%%%%%%%%%%%%%%%%%%%%%%%��ǰ�㲻�ǹ滮��·�����������һ����,������ǰ��%%%%%%%%%%%%%%%%%%%%%%
                                nextNode = TWSerialC1(index+1,1);
                                location = [];
                                location(1,1) = obj.NodeCoordinate(nextNode,2);
                                location(1,2) = obj.NodeCoordinate(nextNode,3);
                                obj.RobotArray(i,1).setLocation(location);
                                obj.RobotArray(i,1).setNode(nextNode);
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Ȩ�޵��ͷ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                if robotNode == TWSerialC1(1,1) %��TWSerial�е�һ����
                                    if robotNode == obj.RobotArray(i,1).taskStartNode %��Ҫ�뿪�������
                                        occupancyColumn = obj.PickUpNodeOccupancy(:,1);
                                        Index = find(occupancyColumn == robotNode);
                                        obj.PickUpNodeOccupancy(Index,2) = 0;
                                        obj.PickUpNodeOccupancy(Index,3) = 0;                                    
                                    else 
                                        if robotNode ~= obj.RobotArray(i,1).taskEndNode %ֻ�е��������������ڽڵ��������յ㲻һ��ʱ���ſ��ͷŸõ��Ȩ��
                                            occupancyColumn = obj.DepotNodeOccupancy(:,1);
                                            Index = find(occupancyColumn == robotNode);
                                            obj.DepotNodeOccupancy(Index,2) = 0;
                                            obj.DepotNodeOccupancy(Index,3) = 0;
                                        end                                    
                                    end
                                end
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            end                        
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    end
                end 
            else %ϵͳ����ʧЧ������
                for i = 1:obj.TotalRobotNumber
                    if i ~= obj.FailureRobotNum
                        TWSerial = obj.AllRobotTW{i,1};
                        if ~isempty(TWSerial)
                            robotNode = obj.RobotArray(i,1).getNode();
                            TWSerialC1 = TWSerial(:,1);
                            index = find(TWSerialC1 == robotNode);
                            robotNodeEndT = TWSerial(index,3);
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ж��ǲ���TWSerial�����һ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if index == size(TWSerial,1) %��TWSerial�����һ����
                                if Time == robotNodeEndT %�õ�ռ�ý���
                                    setUpNode = TWSerial(end,1); %��¼�����˱���TW�滮����ʼ��
                                    obj.AllRobotTW{i,1} = []; %ʱ�䴰���
                                    if robotNode == obj.RobotArray(i,1).taskStartNode %���ڴ������λ�� 
                                        obj.RobotArray(i,1).setPlanned(0);
                                        column = obj.DepotNodeOccupancy(:,1);
                                        index1 = find(column == obj.RobotArray(i,1).taskEndNode);                                
                                        if obj.DepotNodeOccupancy(index1,2) == 0 || ((obj.DepotNodeOccupancy(index1,2) == 1)&&(obj.DepotNodeOccupancy(index1,3) == i))
                                            startNode = obj.RobotArray(i,1).taskStartNode;
                                            endNode = obj.RobotArray(i,1).taskEndNode;                                
                                            obj.TWPathPlanning(i,(Time+1),startNode,endNode,1);
                                            obj.DepotNodeOccupancy(index1,2) = 1;
                                            obj.DepotNodeOccupancy(index1,3) = i;   
                                            obj.RobotArray(i,1).setPlanned(1);
                                        end                                 
                                    elseif robotNode == obj.RobotArray(i,1).taskEndNode %���ڴ����յ�λ��
                                        obj.RobotArray(i,1).setStatus(0);
                                        obj.RobotArray(i,1).setPlanned(0);
                                        obj.FinishedTaskNum = obj.FinishedTaskNum + 1;
                                    else %����λ����ʱͣ����
                                        if ~isempty(find(obj.DepotNode == setUpNode)) %����ȥ��ȡ����
                                            obj.TWPathPlanning(i,(Time+1),obj.RobotArray(i,1).taskStartNode,robotNode,-1);
                                        else %����ȥ�����ܵ�
                                            if obj.NodeCoordinate(robotNode,3) < obj.NodeCoordinate(obj.RobotArray(i,1).taskEndNode,3)
                                                planStartNode = obj.DepotNearCrossNode(find(obj.DepotNearCrossNode(:,1) == robotNode),3);
                                            else
                                                planStartNode = obj.DepotNearCrossNode(find(obj.DepotNearCrossNode(:,1) == robotNode),2);
                                            end
                                            obj.TWPathPlanning(i,(Time+1),planStartNode,obj.RobotArray(i,1).taskEndNode,1);
                                        end
                                    end
                                end
                            else %����TWSerial�����һ����
                                if Time == (robotNodeEndT + 1)
                                    %%%%%%%%%%%%%%%%%%%%%%%%��ǰ�㲻�ǹ滮��·�����������һ����,������ǰ��%%%%%%%%%%%%%%%%%%%%%%
                                    nextNode = TWSerialC1(index+1,1);
                                    location = [];
                                    location(1,1) = obj.NodeCoordinate(nextNode,2);
                                    location(1,2) = obj.NodeCoordinate(nextNode,3);
                                    obj.RobotArray(i,1).setLocation(location);
                                    obj.RobotArray(i,1).setNode(nextNode);
                                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Ȩ�޵��ͷ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    if robotNode == TWSerialC1(1,1) %��TWSerial�е�һ����
                                        if robotNode == obj.RobotArray(i,1).taskStartNode %��Ҫ�뿪�������
                                            occupancyColumn = obj.PickUpNodeOccupancy(:,1);
                                            Index = find(occupancyColumn == robotNode);
                                            obj.PickUpNodeOccupancy(Index,2) = 0;
                                            obj.PickUpNodeOccupancy(Index,3) = 0;                                    
                                        else 
                                            if robotNode ~= obj.RobotArray(i,1).taskEndNode %ֻ�е��������������ڽڵ��������յ㲻һ��ʱ���ſ��ͷŸõ��Ȩ��
                                                occupancyColumn = obj.DepotNodeOccupancy(:,1);
                                                Index = find(occupancyColumn == robotNode);
                                                obj.DepotNodeOccupancy(Index,2) = 0;
                                                obj.DepotNodeOccupancy(Index,3) = 0;
                                            end                                    
                                        end
                                    end
                                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                end                        
                            end
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        end
                    end
                end
            end
        end
        
        %��������Ҫ���й켣�滮�Ļ����˽��й滮
        function allRobotPlanning(obj,Time)
%             disp('allRobotPlanning');
            plannedRobotNum = 0;
            for i = 1:obj.TotalRobotNumber
                if i ~= obj.FailureRobotNum
                    if plannedRobotNum < obj.PlanningRobotNumUp %�ж��Ƿ񵽴�滮����
                        if obj.RobotArray(i,1).getPlanned() == 0 && obj.RobotArray(i,1).getStatus() == 1 %�������������һ�δ�滮
                            robotNode = obj.RobotArray(i,1).getNode();
                            startNode = obj.RobotArray(i,1).taskStartNode;
                            endNode = obj.RobotArray(i,1).taskEndNode;
                            a = find(obj.DepotNodeOccupancy(:,1) == robotNode); %�жϻ����˵�ǰλ���Ƿ��ǷŻ���
                            if robotNode == startNode %�����˵�ǰλ���������
                                column = obj.DepotNodeOccupancy(:,1);
                                index = find(column == endNode);                            
                                if (obj.DepotNodeOccupancy(index,2) == 0) || ((obj.DepotNodeOccupancy(index,2) == 1)&&(obj.DepotNodeOccupancy(index,3) == i)) %�����յ��Ȩ���ѱ��ͷ�
                                    obj.TWPathPlanning(i,(Time+1),startNode,endNode,1);
                                    obj.RobotArray(i,1).setPlanned(1);
                                    plannedRobotNum = plannedRobotNum + 1;     
                                    obj.DepotNodeOccupancy(index,2) = 1;
                                    obj.DepotNodeOccupancy(index,3) = i;  
                                end
                            elseif ~isempty(a) %������λ�ڷŻ��� 
                                column = obj.PickUpNodeOccupancy(:,1);
                                index = find(column == startNode);
                                if (obj.PickUpNodeOccupancy(index,2) == 0) || ((obj.PickUpNodeOccupancy(index,2) == 1)&&(obj.PickUpNodeOccupancy(index,3) == i)) %��������Ȩ���ѱ��ͷ�
                                    obj.TWPathPlanning(i,Time,startNode,robotNode,-1);
                                    obj.RobotArray(i,1).setPlanned(1);
                                    plannedRobotNum = plannedRobotNum + 1;                              
                                    obj.PickUpNodeOccupancy(index,2) = 1;
                                    obj.PickUpNodeOccupancy(index,3) = i;                                
                                end
                            end
                        end                    
                    end
                end
            end
        end
        
        %ʱ�䴰�滮�㷨
        function TWPathPlanning(obj,Number,Time,StartNode,EndNode,order) %order,1:��ȡ�������Ż���/-1:�ӷŻ�����ȡ����
            kPlannedResult = []; %��ʱ�洢K�����·���Ĺ滮������Ż�ʱ��
            kShortestPaths = [];            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��KShortestPaths��������K���·��%%%%%%%%%%%%%%%%%%%%%%%%%%%%(��������ʱ��)
%             index = find(obj.KShortestPathsNodePair(:,1) == StartNode);
%             for i = 1:size(index,1)
%                 if obj.KShortestPathsNodePair(index(i,1),2) == EndNode %ƥ����
%                     kShortestPaths = obj.KShortestPaths{index(i,1),3};
%                     break;
%                 end
%             end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����ʱ�øò��ִ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %����K���·��
            column = obj.DepotNearCrossNode(:,1);
            index = find(column == EndNode);
            if obj.Failure == 1 %ϵͳ����ʧЧ������
                index1 = find(obj.DepotNearCrossNode(:,1) == EndNode);
                failureRobotNode = obj.RobotArray(obj.FailureRobotNum,1).getNode();
                nearDepotNode = obj.MapNode(obj.NodeCoordinate(failureRobotNode,2)-1,obj.NodeCoordinate(failureRobotNode,3));
                index2 = find(obj.DepotNearCrossNode(:,1) == nearDepotNode);
                node1 = obj.DepotNearCrossNode(index1,2);
                node2 = obj.DepotNearCrossNode(index1,3);
                node3 = obj.DepotNearCrossNode(index2,2);
                node4 = obj.DepotNearCrossNode(index2,3);                
                if node1 == node3 && node2 == node4 %EndNode��ʧЧ����������λ����ͬһ�����
                    if obj.NodeCoordinate(EndNode,3) < obj.NodeCoordinate(obj.RobotArray(obj.FailureRobotNum,1).getNode(),3)
                        crossNode1 = obj.DepotNearCrossNode(index,2);
                        crossNode2 = 0;
                        [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, StartNode, crossNode1, crossNode2, EndNode, 5, 5);
                        kShortestPaths = shortestPaths;                      
                    else 
                        crossNode1 = obj.DepotNearCrossNode(index,3);
                        crossNode2 = 0;
                        [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, StartNode, crossNode1, crossNode2, EndNode, 5, 5);
                        kShortestPaths = shortestPaths;                        
                    end                    
                else %EndNode��ʧЧ����������λ�ò���ͬһ�����
                    crossNode1 = obj.DepotNearCrossNode(index,2);
                    crossNode2 = obj.DepotNearCrossNode(index,3);            
                    [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, StartNode, crossNode1, crossNode2, EndNode, 5, 5);
                    kShortestPaths = shortestPaths;                     
                end
            else %ϵͳ����ʧЧ������
                crossNode1 = obj.DepotNearCrossNode(index,2);
                crossNode2 = obj.DepotNearCrossNode(index,3);            
                [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, StartNode, crossNode1, crossNode2, EndNode, 5, 5);
                kShortestPaths = shortestPaths;                
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%����������·���ڵ��в���ȷ֮�������޸�(·�����ظ�)%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(kShortestPaths,2)
                if size(kShortestPaths{1,i},2) > 3 %��·��������ɵ���Ҫ�ڵ���ڵ���4��
                    node1 = kShortestPaths{1,i}(1,end); %���ܵ�
                    node2 = kShortestPaths{1,i}(1,end-2); %������3����
                    node3 = kShortestPaths{1,i}(1,end-3); %������4����
                    if (obj.NodeCoordinate(node1,3) - obj.NodeCoordinate(node2,3))*(obj.NodeCoordinate(node1,3) - obj.NodeCoordinate(node3,3)) < 0 %node1λ��node2��node3֮��
                        kShortestPaths{1,i}(:,end-2) = [];
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��K��·���ϵĽڵ㲹������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            kPathNode = []; %�洢K��·��������·����
            for i = 1:size(kShortestPaths,2)
                pathCrossNode = kShortestPaths{1,i}; %ÿһ��·����Ӧ����� + ����ڽڵ� + �յ�
                pathNode = []; %��¼��ǰ·���е������ڵ�
                if order == 1
                    for j = 1:(size(pathCrossNode,2)-1)
                        node1 = pathCrossNode(1,j);
                        node2 = pathCrossNode(1,j+1);
                        r1 = obj.NodeCoordinate(node1,2);
                        c1 = obj.NodeCoordinate(node1,3);
                        r2 = obj.NodeCoordinate(node2,2);
                        c2 = obj.NodeCoordinate(node2,3); 
                        pathNode(size(pathNode,1)+1,1) = node1;
                        if r1 == r2
                            deltaC = abs(c2 - c1);
                            for k = 1:(deltaC-1)
                                C = c1 + k*sign(c2-c1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(r1,C);
                            end
                        elseif c1 == c2
                            deltaR = abs(r2-r1);
                            for k = 1:(deltaR-1)
                                R = r1 + k*sign(r2-r1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(R,c1);
                            end                            
                        end
                    end   
                    pathNode(size(pathNode,1)+1,1) = pathCrossNode(1,size(pathCrossNode,2));
                elseif order == -1
                    for j = size(pathCrossNode,2):-1:2
                        node1 = pathCrossNode(1,j);
                        node2 = pathCrossNode(1,j-1);
                        r1 = obj.NodeCoordinate(node1,2);
                        c1 = obj.NodeCoordinate(node1,3);
                        r2 = obj.NodeCoordinate(node2,2);
                        c2 = obj.NodeCoordinate(node2,3);  
                        pathNode(size(pathNode,1)+1,1) = node1;
                        if r1 == r2
                            deltaC = abs(c2 - c1);
                            for k = 1:(deltaC-1)
                                C = c1 + k*sign(c2-c1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(r1,C);
                            end
                        elseif c1 == c2
                            deltaR = abs(r2-r1);
                            for k = 1:(deltaR-1)
                                R = r1 + k*sign(r2-r1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(R,c1);
                            end                            
                        end                        
                    end
                    pathNode(size(pathNode,1)+1,1) = pathCrossNode(1,1);
                end 
                kPathNode{i,1} = pathNode;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ΪK��·������ʱ�䴰%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(kPathNode,1)
                pathNode = kPathNode{i,1};
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%ʱ�䴰��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                InitializedTW = zeros(size(pathNode,1),2);
                for j = 1:size(pathNode,1)
                    if j == size(pathNode,1)
                        InitializedTW(j,1) = pathNode(j,1);
                        InitializedTW(j,2) = 3;                        
                    else
                        InitializedTW(j,1) = pathNode(j,1);
                        InitializedTW(j,2) = 1;                        
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
                plannedSuccess = 0; %��¼ĳ��path��ʱ�䴰�滮�Ƿ���ɣ�0-δ��ɣ�1-��ɣ�
                pathNodeIndex = 0;
                nodeOverlapIndex = 0;
                InsertedTW = zeros(size(InitializedTW,1),4);
                eachPlannedTW = zeros(size(InitializedTW,1),4);
                k = 1;
                while plannedSuccess == 0
                    [InsertedTW, Node, t1, t2, Index] = obj.twInsert(InitializedTW,InsertedTW,Time,order,Number,pathNodeIndex,nodeOverlapIndex);
                    ConnectedTW = obj.twConnect(InsertedTW);
                    [pathNodeIndex, nodeOverlapIndex, eachPlannedTW, plannedSuccess] = obj.twOverlapDetect(ConnectedTW);
                end
                %%%%%%%%%%%%%%%%%%%%�ѹ滮�������kPlannedResult��%%%%%%%%%%%%%%%%%%%%
                kPlannedResult{size(kPlannedResult,1)+1,1} = eachPlannedTW;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����kPlannedResult��K��·����ѡ�����Ž��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            finishT = inf;
            index = 0;
            for i = 1:size(kPlannedResult,1)
                T = kPlannedResult{i,1}(size(kPlannedResult{i,1},1),3) - kPlannedResult{i,1}(1,2) + 1;
                if T < finishT
                    finishT = T;
                    index = i;
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��������ʻ��������AllNodeTW��AllRobotTW��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            plannedTW = kPlannedResult{index,1};
            obj.AllRobotTW{Number,1} = zeros(size(plannedTW,1),3);
            for i = 1:size(plannedTW,1)
                obj.AllRobotTW{Number,1}(i,1) = plannedTW(i,1);
                obj.AllRobotTW{Number,1}(i,2) = plannedTW(i,2);
                obj.AllRobotTW{Number,1}(i,3) = plannedTW(i,3);
                if isempty(obj.AllNodeTW{plannedTW(i,1),1}) %node������ʱ�䴰   
                    obj.AllNodeTW{plannedTW(i,1),1}(1,1) = plannedTW(i,2);
                    obj.AllNodeTW{plannedTW(i,1),1}(1,2) = plannedTW(i,3);
                    obj.AllNodeTW{plannedTW(i,1),1}(1,3) = Number;
                else %node������ʱ�䴰
%                     disp('�����˱��');
%                     disp(Number);
%                     disp(i);
%                     disp(plannedTW(i,1))
%                     disp(plannedTW(i,4));
                    if plannedTW(i,4) == 1 %���ڵ�һ��
                        obj.AllNodeTW{plannedTW(i,1),1} = [[plannedTW(i,2) plannedTW(i,3) Number];obj.AllNodeTW{plannedTW(i,1),1}];
                    elseif plannedTW(i,4) == (size(obj.AllNodeTW{plannedTW(i,1),1},1) + 1) %�������һ��
                        obj.AllNodeTW{plannedTW(i,1),1} = [obj.AllNodeTW{plannedTW(i,1),1};[plannedTW(i,2) plannedTW(i,3) Number]];
                    else %�����м�
                        obj.AllNodeTW{plannedTW(i,1),1} = [obj.AllNodeTW{plannedTW(i,1),1}(1:(plannedTW(i,4)-1),:);[plannedTW(i,2) plannedTW(i,3) Number];obj.AllNodeTW{plannedTW(i,1),1}(plannedTW(i,4):end,:)];
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ʱ�䴰�㷨1����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %ʱ�䴰����
        function [InsertedTW, Node, t1, t2, Index] = twInsert(obj,InitializedTW,InsertedTW,Time,order,Number,pathNodeIndex,nodeOverlapIndex) 
            Node = 0;
            t1 = 0;
            t2 = 0;
            Index = 0;
            if pathNodeIndex == 0 %��һ�β���
                for i = 1:size(InitializedTW,1)
                    node = InitializedTW(i,1); %��ǰ��Ҫ����ʱ�䴰����Ľڵ�
                    if i == 1 %·�������ϵ�һ����
%                         if order == 1 %��ȡ�������Ż���
%                             disp(Number);
%                             if isempty(obj.AllNodeTW{node,1}) %node1�ϻ�û���κε�ʱ�䴰
%                                 InsertedTW(i,1) = node;
%                                 InsertedTW(i,2) = Time;
%                                 InsertedTW(i,3) = Time;
%                                 InsertedTW(i,4) = 1;
%                             else %node1���Ѿ���ʱ�䴰
%                                 indexList = find(obj.AllNodeTW{node,1}(:,3) == Number);
%                                 disp('�û�����ռ�øõ�ʱ�䴰��index');
%                                 disp(indexList);
%                                 index = indexList(size(indexList,1),1);
%                                 InsertedTW(i,1) = node;
%                                 InsertedTW(i,2) = obj.AllNodeTW{node,1}(index,1);
%                                 InsertedTW(i,3) = obj.AllNodeTW{node,1}(index,2);
%                                 InsertedTW(i,4) = index;    
%                                 obj.AllNodeTW{node,1}(index,:) = [];
%                                 Node = node;
%                                 t1 = InsertedTW(i,2);
%                                 t2 = InsertedTW(i,3);
%                                 Index = InsertedTW(i,4);
%                             end
%                         elseif order == -1 %�ӷŻ�����ȡ����
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = Time;
                            InsertedTW(i,3) = Time;
                            InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                        
%                         end                    
                    else %·�������ϵ�һ����֮��
                        lastNodeEndTime = InsertedTW(i-1,3);
                        nodeTimeLength = InitializedTW(i,2);
                        if size(obj.AllNodeTW{node,1},1) == 0 %node�ϻ�û���κ�ʱ�䴰
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = lastNodeEndTime + 1;
                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                            InsertedTW(i,4) = 1;                        
                        elseif size(obj.AllNodeTW{node,1},1) == 1 %node��ֻ��һ��ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                             
                            else %���ڵ�һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(1,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(1,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(1,2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(1,2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                    
                                end
                                InsertedTW(i,4) = 2;                                  
                            end
                        else %node������������ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                            
                            elseif (lastNodeEndTime+1) > obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) || (lastNodeEndTime+1) == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) %�������һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                              
                            else
                                success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                                for j = 1:(size(obj.AllNodeTW{node,1},1)-1) 
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(j,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(j,2) %��node�ϵ�j��ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) > (nodeTimeLength+2) || (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) == (nodeTimeLength+2) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 1 + 1;
                                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 1 + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = lastNodeEndTime + 1;
                                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    end
                                end
                                if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                    InsertedTW(i,1) = node;
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = lastNodeEndTime + 1;
                                        InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                    end
                                    InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                   
                                end
                            end
                        end
                    end
                end
            elseif pathNodeIndex ~= 0 %ʱ�䴰�н��棬���²���
%                 if order == 1
%                     node = InitializedTW(1,1);
%                     indexList = find(obj.AllNodeTW{node,1}(:,3) == Number);
%                     index = indexList(size(indexList,1),1);  
%                     Node = node;
%                     t1 = obj.AllNodeTW{node,1}(index,1);
%                     t2 = obj.AllNodeTW{node,1}(index,2);
%                     Index = index;                 
%                     obj.AllNodeTW{node,1}(index,:) = [];
%                 end

%                 try
%                     lastNodeEndTime = InsertedTW(pathNodeIndex-1,3);
%                 catch
%                     disp(order);
%                     disp(Number);
%                     disp(Time);
%                     disp(pathNodeIndex);
%                     disp(nodeOverlapIndex);
%                     disp(InsertedTW(1,1));
%                     disp(InsertedTW(1,:));
%                     disp(obj.AllNodeTW{InsertedTW(1,1),1});
%                 end
                %%%%%%%%%%%%%%%%%%InsertedTW��pathNodeIndex���Ժ�Ķ���0%%%%%%%%%%%%%%%%
                for i = pathNodeIndex:size(InsertedTW,1)
                    for j = 1:4
                        InsertedTW(i,j) = 0;
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                for i = pathNodeIndex:size(InsertedTW,1)
                    node = InitializedTW(i,1);
                    lastNodeEndTime = InsertedTW(i-1,3);
                    nodeTimeLength = InitializedTW(i,2);                    
                    if i == pathNodeIndex %ʱ�䴰�н�����Ǹ���,����nodeOverlapIndex���в���
                        if nodeOverlapIndex == size(obj.AllNodeTW{node,1},1) %���������һ��
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                            InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                             
                        else
                            success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                            for j = nodeOverlapIndex:(size(obj.AllNodeTW{node,1},1)-1) 
                                if (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) > (nodeTimeLength+2) || (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) == (nodeTimeLength+2) %���ڵ�j��ʱ�䴰֮��
                                    InsertedTW(i,1) = node;
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 1 + nodeTimeLength;
                                    InsertedTW(i,4) = j + 1;  
                                    success = 1;
                                    break;
                                end                                        
                            end
                            if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                
                            end                            
                        end
                    else %·�������ϵ�һ����֮��
                        if size(obj.AllNodeTW{node,1},1) == 0 %node�ϻ�û���κ�ʱ�䴰
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = lastNodeEndTime + 1;
                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                            InsertedTW(i,4) = 1;                        
                        elseif size(obj.AllNodeTW{node,1},1) == 1 %node��ֻ��һ��ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                             
                            else %���ڵ�һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(1,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(1,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(1,2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(1,2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                    
                                end
                                InsertedTW(i,4) = 2;                                  
                            end
                        else %node������������ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                            
                            elseif (lastNodeEndTime+1) > obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) || (lastNodeEndTime+1) == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) %�������һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                              
                            else
                                success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                                for j = 1:(size(obj.AllNodeTW{node,1},1)-1) 
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(j,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(j,2) %��node�ϵ�j��ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) > (nodeTimeLength+2) || (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) == (nodeTimeLength+2) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 1 + 1;
                                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 1 + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = lastNodeEndTime + 1;
                                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    end
                                end
                                if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                    InsertedTW(i,1) = node;
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = lastNodeEndTime + 1;
                                        InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                    end
                                    InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                   
                                end
                            end
                        end
                    end
                end
            end
        end        
        
        %ʱ�䴰����
        function ConnectedTW = twConnect(obj,InsertedTW) 
            ConnectedTW = zeros(size(InsertedTW,1),4);
            for i = 1:(size(InsertedTW,1)-1)
                ConnectedTW(i,1) = InsertedTW(i,1);
                ConnectedTW(i,2) = InsertedTW(i,2);
                ConnectedTW(i,3) = InsertedTW(i+1,2) - 1;
                ConnectedTW(i,4) = InsertedTW(i,4);
            end
            ConnectedTW(size(ConnectedTW,1),1) = InsertedTW(size(InsertedTW,1),1);
            ConnectedTW(size(ConnectedTW,1),2) = InsertedTW(size(InsertedTW,1),2);
            ConnectedTW(size(ConnectedTW,1),3) = InsertedTW(size(InsertedTW,1),3);
            ConnectedTW(size(ConnectedTW,1),4) = InsertedTW(size(InsertedTW,1),4);
        end        
        
        %ʱ�䴰Overlap���
        % pathNodeIndex:path�ϵ�һ������ʱ�䴰�������path�ϵڼ�����,0-δ����,��������-�н���
        % nodeOverlapIndex:��node�ϵ�ʱ�䴰���������ʱ�䴰��ŵ����һ��,0-δ����,��������-�н���
        function [pathNodeIndex, nodeOverlapIndex, eachPlannedTW, plannedSuccess] = twOverlapDetect(obj,ConnectedTW) 
            success = 1;%��¼�Ƿ���ʱ�䴰���棬0-�н��棬1-û�н���
            eachPlannedTW = zeros(size(ConnectedTW,1),4);
            for i = 1:(size(ConnectedTW,1)-1)
                node = ConnectedTW(i,1);
                t1 = ConnectedTW(i,2);
                t2 = ConnectedTW(i,3);
                if size(obj.AllNodeTW{node,1},1) == 0 %node��û��ʱ�䴰����
                    continue;
                else %node����ʱ�䴰����
                    for j = size(obj.AllNodeTW{node,1},1):-1:1
                        t3 = obj.AllNodeTW{node,1}(j,1);
                        t4 = obj.AllNodeTW{node,1}(j,2);
                        if ((t1<=t3)&&(t2>=t3)) || ((t2>=t4)&&(t1<=t4)) %ʱ�䴰���ڽ���
                            success = 0;
                            plannedSuccess = 0;
                            pathNodeIndex = i;
                            nodeOverlapIndex = j;
                            break;
                        end
                    end
                end                 
                if success == 0 %�Ѽ�⵽ʱ�䴰����
                    break;
                end
            end
            if success == 1 %ȫ�����һ�飬����ʱ�䴰û�н���
                plannedSuccess = 1;
                pathNodeIndex = 0;
                nodeOverlapIndex = 0;
                for i = 1:size(ConnectedTW,1)
                    for j = 1:4
                        eachPlannedTW(i,j) = ConnectedTW(i,j);
                    end
                end
            end
        end        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %������ʧЧ���滮����
        function robotFailurePlanning(obj,Time)
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ѡ��ʧЧ������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:obj.TotalRobotNumber
                node = obj.RobotArray(i,1).getNode();
                atCandidateFailureNode = find(obj.CandidateFailureNode == node);
                if ~isempty(atCandidateFailureNode) %����������λ�ڿ���ʧЧ�Ľڵ�
                    row = obj.NodeCoordinate(node,2); %���������ڽڵ����
                    column = obj.NodeCoordinate(node,3); %���������ڽڵ����
                    nowNodeNearDepotNode = obj.MapNode(row-1,column); %����������λ����һ�еĻ��ܵ�
                    crossNode1 = obj.DepotNearCrossNode(find(obj.DepotNearCrossNode(:,1) == nowNodeNearDepotNode),2); %��node�������ཻ��ڽڵ�
                    crossNode1Column = obj.NodeCoordinate(crossNode1,3); %��node�������ཻ��ڽڵ����
                    %%%%%%%%%%%%%%%%%%%%%%%�洢�����˸����Ļ��ܵ��Լ���·��%%%%%%%%%%%%%%%%%%%%%%%
                    nearDepotNode = []; %�洢��������������еĻ��ܵ�
                    nearPathNode = []; %�洢��������������еĵ�·��(��������ǰ�жϵĻ��������ڵĽڵ�)
                    for j = 1:6
                        row1 = size(nearDepotNode,1);
                        nearDepotNode(row1+1,1) = obj.MapNode(row-1,crossNode1Column+j);   
                        nearDepotNode(row1+2,1) = obj.MapNode(row+1,crossNode1Column+j);
                        if (crossNode1Column+j) ~= column                            
                            row2 = size(nearPathNode,1);
                            nearPathNode(row2+1,1) = obj.MapNode(row,crossNode1Column+j);
                        end
                    end  
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    success = 1;
                    influencedRobotNum = 0;
                    for j = 1:obj.TotalRobotNumber
                        if j ~= i
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%������·���޻�����%%%%%%%%%%%%%%%%%%%%%%%%%
                            atPathNode = find(nearPathNode == obj.RobotArray(j,1).getNode());
                            if ~isempty(atPathNode) %������·���л�����
                                success = 0;
                                break;
                            end
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%%%%%%%%%%%%%%%%%%%%%%%�������ܵ�����������˵��յ�%%%%%%%%%%%%%%%%%%%%%%
                            if obj.RobotArray(j,1).getStatus() == 1 && obj.RobotArray(j,1).getNode() ~= obj.RobotArray(j,1).taskEndNode %�����������������ڲ�λ�������յ�
                                atDepotNode = find(nearDepotNode == obj.RobotArray(j,1).taskEndNode);
                                if ~isempty(atDepotNode) %�������ܵ�����������˵��յ�
                                    success = 0;
                                    break;
                                end
                            end
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%%%%%%%%%%%%%%%%%%%%%%�������ܵ����ѹ滮�����˵����%%%%%%%%%%%%%%%%%%%%%
                            if obj.RobotArray(j,1).getStatus() == 1 && obj.RobotArray(j,1).getPlanned() == 1 %���������ѹ滮
                                if ~isempty(find(nearDepotNode == obj.RobotArray(j,1).getNode())) %����������λ�ڸ������ܵ�
                                    if obj.RobotArray(j,1).getNode() == obj.AllRobotTW{j,1}(1,1) %�����˽������ڵ�λ����Ϊ������
                                        influenced = find(obj.AllRobotTW{j,1}(:,1) == obj.RobotArray(i,1).getNode());
                                        if ~isempty(influenced)
                                            success = 0;
                                            break;
                                        end
                                    end
                                end
                            end                            
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ڱ�Ӱ��Ļ�����%%%%%%%%%%%%%%%%%%%%%%%%%%
                            nowRobotNode = obj.RobotArray(i,1).getNode();
                            if ~isempty(obj.AllRobotTW{i,1}) %i�Ż������ѹ滮��
                                index = find(obj.AllRobotTW{i,1}(:,1) == nowRobotNode);
                                leftPathNode = obj.AllRobotTW{i,1}(index:end,1);
                                influenced = find(leftPathNode == obj.RobotArray(i,1).getNode());
                                if ~isempty(influenced) %ʣ��·����Ӱ��
                                    influencedRobotNum = influencedRobotNum + 1;
                                end  
                            end
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         
                        end
                    end
                    if success == 1 && influencedRobotNum > 0 %������·��û����������� + ��������û����������˵��յ� + ���ܵ�Ӱ��Ļ������һ����˲��ǽ�Ҫ�Ӹ����Ļ��ܵ����
                        obj.Failure = 1;
                        obj.FailureRobotNum = i;
                        obj.FailureTime = Time;
                        %obj.FailureLength = 10;
                        break;
                    else
                        continue;
                    end                       
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if obj.Failure == 1 %������ʧЧ������
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ɾ��ʧЧ�����˺���ʱ�䴰 + �޸��ڽӾ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %ɾ������ʱ�䴰
                failureNode = obj.RobotArray(obj.FailureRobotNum,1).getNode();
                index = find(obj.AllRobotTW{obj.FailureRobotNum,1}(:,1) == failureNode);
                for i = index:size(obj.AllRobotTW{obj.FailureRobotNum,1},1)
                    node = obj.AllRobotTW{obj.FailureRobotNum,1}(i,1);
                    t1 = obj.AllRobotTW{obj.FailureRobotNum,1}(i,2);
                    t2 = obj.AllRobotTW{obj.FailureRobotNum,1}(i,3);
                    for j = 1:size(obj.AllNodeTW{node,1},1)
                        t3 = obj.AllNodeTW{node,1}(j,1);
                        t4 = obj.AllNodeTW{node,1}(j,2);                        
                        if t1 == t3 && t2 == t4 && obj.FailureRobotNum == obj.AllNodeTW{node,1}(j,3)
                            if i == index
%                                 obj.AllNodeTW{node,1}(j,2) = Time;
                                obj.AllNodeTW{node,1}(j,:) = [];
                            else
                                obj.AllNodeTW{node,1}(j,:) = [];
                            end  
                            break;
                        end
                    end
                end
                %�޸��ڽӾ���
                nearDepotNode = obj.MapNode(obj.NodeCoordinate(failureNode,2)-1,obj.NodeCoordinate(failureNode,3));
                depotIndex = find(obj.DepotNearCrossNode(:,1) == nearDepotNode);
                node1 = obj.DepotNearCrossNode(depotIndex,2); %ʧЧ�㸽�����ڽӾ���ڵ�1
                node2 = obj.DepotNearCrossNode(depotIndex,3); %ʧЧ�㸽�����ڽӾ���ڵ�2
                node1Index = find(obj.AdjacentMatrixNode == node1);
                node2Index = find(obj.AdjacentMatrixNode == node2);
                obj.AdjacentMatrix(node1Index,node2Index) = inf;
                obj.AdjacentMatrix(node2Index,node1Index) = inf;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ж�Path��Ӱ��Ļ�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                influencedRobot = [];
                for i = 1:obj.TotalRobotNumber
                    if i ~= obj.FailureRobotNum %��ʧЧ������
                        if ~isempty(obj.AllRobotTW{i,1})
                            nowRobotNode = obj.RobotArray(i,1).getNode();
                            index = find(obj.AllRobotTW{i,1}(:,1) == nowRobotNode);
                            leftPathNode = obj.AllRobotTW{i,1}(index:end,1);
                            influenced = find(leftPathNode == obj.RobotArray(obj.FailureRobotNum,1).getNode());
                            if ~isempty(influenced) %ʣ��·����Ӱ��
                                row = size(influencedRobot,1);
                                influencedRobot(row+1,1) = i;
                            end
                        end
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��influencedRobot��ȡ������ȡ����/�Ż���Ļ�����%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %������������ˣ���������Ӱ��Ļ����˶��ع滮��֮����Ϊ�������¹滮
                influencedReplanRobot = []; %��¼��������Ӱ�죬������λ��ȡ����/�Ż���
                if ~isempty(influencedRobot)
                    for i = 1:size(influencedRobot,1)
                        if ~isempty(influencedRobot)
                            disp('iii');
                            disp(i);
                            disp(size(influencedRobot,1));
                            number = influencedRobot(i,1);
                            nowNode = obj.RobotArray(number,1).getNode();
                            if ~isempty(find(obj.PickUpNode == nowNode)) || ~isempty(find(obj.DepotNode == nowNode)) %��Ӱ��Ļ���������λ��ȡ����/�Ż���
                                influencedRobot(i,:) = [];
                                row = size(influencedReplanRobot,1);
                                influencedReplanRobot(row+1,1) = number;
                                i = i - 1;
                            end
                        end
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Ϊ��Ӱ��Ļ����˷������ȼ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %���� T =��ʧЧǰ�滮����ʧЧ�����˽ڵ�ʱ�� - ��ǰʱ�̣��Ĵ�С�����䣬TԽС�����ȼ�Խ��
                if ~isempty(influencedRobot)
                    robotPriority = zeros(size(influencedRobot,1),1);
                    robotDeltaT = zeros(size(influencedRobot,1),2); %��һ��-��Ӱ������˱�ţ��ڶ���-ʱ���
                    for i = 1:size(influencedRobot,1)
                        number = influencedRobot(i,1); %��Ӱ������˱��
                        index = find(obj.AllRobotTW{number,1}(:,1) == obj.RobotArray(obj.FailureRobotNum,1).getNode());
                        deltaT = obj.AllRobotTW{number,1}(index(1,1),2) - Time;
                        robotDeltaT(i,1) = number;
                        robotDeltaT(i,2) = deltaT;
                    end
                    robotDeltaTCopy = robotDeltaT;
                    for i = 1:size(robotDeltaT,1)
                        T = inf;
                        index = 0;
                        for j = 1:size(robotDeltaTCopy,1)
                            if robotDeltaTCopy(j,2) < T
                                T = robotDeltaTCopy(j,2);
                                index = j;
                            end
                        end
                        robotPriority(i,1) = robotDeltaTCopy(index,1);
                        robotDeltaTCopy(index,:) = [];
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%�������ȼ�����滮influencedRobot�еĻ�����,�����켣%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if ~isempty(influencedRobot)
                    for i = 1:size(robotPriority,1)
                        number = robotPriority(i,1);
                        obj.localTrajectoryPlanning(number,Time);
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%����滮influencedReplanRobot�еĻ����ˣ�����ͷ�ع滮%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if ~isempty(influencedReplanRobot)
                    for k = 1:size(influencedReplanRobot,1)
                        robotNum = influencedReplanRobot(k,1);
                        %ɾ��obj.AllRobotTW{robotNum,1}��obj.AllRobotTW�ϵ�TW
                        for i = 1:size(obj.AllRobotTW{robotNum,1},1)
                            node = obj.AllRobotTW{robotNum,1}(i,1);
                            t1 = obj.AllRobotTW{robotNum,1}(i,2);
                            t2 = obj.AllRobotTW{robotNum,1}(i,3);
                            for j = 1:size(obj.AllNodeTW{node,1},1)
                                t3 = obj.AllNodeTW{node,1}(j,1);
                                t4 = obj.AllNodeTW{node,1}(j,2);
                                if t1 == t3 && t2 == t4 && obj.AllNodeTW{node,1}(j,3) == robotNum
                                    obj.AllNodeTW{node,1}(j,:) = [];
                                    break;
                                end
                            end
                        end  
                        obj.AllRobotTW{robotNum,1} = [];
                        %���½���TW�滮
                        robotNode = obj.RobotArray(robotNum,1).getNode();
                        if ~isempty(find(obj.DepotNode == robotNode)) %Ҫ�ع滮�Ļ���������λ�ڷŻ���
                            obj.TWPathPlanning(robotNum,Time,obj.RobotArray(robotNum,1).taskStartNode,robotNode,-1);
                        else %Ҫ�ع滮�Ļ���������λ��ȡ����
                            obj.TWPathPlanning(robotNum,Time,obj.RobotArray(robotNum,1).taskStartNode,obj.RobotArray(robotNum,1).taskEndNode,1);
                        end
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end
        end

        %�ֲ��켣��������
        function localTrajectoryPlanning(obj,number,Time)
            %%%%%%%%%%%%%%%%%%%%%%%��¼�����˵�ǰλ�õ�ʧЧ��֮ǰ���ڽӾ���ڵ� + ʧЧ��֮����ڽӾ���ڵ�%%%%%%%%%%%%%%%%%%%%%%%%
            nowNode = obj.RobotArray(number,1).getNode(); %�����˵�ǰ���ڵĽڵ�
            failureNode = obj.RobotArray(obj.FailureRobotNum,1).getNode(); %ʧЧ�������������ڵĽڵ�
            index1 = find(obj.AllRobotTW{number,1}(:,1) == nowNode);
            index2 = find(obj.AllRobotTW{number,1}(:,1) == failureNode);
            pathNode1 = obj.AllRobotTW{number,1}(index1:index2-1,1); %�����˵�ǰλ�õ�ʧЧ��֮ǰ��·���ڵ�
            pathNode2 = obj.AllRobotTW{number,1}(index2+1:end-1,1); %ʧЧ�㼰֮���·���ڵ㣨�������յ㣩
            pathCrossNode1 = [];
            pathCrossNode2 = [];
            for i = 1:size(pathNode1,1)
                if ~isempty(find(obj.AdjacentMatrixNode == pathNode1(i,1)))
                    row = size(pathCrossNode1,1);
                    pathCrossNode1(row+1,1) = pathNode1(i,1);
                end
            end
            for i = 1:size(pathNode2,1)
                if ~isempty(find(obj.AdjacentMatrixNode == pathNode2(i,1)))
                    row = size(pathCrossNode2,1);
                    pathCrossNode2(row+1,1) = pathNode2(i,1);
                end                
            end 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��¼�ֲ������ķ�Χ������ʼ�� + �յ㣩%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            startNode = 0; %�ֲ�����·����ʼ����ڽڵ�
            endNode = 0; %�ֲ�����·����󽻲�ڽڵ�
            if size(pathCrossNode1,1) < obj.beforeFailureNodeNum
                startNode = pathCrossNode1(1,1);
            else
                startNode = pathCrossNode1(size(pathCrossNode1,1) - obj.beforeFailureNodeNum + 1,1);
            end
            if ~isempty(pathCrossNode2) %ʧЧ��֮���·���ڵ������д����ڽӾ���ڵ�
                if size(pathCrossNode2,1) < obj.afterFailureNodeNum
                    endNode = pathCrossNode2(end,1);
                else
                    endNode = pathCrossNode2(obj.afterFailureNodeNum,1);
                end   
            else %ʧЧ��֮���·���ڵ������в������ڽӾ���ڵ㣬��ʧЧ���뵱ǰ������Ҫǰ���Ļ��ܵ���ͬһ�����
                failureNodeR = obj.NodeCoordinate(failureNode,2);
                failureNodeC = obj.NodeCoordinate(failureNode,3);
                nearDepotNode = obj.MapNode(failureNodeR-1,failureNodeC);
                if obj.NodeCoordinate(pathCrossNode1(end,1),3) < obj.NodeCoordinate(obj.RobotArray(obj.FailureRobotNum,1).getNode(),3) %ʧЧ��֮ǰ���ڽӾ���ڵ���ʧЧ�����
                    endNode = obj.DepotNearCrossNode(find(obj.DepotNearCrossNode(:,1) == nearDepotNode),3);
                else %ʧЧ��֮ǰ���ڽӾ���ڵ���ʧЧ���ұ�
                    endNode = obj.DepotNearCrossNode(find(obj.DepotNearCrossNode(:,1) == nearDepotNode),2);
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ֲ�·������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            pathSearchSuccess = 1;
            III = find(obj.AllRobotTW{number,1}(:,1) == endNode);
            try
                endNodeT = obj.AllRobotTW{number,1}(III(1,1),2);
            catch
                disp('endNode');
                disp(endNode);
                disp('III');
                disp(III);
                disp('obj.AllRobotTW{number,1}');
                disp(obj.AllRobotTW{number,1});
            end
            endNodeT = obj.AllRobotTW{number,1}(III(1,1),2); %ʧЧǰ�滮�ĵ���endNode��ʱ��
            [shortestLocalPaths, totalLocalCosts] = LocalPathSearch(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, startNode, endNode, 5);
            if isempty(shortestLocalPaths) %δ�����������������ľֲ�·��
                pathSearchSuccess = 0;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            success = 0; %��¼�ֲ�·��TW�����Ƿ�ɹ���1-�ɹ���0-ʧ��
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ֲ��켣����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if pathSearchSuccess == 1 %�������˿��Ծֲ�������·��
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��K��·���ϵĽڵ㲹������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                kPathNode = []; %�洢K��·��������·����
                for i = 1:size(shortestLocalPaths,1)
                    pathCrossNode = shortestLocalPaths{i,1}; %ÿһ��·����Ӧ����� + ����ڽڵ� + �յ�
                    pathNode = []; %��¼��ǰ·���е������ڵ�
                    for j = 1:(size(pathCrossNode,2)-1)
                        node1 = pathCrossNode(1,j);
                        node2 = pathCrossNode(1,j+1);
                        r1 = obj.NodeCoordinate(node1,2);
                        c1 = obj.NodeCoordinate(node1,3);
                        r2 = obj.NodeCoordinate(node2,2);
                        c2 = obj.NodeCoordinate(node2,3); 
                        pathNode(size(pathNode,1)+1,1) = node1;
                        if r1 == r2
                            deltaC = abs(c2 - c1);
                            for k = 1:(deltaC-1)
                                C = c1 + k*sign(c2-c1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(r1,C);
                            end
                        elseif c1 == c2
                            deltaR = abs(r2-r1);
                            for k = 1:(deltaR-1)
                                R = r1 + k*sign(r2-r1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(R,c1);
                            end                            
                        end
                    end   
                    pathNode(size(pathNode,1)+1,1) = pathCrossNode(1,size(pathCrossNode,2));
                    kPathNode{i,1} = pathNode;
                end
                %��������������λ�ò����ھֲ�����·������㣬����Ҫ�������֮ǰ��ǰһ���ڵ㣨��߹滮�ɹ��ʣ�
                if nowNode ~= startNode 
                    startIndex = find(obj.AllRobotTW{number,1}(:,1) == startNode);
                    disp('obj.AllRobotTW{number,1}(startIndex-1,1)');
                    disp(obj.AllRobotTW{number,1}(startIndex-1,1));
                    for i = 1:size(kPathNode,1)
                        kPathNode{i,1} = [obj.AllRobotTW{number,1}(startIndex-1,1);kPathNode{i,1}];
                    end
                end            
                %��kPathNode������ÿһ���ֲ�·����endNodeɾ��
                for i = 1:size(kPathNode,1)
                    kPathNode{i,1}(end,:) = [];
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%�Ѿֲ�����·�����ֶ�Ӧ��֮ǰ�Ѿ��滮�õ�ʱ�䴰ɾ��%%%%%%%%%%%%%%%%%%%%%%%%
                localIndex1 = find(obj.AllRobotTW{number,1}(:,1) == kPathNode{i,1}(1,1));
                localIndex2 = find(obj.AllRobotTW{number,1}(:,1) == endNode);
                deleteNodeTW = []; %��¼��ɾ���Ľڵ��TW,���ֲ�·������ʧ�ܺ󣬹滮��ʱͣ����֮ǰ��Ҫ�Ѵ˾����еĽڵ�TW���²���
                for j = localIndex1:(localIndex2-1)
                    deleteNode = obj.AllRobotTW{number,1}(j,1);
                    t1 = obj.AllRobotTW{number,1}(j,2);
                    t2 = obj.AllRobotTW{number,1}(j,3);
                    for k = 1:size(obj.AllNodeTW{deleteNode,1},1)
                        t3 = obj.AllNodeTW{deleteNode,1}(k,1);
                        t4 = obj.AllNodeTW{deleteNode,1}(k,2);
                        robotNumber = obj.AllNodeTW{deleteNode,1}(k,3);
                        if t1 == t3 && t2 == t4 && number == robotNumber
                            obj.AllNodeTW{deleteNode,1}(k,:) = [];
                            Row = size(deleteNodeTW,1);
                            deleteNodeTW(Row+1,1) = deleteNode;
                            deleteNodeTW(Row+1,2) = t1;
                            deleteNodeTW(Row+1,3) = t2;
                            deleteNodeTW(Row+1,4) = k;
                            break;
                        end
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%              
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ΪkPathNode�е�·�����оֲ��켣�滮%%%%%%%%%%%%%%%%%%%%
                for i = 1:size(kPathNode,1)
                    pathNode = kPathNode{i,1};
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%ʱ�䴰��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    InitializedTW = zeros(size(pathNode,1),2);
                    for j = 1:size(pathNode,1)
                        InitializedTW(j,1) = pathNode(j,1);
                        InitializedTW(j,2) = 1;                        
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%%%%%%%%%%%%%%%%%%%%%%%�ֲ�����·������ʼʱ��%%%%%%%%%%%%%%%%%%%%%%%
                    KKK = find(obj.AllRobotTW{number,1}(:,1) == kPathNode{i,1}(1,1));
                    firstNodeT = obj.AllRobotTW{number,1}(KKK(1,1),2);
                    if Time < firstNodeT || Time == firstNodeT
                        startPlanT = firstNodeT;
                    else
                        startPlanT = Time - 1;
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %ԭɾ��obj.AllNodeTW��TW�Ĵ���λ��
                    %%%%%%%%%%%%%%%%%%%%%%%%��ʼ���оֲ��켣����%%%%%%%%%%%%%%%%%%%%%%%%%%
                    pathNodeIndex = 0;
                    nodeOverlapIndex = 0;
                    InsertedTW = zeros(size(InitializedTW,1),4);
                    eachPlannedTW = zeros(size(InitializedTW,1),4);
                    planSuccess = 0; %��¼�ôβ��롢���ӡ������Ƿ�ɹ�
                    pathPlanSuccess = 1; %��¼���ξֲ��������ֵ�·���ܷ�ɹ��滮����Ϊ0�������һ���TW�����޷�����/����TW������ǵ�һ���㣩����ֱ���������ι滮��������һ���ֲ�·���Ĺ滮
                    while planSuccess == 0
                        [InsertedTW, pathPlanSuccess] = obj.localTWInsert(number,InitializedTW,InsertedTW,startPlanT,endNodeT-1,pathNodeIndex,nodeOverlapIndex);
                        if pathPlanSuccess == 0
                            break;
                        end
                        ConnectedTW = obj.localTWConnect(InsertedTW);
                        [pathPlanSuccess, planSuccess, pathNodeIndex, nodeOverlapIndex,eachPlannedTW] = obj.localTWOverlapDetect(number,ConnectedTW);
                        if pathPlanSuccess == 0 %��⵽��TW�����ǵ�һ���㣬planSuccess�Ѿ���Ϊ0
                            break;
                        end                        
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if planSuccess == 1 %���ξֲ�·��TW�����ɹ�
                        success = 1;
                        break;
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%�ֲ�·�������ɹ�,�޸�obj.AllRobotTW{number,1},�ѽڵ��µ�TW���뵽obj.AllNodeTW��%%%%%%%%%%%%%%
            if success == 1
                startIndex = find(obj.AllRobotTW{number,1}(:,1) == eachPlannedTW(1,1));
                endNodeIndex = find(obj.AllRobotTW{number,1}(:,1) == endNode) - 1;
                obj.AllRobotTW{number,1}(startIndex:endNodeIndex,:) = [];
                obj.AllRobotTW{number,1} = [obj.AllRobotTW{number,1}(1:startIndex-1,:);eachPlannedTW(:,1:3);obj.AllRobotTW{number,1}(startIndex:end,:)];
                for i = 1:size(eachPlannedTW,1)
                    if isempty(obj.AllNodeTW{eachPlannedTW(i,1),1}) %node������ʱ�䴰   
                        obj.AllNodeTW{eachPlannedTW(i,1),1}(1,1) = eachPlannedTW(i,2);
                        obj.AllNodeTW{eachPlannedTW(i,1),1}(1,2) = eachPlannedTW(i,3);
                        obj.AllNodeTW{eachPlannedTW(i,1),1}(1,3) = number;
                    else %node������ʱ�䴰
                        try
                            obj.AllNodeTW{eachPlannedTW(i,1),1};
                        catch
                            disp('eachPlannedTW');
                            disp(eachPlannedTW);
                            disp('i');
                            disp(i);
                            disp('eachPlannedTW(i,1)');
                            disp(eachPlannedTW(i,1));                            
                            disp('eachPlannedTW(i,4)');
                            disp(eachPlannedTW(i,4));
                        end
                        try
                            obj.AllNodeTW{eachPlannedTW(i,1),1}(1:(eachPlannedTW(i,4)-1),:);
                        catch
                            disp('eachPlannedTW');
                            disp(eachPlannedTW);
                            disp('i');
                            disp(i);
                            disp('eachPlannedTW(i,1)');
                            disp(eachPlannedTW(i,1));                            
                            disp('eachPlannedTW(i,4)');
                            disp(eachPlannedTW(i,4));
                        end
                        try
                            obj.AllNodeTW{eachPlannedTW(i,1),1}(eachPlannedTW(i,4):end,:);
                        catch
                            disp('eachPlannedTW');
                            disp(eachPlannedTW);
                            disp('i');
                            disp(i);
                            disp('eachPlannedTW(i,1)');
                            disp(eachPlannedTW(i,1));                            
                            disp('eachPlannedTW(i,4)');
                            disp(eachPlannedTW(i,4));
                        end                        
                        if eachPlannedTW(i,4) == 1 %���ڵ�һ��
                            obj.AllNodeTW{eachPlannedTW(i,1),1} = [[eachPlannedTW(i,2) eachPlannedTW(i,3) number];obj.AllNodeTW{eachPlannedTW(i,1),1}];
                        elseif eachPlannedTW(i,4) == (size(obj.AllNodeTW{eachPlannedTW(i,1),1},1) + 1) %�������һ��
                            obj.AllNodeTW{eachPlannedTW(i,1),1} = [obj.AllNodeTW{eachPlannedTW(i,1),1};[eachPlannedTW(i,2) eachPlannedTW(i,3) number]];
                        else %�����м�
                            obj.AllNodeTW{eachPlannedTW(i,1),1} = [obj.AllNodeTW{eachPlannedTW(i,1),1}(1:(eachPlannedTW(i,4)-1),:);[eachPlannedTW(i,2) eachPlannedTW(i,3) number];obj.AllNodeTW{eachPlannedTW(i,1),1}(eachPlannedTW(i,4):end,:)];
                        end
                    end                    
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���û���������ֲ�����·�� + �ֲ�·��TW����ʧ�ܡ�>��ͣ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if pathSearchSuccess == 0 || success == 0
                if pathSearchSuccess == 1 %�������˾ֲ�����·�������ǹ滮ʧ�ܣ���Ҫ��֮ǰɾ����TW���²���
                    for i = 1:size(deleteNodeTW,1)
                        if isempty(obj.AllNodeTW{deleteNodeTW(i,1),1}) %node������ʱ�䴰   
                            obj.AllNodeTW{deleteNodeTW(i,1),1}(1,1) = deleteNodeTW(i,2);
                            obj.AllNodeTW{deleteNodeTW(i,1),1}(1,2) = deleteNodeTW(i,3);
                            obj.AllNodeTW{deleteNodeTW(i,1),1}(1,3) = number;
                        else %node������ʱ�䴰                        
                            if deleteNodeTW(i,4) == 1 %���ڵ�һ��
                                obj.AllNodeTW{deleteNodeTW(i,1),1} = [[deleteNodeTW(i,2) deleteNodeTW(i,3) number];obj.AllNodeTW{deleteNodeTW(i,1),1}];
                            elseif deleteNodeTW(i,4) == (size(obj.AllNodeTW{deleteNodeTW(i,1),1},1) + 1) %�������һ��
                                obj.AllNodeTW{deleteNodeTW(i,1),1} = [obj.AllNodeTW{deleteNodeTW(i,1),1};[deleteNodeTW(i,2) deleteNodeTW(i,3) number]];
                            else %�����м�
                                obj.AllNodeTW{deleteNodeTW(i,1),1} = [obj.AllNodeTW{deleteNodeTW(i,1),1}(1:(deleteNodeTW(i,4)-1),:);[deleteNodeTW(i,2) deleteNodeTW(i,3) number];obj.AllNodeTW{deleteNodeTW(i,1),1}(deleteNodeTW(i,4):end,:)];
                            end   
                        end
                    end
                end
                nowNodeIndex = find(obj.AllRobotTW{number,1}(:,1) == obj.RobotArray(number,1).getNode());
                failureNodeIndex = find(obj.AllRobotTW{number,1}(:,1) == obj.RobotArray(obj.FailureRobotNum,1).getNode());
                tempDepotIndex = 0; %��¼��·���ϵڼ�����������ʱͣ����
                tempDepotNode = 0; %��¼��ʱͣ����
                for i = nowNodeIndex:failureNodeIndex-1
                    node = obj.AllRobotTW{number,1}(i,1);
                    r = obj.NodeCoordinate(node,2);
                    c = obj.NodeCoordinate(node,3);
                    if obj.MapSignalNode(r-1,c) == 1 || obj.MapSignalNode(r+1,c) == 1 %��ǰ���ں��ŵ������
                        if obj.MapSignalNode(r-1,c) == 1 && obj.MapSignalNode(r+1,c) == 1 %���¶��л���
                            depotNode1 = obj.MapNode(r-1,c); %�ϻ��ܵ�
                            depotNode2 = obj.MapNode(r+1,c); %�»��ܵ�
                            depotNodeIndex1 = find(obj.DepotNodeOccupancy(:,1) == depotNode1);
                            depotNodeIndex2 = find(obj.DepotNodeOccupancy(:,1) == depotNode2);
                            tempDepotSuccess = 0; %��¼��Χ�Ļ��ܵ��ܷ��Ϊ��ʱͣ����
                            if obj.DepotNodeOccupancy(depotNodeIndex1,2) == 0 %���жϵ�һ�����ܵ��ܷ�ͣ��
                                tempDepotSuccess = 1;
                                tempDepotIndex = i;
                                tempDepotNode = depotNode1;
                                for j = 1:obj.TotalRobotNumber
                                    if obj.RobotArray(j,1).taskEndNode == depotNode1
                                        tempDepotSuccess = 0;
                                    end
                                end
                            end
                            if tempDepotSuccess == 0 %����һ�����ܵ㲻����Ϊͣ���㣬�жϵڶ������ܵ�
                                if obj.DepotNodeOccupancy(depotNodeIndex2,2) == 0
                                    tempDepotSuccess = 1;
                                    tempDepotIndex = i;
                                    tempDepotNode = depotNode2;                                    
                                    for j = 1:obj.TotalRobotNumber
                                        if obj.RobotArray(j,1).taskEndNode == depotNode2
                                            tempDepotSuccess = 0;
                                        end
                                    end                                    
                                end
                            end
                            if tempDepotSuccess == 1 %��·������Χ�Ļ��ܵ������Ϊ��ʱͣ����
                                break;
                            else %����ʱͣ����
                                continue;
                            end
                        elseif obj.MapSignalNode(r-1,c) == 1 && obj.MapSignalNode(r+1,c) ~= 1 %ֻ�������л���
                            depotNode = obj.MapNode(r-1,c);
                            depotNodeIndex = find(obj.DepotNodeOccupancy(:,1) == depotNode);
                            tempDepotSuccess = 0; %��¼��Χ�Ļ��ܵ��ܷ��Ϊ��ʱͣ����
                            if obj.DepotNodeOccupancy(depotNodeIndex,2) == 0
                                tempDepotSuccess = 1;
                                tempDepotIndex = i;
                                tempDepotNode = depotNode;
                                for j = 1:obj.TotalRobotNumber
                                    if obj.RobotArray(j,1).taskEndNode == depotNode
                                        tempDepotSuccess = 0;
                                    end
                                end                                
                            end
                            if tempDepotSuccess == 1 %��·������Χ�Ļ��ܵ������Ϊ��ʱͣ����
                                break;
                            else %����ʱͣ����
                                continue;
                            end                            
                        elseif obj.MapSignalNode(r-1,c) ~= 1 && obj.MapSignalNode(r+1,c) == 1 %ֻ�������л���
                            depotNode = obj.MapNode(r+1,c);
                            depotNodeIndex = find(obj.DepotNodeOccupancy(:,1) == depotNode);
                            tempDepotSuccess = 0; %��¼��Χ�Ļ��ܵ��ܷ��Ϊ��ʱͣ����
                            if obj.DepotNodeOccupancy(depotNodeIndex,2) == 0
                                tempDepotSuccess = 1;
                                tempDepotIndex = i;
                                tempDepotNode = depotNode;
                                for j = 1:obj.TotalRobotNumber
                                    if obj.RobotArray(j,1).taskEndNode == depotNode
                                        tempDepotSuccess = 0;
                                    end
                                end                                
                            end
                            if tempDepotSuccess == 1 %��·������Χ�Ļ��ܵ������Ϊ��ʱͣ����
                                break;
                            else %����ʱͣ����
                                continue;
                            end                             
                        end
                    elseif obj.MapSignalNode(r,c-1) == 1 || obj.MapSignalNode(r,c+1) == 1 %��ǰ�������ŵ������
                        if obj.MapSignalNode(r,c-1) == 1 && obj.MapSignalNode(r,c+1) == 1 %���Ҷ��л���
                            depotNode1 = obj.MapNode(r,c-1); %�ϻ��ܵ�
                            depotNode2 = obj.MapNode(r,c+1); %�»��ܵ�
                            depotNodeIndex1 = find(obj.DepotNodeOccupancy(:,1) == depotNode1);
                            depotNodeIndex2 = find(obj.DepotNodeOccupancy(:,1) == depotNode2);
                            tempDepotSuccess = 0; %��¼��Χ�Ļ��ܵ��ܷ��Ϊ��ʱͣ����
                            if obj.DepotNodeOccupancy(depotNodeIndex1,2) == 0 %���жϵ�һ�����ܵ��ܷ�ͣ��
                                tempDepotSuccess = 1;
                                tempDepotIndex = i;
                                tempDepotNode = depotNode1;
                                for j = 1:obj.TotalRobotNumber
                                    if obj.RobotArray(j,1).taskEndNode == depotNode1
                                        tempDepotSuccess = 0;
                                    end
                                end
                            end
                            if tempDepotSuccess == 0 %����һ�����ܵ㲻����Ϊͣ���㣬�жϵڶ������ܵ�
                                if obj.DepotNodeOccupancy(depotNodeIndex2,2) == 0
                                    tempDepotSuccess = 1;
                                    tempDepotIndex = i;
                                    tempDepotNode = depotNode2;                                    
                                    for j = 1:obj.TotalRobotNumber
                                        if obj.RobotArray(j,1).taskEndNode == depotNode2
                                            tempDepotSuccess = 0;
                                        end
                                    end                                    
                                end
                            end
                            if tempDepotSuccess == 1 %��·������Χ�Ļ��ܵ������Ϊ��ʱͣ����
                                break;
                            else %����ʱͣ����
                                continue;
                            end                            
                        elseif obj.MapSignalNode(r,c-1) == 1 && obj.MapSignalNode(r,c+1) ~= 1 %ֻ������л���
                            depotNode = obj.MapNode(r,c-1);
                            depotNodeIndex = find(obj.DepotNodeOccupancy(:,1) == depotNode);
                            tempDepotSuccess = 0; %��¼��Χ�Ļ��ܵ��ܷ��Ϊ��ʱͣ����
                            if obj.DepotNodeOccupancy(depotNodeIndex,2) == 0
                                tempDepotSuccess = 1;
                                tempDepotIndex = i;
                                tempDepotNode = depotNode;
                                for j = 1:obj.TotalRobotNumber
                                    if obj.RobotArray(j,1).taskEndNode == depotNode
                                        tempDepotSuccess = 0;
                                    end
                                end                                
                            end
                            if tempDepotSuccess == 1 %��·������Χ�Ļ��ܵ������Ϊ��ʱͣ����
                                break;
                            else %����ʱͣ����
                                continue;
                            end                               
                        elseif obj.MapSignalNode(r,c-1) ~= 1 && obj.MapSignalNode(r,c+1) == 1 %ֻ���ұ��л���
                            depotNode = obj.MapNode(r,c+1);
                            depotNodeIndex = find(obj.DepotNodeOccupancy(:,1) == depotNode);
                            tempDepotSuccess = 0; %��¼��Χ�Ļ��ܵ��ܷ��Ϊ��ʱͣ����
                            if obj.DepotNodeOccupancy(depotNodeIndex,2) == 0
                                tempDepotSuccess = 1;
                                tempDepotIndex = i;
                                tempDepotNode = depotNode;
                                for j = 1:obj.TotalRobotNumber
                                    if obj.RobotArray(j,1).taskEndNode == depotNode
                                        tempDepotSuccess = 0;
                                    end
                                end                                
                            end
                            if tempDepotSuccess == 1 %��·������Χ�Ļ��ܵ������Ϊ��ʱͣ����
                                break;
                            else %����ʱͣ����
                                continue;
                            end                             
                        end
                    end
                end
                %��ʱͣ����Ȩ��ռ��
                obj.DepotNodeOccupancy(find(obj.DepotNodeOccupancy(:,1) == tempDepotNode),2) = 1;
                obj.DepotNodeOccupancy(find(obj.DepotNodeOccupancy(:,1) == tempDepotNode),3) = number;
                %ɾ��obj.AllRobotTW{number,1}��obj.AllNodeTW��tempDepotIndex���TW
                for i = tempDepotIndex+1:size(obj.AllRobotTW{number,1},1)
                    deleteNode = obj.AllRobotTW{number,1}(i,1);
                    t1 = obj.AllRobotTW{number,1}(i,2);
                    t2 = obj.AllRobotTW{number,1}(i,3);
                    for j = 1:size(obj.AllNodeTW{deleteNode,1},1)
                        t3 = obj.AllNodeTW{deleteNode,1}(j,1);
                        t4 = obj.AllNodeTW{deleteNode,1}(j,2);
                        if t1 == t3 && t2 == t4 && obj.AllNodeTW{deleteNode,1}(j,3) == number
                            obj.AllNodeTW{deleteNode,1}(j,:) = [];
                            break;
                        end
                    end
                end
                obj.AllRobotTW{number,1}(tempDepotIndex+1:size(obj.AllRobotTW{number,1},1),:) = [];
                %�ѽ�����ʱͣ����֮ǰ�����·�����TW������Ϊ1����������ʱͣ�����TW
                beforeDepotNode = obj.AllRobotTW{number,1}(end,1); %������ʱͣ����֮ǰ�����·����
                for i = 1:size(obj.AllNodeTW{beforeDepotNode,1},1)
                    endT1 = obj.AllRobotTW{number,1}(end,2);
                    endT2 = obj.AllRobotTW{number,1}(end,3);
                    endT3 = obj.AllNodeTW{beforeDepotNode,1}(i,1);
                    endT4 = obj.AllNodeTW{beforeDepotNode,1}(i,2);
                    if endT1 == endT3 && endT2 == endT4 && obj.AllNodeTW{beforeDepotNode,1}(i,3) == number
                        obj.AllNodeTW{beforeDepotNode,1}(i,2) = obj.AllNodeTW{beforeDepotNode,1}(i,1);
                        obj.AllRobotTW{number,1}(end,3) = obj.AllRobotTW{number,1}(end,2);
                        break;
                    end
                end
                Row = size(obj.AllRobotTW{number,1},1);
                obj.AllRobotTW{number,1}(Row+1,1) = tempDepotNode;
                obj.AllRobotTW{number,1}(Row+1,2) = obj.AllRobotTW{number,1}(Row,2) + 1;
                obj.AllRobotTW{number,1}(Row+1,3) = obj.AllRobotTW{number,1}(Row,2) + 1;
                Row = size(obj.AllNodeTW{tempDepotNode,1},1);
                obj.AllNodeTW{tempDepotNode,1}(Row+1,1) = obj.AllRobotTW{number,1}(end,2);
                obj.AllNodeTW{tempDepotNode,1}(Row+1,2) = obj.AllRobotTW{number,1}(end,3);
                obj.AllNodeTW{tempDepotNode,1}(Row+1,3) = number;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        
        %�ֲ�ʱ�䴰����
        function [InsertedTW, pathPlanSuccess] = localTWInsert(obj,number,InitializedTW,InsertedTW,StartTime,EndTime,pathNodeIndex,nodeOverlapIndex)
            pathPlanSuccess = 1;
            if pathNodeIndex == 0 %���β���
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��ȷ�����һ�����ʱ�䴰�ܷ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                endNode = InitializedTW(end,1);
                endNodeSuccess = 0;
                if size(obj.AllNodeTW{endNode,1},1) == 0 %endNode��û��һ��ʱ�䴰
                    endNodeSuccess = 1;
                    InsertedTW(end,1) = endNode;
                    InsertedTW(end,2) = EndTime;
                    InsertedTW(end,3) = EndTime;
                    InsertedTW(end,4) = 1;
                elseif size(obj.AllNodeTW{endNode,1},1) == 1 %endNode��ֻ��һ��ʱ�䴰
                    if obj.AllNodeTW{endNode,1}(1,1) - EndTime > 1 %���һ��������EndTime��Ҫ���Ҳ��ڵ�һ��
                        endNodeSuccess = 1;
                        InsertedTW(end,1) = endNode;
                        InsertedTW(end,2) = EndTime;
                        InsertedTW(end,3) = EndTime;
                        InsertedTW(end,4) = 1;                        
                    elseif EndTime - obj.AllNodeTW{endNode,1}(1,2) > 1 %���һ��������EndTime��Ҫ���Ҳ��ڵڶ���
                        endNodeSuccess = 1;
                        InsertedTW(end,1) = endNode;
                        InsertedTW(end,2) = EndTime;
                        InsertedTW(end,3) = EndTime;
                        InsertedTW(end,4) = 2;                         
                    else %������EndTime��Ҫ���޷�����
                        pathPlanSuccess = 0;
                    end
                else %endNode������������ʱ�䴰
                    if obj.AllNodeTW{endNode,1}(1,1) - EndTime > 1 %���һ��������EndTime��Ҫ���Ҳ��ڵ�һ��
                        endNodeSuccess = 1;
                        InsertedTW(end,1) = endNode;
                        InsertedTW(end,2) = EndTime;
                        InsertedTW(end,3) = EndTime;
                        InsertedTW(end,4) = 1;                         
                    elseif EndTime - obj.AllNodeTW{endNode,1}(end,2) > 1 %���һ��������EndTime��Ҫ���Ҳ������һ��
                        endNodeSuccess = 1;
                        InsertedTW(end,1) = endNode;
                        InsertedTW(end,2) = EndTime;
                        InsertedTW(end,3) = EndTime;
                        InsertedTW(end,4) = size(obj.AllNodeTW{endNode,1},1) + 1;                             
                    else %���ܿ��Բ����м�����ʱ�䴰֮��
                        for i = 1:size(obj.AllNodeTW{endNode,1},1)-1
                            t1 = obj.AllNodeTW{endNode,1}(i,2);
                            t2 = obj.AllNodeTW{endNode,1}(i+1,1);
                            if t2 - t1 > 3 && EndTime > (t1+1) && EndTime < (t2-1) %���Բ��ڵ�i�κ�
                                endNodeSuccess = 1;
                                InsertedTW(end,1) = endNode;
                                InsertedTW(end,2) = EndTime;
                                InsertedTW(end,3) = EndTime;
                                InsertedTW(end,4) = i + 1;                                
                            end
                        end
                    end
                end
                if endNodeSuccess == 0 %���һ��������������㣬ʱ�䴰�޷�����
                    pathPlanSuccess = 0;
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����Ĳ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if endNodeSuccess == 1 %�����һ����ɹ����룬�ſɼ������к��������Ĳ���
                    for i = 1:size(InitializedTW,1)-1 %�ֲ�����·����һ���㵽�����ڶ�����
                        if i == 1 %����ǵ�һ����
                            firstNode = InitializedTW(1,1);
                            InsertedTW(1,1) = firstNode;
                            InsertedTW(1,2) = StartTime;
                            InsertedTW(1,3) = StartTime;
                            if size(obj.AllNodeTW{firstNode,1},1) == 0 %firstNode��û��ʱ�䴰
                                InsertedTW(1,4) = 1;
                            elseif size(obj.AllNodeTW{firstNode,1},1) == 1 %firstNode��ֻ��һ��ʱ�䴰
                                if obj.AllNodeTW{firstNode,1}(1,1) - StartTime > 1 %���ڵ�һ��
                                    InsertedTW(1,4) = 1;                        
                                elseif StartTime - obj.AllNodeTW{firstNode,1}(1,2) > 1 %���ڵڶ���
                                    InsertedTW(1,4) = 2;                         
                                end                                
                            else %firstNode������������ʱ�䴰
                                if obj.AllNodeTW{firstNode,1}(1,1) - StartTime > 1 % ���Բ��ڵ�һ��λ��
                                    InsertedTW(1,4) = 1;
                                elseif StartTime - obj.AllNodeTW{firstNode,1}(end,2) > 1 %���Բ������
                                    InsertedTW(1,4) = size(obj.AllNodeTW{firstNode,1},1) + 1;
                                else %���ܿ��Բ����м��ʱ�䴰�յ���
                                    success = 0;
                                    for j = 1:size(obj.AllNodeTW{firstNode,1},1)-1
                                        t1 = obj.AllNodeTW{firstNode,1}(j,2);
                                        t2 = obj.AllNodeTW{firstNode,1}(j+1,1);
                                        if t2 - t1 > 3 && StartTime > (t1+1) && StartTime < (t2-1) %���Բ��ڵ�j�κ�
                                            InsertedTW(1,4) = j + 1;    
                                            success = 1;
                                        end                                    
                                    end          
                                    if success == 0 %ֻ�ܲ嵽���
                                        InsertedTW(1,4) = size(obj.AllNodeTW{firstNode,1},1) + 1;
                                    end
                                end
                            end
                        else %����ǵڶ��㡪�������ڶ�����
                            node = InitializedTW(i,1);
                            lastNodeEndT = InsertedTW(i-1,3);
                            if size(obj.AllNodeTW{node,1},1) == 0 %node��û��ʱ�䴰
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndT + 1;
                                InsertedTW(i,3) = lastNodeEndT + 1;
                                InsertedTW(i,4) = 1;
                            elseif size(obj.AllNodeTW{node,1},1) == 1 %node��ֻ��һ��ʱ�䴰
                                if obj.AllNodeTW{node,1}(1,1) - lastNodeEndT > 2 %����Ψһһ��ʱ�䴰֮ǰ
                                    InsertedTW(i,1) = node;
                                    InsertedTW(i,2) = lastNodeEndT + 1;
                                    InsertedTW(i,3) = lastNodeEndT + 1;
                                    InsertedTW(i,4) = 1;                                    
                                else %����Ψһһ��ʱ�䴰֮��
                                    if lastNodeEndT < obj.AllNodeTW{node,1}(1,2) || lastNodeEndT == obj.AllNodeTW{node,1}(1,2) %��obj.AllNodeTW{node,1}(1,2)Ϊ��׼
                                        InsertedTW(i,1) = node;
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(1,2) + 2;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(1,2) + 2;
                                        InsertedTW(i,4) = 2;                                          
                                    else %��lastNodeEndTΪ��׼
                                        InsertedTW(i,1) = node;
                                        InsertedTW(i,2) = lastNodeEndT + 1;
                                        InsertedTW(i,3) = lastNodeEndT + 1;
                                        InsertedTW(i,4) = 2;                                             
                                    end
                                end
                            else %node������������ʱ�䴰
                                if obj.AllNodeTW{node,1}(1,1) - lastNodeEndT > 2 %���ڵ�һ��
                                    InsertedTW(i,1) = node;
                                    InsertedTW(i,2) = lastNodeEndT + 1;
                                    InsertedTW(i,3) = lastNodeEndT + 1;
                                    InsertedTW(i,4) = 1;                                      
                                elseif lastNodeEndT > (obj.AllNodeTW{node,1}(end,1) - 3) %�������һ��
                                    InsertedTW(i,1) = node;
                                    InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;
                                    if lastNodeEndT > obj.AllNodeTW{node,1}(end,2) %��lastNodeEndT��Ϊ��׼
                                        InsertedTW(i,2) = lastNodeEndT + 1;
                                        InsertedTW(i,3) = lastNodeEndT + 1;                                        
                                    else %��obj.AllNodeTW{node,1}(end,2)��Ϊ��׼
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(end,2) + 2;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(end,2) + 2;                                          
                                    end
                                else %���ܿ��Բ����м��ʱ�䴰�յ���
                                    success = 0;
                                    for j = 1:size(obj.AllNodeTW{node,1},1)-1
                                        if lastNodeEndT > obj.AllNodeTW{node,1}(j,2)
                                            if obj.AllNodeTW{node,1}(j+1,1) - lastNodeEndT > 2 %���Բ��ڵ�j�κ�
                                                InsertedTW(i,1) = node;
                                                InsertedTW(i,2) = lastNodeEndT + 1;
                                                InsertedTW(i,3) = lastNodeEndT + 1;
                                                InsertedTW(i,4) = j + 1;    
                                                success = 1;
                                                break;
                                            end
                                        else
                                            if obj.AllNodeTW{node,1}(j+1,1) - obj.AllNodeTW{node,1}(j,2) > 3 %���Բ��ڵ�j�κ�
                                                InsertedTW(i,1) = node;
                                                InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 2;
                                                InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 2;
                                                InsertedTW(i,4) = j + 1;   
                                                success = 1;
                                                break;                                                
                                            end
                                        end
                                    end
                                    if success == 0 %ֻ�ܲ������
                                        InsertedTW(i,1) = node;
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(end,2) + 2;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(end,2) + 2;
                                        InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                           
                                    end
                                end
                            end
                        end
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            else %���ǳ��β��룬֮ǰ�滮ʱ������TW����
                endNodeSuccess = 1;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%��pathNodeIndex�������ڶ�������InsertedTW�ж�Ӧ�Ĳ������%%%%%%%%%%%%%%%%%%%%%%%%%%
                for i = pathNodeIndex:size(InsertedTW,1)-1
                    for j = 1:4
                        InsertedTW(i,j) = 0;
                    end
                end
                %��InsertedTW���һ����Ľ���ʱ����Ϊ�õ���뿪ʱ��
                InsertedTW(end,2) = InsertedTW(end,3);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                for i = pathNodeIndex:size(InsertedTW,1)-1
                    node = InitializedTW(i,1);
                    lastNodeEndTime = InsertedTW(i-1,3);                 
                    if i == pathNodeIndex %ʱ�䴰�н�����Ǹ���,����nodeOverlapIndex���в���
                        if nodeOverlapIndex == size(obj.AllNodeTW{node,1},1) %���������һ��
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(end,2) + 2;
                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(end,2) + 2;
                            InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                             
                        else
                            success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                            for j = nodeOverlapIndex:(size(obj.AllNodeTW{node,1},1)-1) 
                                if (obj.AllNodeTW{node,1}(j+1,1) - obj.AllNodeTW{node,1}(j,2)) > 3 %���ڵ�j��ʱ�䴰֮��
                                    InsertedTW(i,1) = node;
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 2;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 2;
                                    InsertedTW(i,4) = j + 1;  
                                    success = 1;
                                    break;
                                end                                        
                            end
                            if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(end,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(end,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(end,2) + 2;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(end,2) + 2;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + 1;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                
                            end                            
                        end
                    else %·�������ϵ�һ����֮��
                        if size(obj.AllNodeTW{node,1},1) == 0 %node�ϻ�û���κ�ʱ�䴰
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = lastNodeEndTime + 1;
                            InsertedTW(i,3) = lastNodeEndTime + 1;
                            InsertedTW(i,4) = 1;                        
                        elseif size(obj.AllNodeTW{node,1},1) == 1 %node��ֻ��һ��ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - lastNodeEndTime) > 2 %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + 1;
                                InsertedTW(i,4) = 1;                             
                            else %���ڵ�һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(1,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(1,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(1,2) + 2;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(1,2) + 2;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + 1;                                    
                                end
                                InsertedTW(i,4) = 2;                                  
                            end
                        else %node������������ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - lastNodeEndTime) > 2 %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + 1;
                                InsertedTW(i,4) = 1;                            
                            elseif lastNodeEndTime > obj.AllNodeTW{node,1}(end,1) - 3 %�������һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(end,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(end,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(end,2) + 2;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(end,2) + 2;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + 1;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                              
                            else
                                success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                                for j = 1:(size(obj.AllNodeTW{node,1},1)-1) 
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(j,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(j,2) %��node�ϵ�j��ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - obj.AllNodeTW{node,1}(j,2)) > 3 %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 2;
                                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 2;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - lastNodeEndTime) > 2 %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = lastNodeEndTime + 1;
                                            InsertedTW(i,3) = lastNodeEndTime + 1;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    end
                                end
                                if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                    InsertedTW(i,1) = node;
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(end,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(end,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(end,2) + 2;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(end,2) + 2;
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = lastNodeEndTime + 1;
                                        InsertedTW(i,3) = lastNodeEndTime + 1;                                       
                                    end
                                    InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                   
                                end
                            end
                        end
                    end
                end
            end
            if endNodeSuccess == 1
                while pathPlanSuccess == 1
                    if InsertedTW(end,2) < InsertedTW(end-1,3) || InsertedTW(end,2) == InsertedTW(end-1,3) %�����ڶ���ʱ�䴰���뿪ʱ����ڵ������һ��ʱ�䴰�Ľ���ʱ��
                        pathPlanSuccess = 0;
                    else %�����ڶ���ʱ�䴰�����һ��ʱ�䴰û�н���
                        node1 = InsertedTW(end-1,1); %�����ڶ����ڵ�
                        index1 = InsertedTW(end-1,4); %�����ڶ����ڵ�Ҫ�����λ��
                        node2 = InsertedTW(end,1); %���һ���ڵ�
                        index2 = InsertedTW(end,4); %���һ���ڵ�Ҫ�����λ��
                        if index1 == (size(obj.AllNodeTW{node1,1},1) + 1) || index2 == 1 %�����ڶ����ڵ��TW������󣬻������һ���ڵ��TW���ڵ�һ��
                            break; %����ѭ��������TW����
                        else %�����ڶ����ڵ��TW���ǲ�����󣬲������һ���ڵ��TW���ǲ��ڵ�һ��
                            if obj.AllNodeTW{node1,1}(index1,1) - obj.AllNodeTW{node2,1}(index2-1,2) > 2 %�����ڶ���������һ��������TW�����λ�ÿ�������
                                break; %����ѭ��������TW����
                            else %�����ڶ���������һ��������TW�����λ�ò���������,�����ڶ������TW����Ѱ�Ҳ���λ��
                                if index1 == size(obj.AllNodeTW{node1,1},1)  %�����ڶ������TW�����λ�ú�ֻ��һ��ʱ�䴰
                                    InsertedTW(end-1,2) = obj.AllNodeTW{node1,1}(end,2) + 2;
                                    InsertedTW(end-1,3) = obj.AllNodeTW{node1,1}(end,2) + 2;
                                    InsertedTW(end-1,4) = size(obj.AllNodeTW{node1,1},1) + 1;
                                else %�����ڶ������TW�����λ�ú�����������ʱ�䴰
                                    success = 0;
                                    for i = index1:size(obj.AllNodeTW{node1,1},1)-1
                                        if obj.AllNodeTW{node1,1}(i+1,1) - obj.AllNodeTW{node1,1}(i,2) > 3 %���Բ��ڵ�i�κ�
                                            InsertedTW(end-1,2) = obj.AllNodeTW{node1,1}(i,2) + 2;
                                            InsertedTW(end-1,3) = obj.AllNodeTW{node1,1}(i,2) + 2;
                                            InsertedTW(end-1,4) = i + 1;       
                                            success = 1;
                                            break;
                                        end
                                    end
                                    if success == 0
                                        InsertedTW(end-1,2) = obj.AllNodeTW{node1,1}(end,2) + 2;
                                        InsertedTW(end-1,3) = obj.AllNodeTW{node1,1}(end,2) + 2;
                                        InsertedTW(end-1,4) = size(obj.AllNodeTW{node1,1},1) + 1;                                         
                                    end
                                end
                            end
                        end
                    end                    
                end
            end
        end
        
        %�ֲ�ʱ�䴰����
        function ConnectedTW = localTWConnect(obj,InsertedTW)
            ConnectedTW = zeros(size(InsertedTW,1),4);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�Ƚ��ֲ�·���ĵ�һ����������������������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(InsertedTW,1)-2
                ConnectedTW(i,1) = InsertedTW(i,1);
                ConnectedTW(i,2) = InsertedTW(i,2);
                ConnectedTW(i,3) = InsertedTW(i+1,2) - 1;
                ConnectedTW(i,4) = InsertedTW(i,4);                
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�������ڶ���������һ��������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if InsertedTW(end,4) == 1 %���һ�����TW����λ���ǵ�һ��������������ǰ�ӳ�
                ConnectedTW(end-1,1) = InsertedTW(end-1,1);
                ConnectedTW(end-1,2) = InsertedTW(end-1,2);
                ConnectedTW(end-1,3) = InsertedTW(end-1,3);
                ConnectedTW(end-1,4) = InsertedTW(end-1,4); 
                ConnectedTW(end,1) = InsertedTW(end,1);
                ConnectedTW(end,2) = InsertedTW(end-1,3) + 1;
                ConnectedTW(end,3) = InsertedTW(end,3);
                ConnectedTW(end,4) = InsertedTW(end,4);                 
            else %���һ�����TW����λ�ò��ǵ�һ����������������ǰ�ӳ�
                endNode = InsertedTW(end,1);
                endInsertIndex = InsertedTW(end,4);
                if (InsertedTW(end-1,3) + 1) > obj.AllNodeTW{endNode,1}(endInsertIndex-1,2) + 1 %���һ�����TW��ǰ�ӳ�
                    ConnectedTW(end-1,1) = InsertedTW(end-1,1);
                    ConnectedTW(end-1,2) = InsertedTW(end-1,2);
                    ConnectedTW(end-1,3) = InsertedTW(end-1,3);
                    ConnectedTW(end-1,4) = InsertedTW(end-1,4); 
                    ConnectedTW(end,1) = InsertedTW(end,1);
                    ConnectedTW(end,2) = InsertedTW(end-1,3) + 1;
                    ConnectedTW(end,3) = InsertedTW(end,3);
                    ConnectedTW(end,4) = InsertedTW(end,4);                      
                else %���һ�����TW��ǰ�ӳ��������ڶ����TW�����ӳ�
                    T = obj.AllNodeTW{endNode,1}(endInsertIndex-1,2); %���һ����TW������λ�õ�ǰһ��TW���뿪ʱ��
                    ConnectedTW(end-1,1) = InsertedTW(end-1,1);
                    ConnectedTW(end-1,2) = InsertedTW(end-1,2);
                    ConnectedTW(end-1,3) = T + 1;
                    ConnectedTW(end-1,4) = InsertedTW(end-1,4);                      
                    ConnectedTW(end,1) = InsertedTW(end,1);
                    ConnectedTW(end,2) = T + 2;
                    ConnectedTW(end,3) = InsertedTW(end,3);
                    ConnectedTW(end,4) = InsertedTW(end,4);                       
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        
        %�ֲ�ʱ�䴰������
        function [pathPlanSuccess, planSuccess, pathNodeIndex, nodeOverlapIndex,eachPlannedTW] = localTWOverlapDetect(obj,number,ConnectedTW)
            success = 1;%��¼�Ƿ���ʱ�䴰���棬0-�н��棬1-û�н���
            pathPlanSuccess = 1;
            eachPlannedTW = zeros(size(ConnectedTW,1),4);
            for i = 1:(size(ConnectedTW,1)-2)
                node = ConnectedTW(i,1);
                t1 = ConnectedTW(i,2);
                t2 = ConnectedTW(i,3);
                try
                    xxx = size(obj.AllNodeTW{node,1},1);
                catch
                    disp('localTWOverlapDetect');
                    disp(obj.RobotArray(number,1).getNode());
                    disp(obj.RobotArray(number,1).taskStartNode);
                    disp(obj.RobotArray(number,1).taskEndNode);
                    disp(i);
                    disp(node);
                    disp(ConnectedTW);
                end
                if size(obj.AllNodeTW{node,1},1) == 0 %node��û��ʱ�䴰����
                    continue;
                else %node����ʱ�䴰����
                    for j = size(obj.AllNodeTW{node,1},1):-1:1
                        t3 = obj.AllNodeTW{node,1}(j,1);
                        t4 = obj.AllNodeTW{node,1}(j,2);
                        if ((t1<=t3)&&(t2>=t3)) || ((t2>=t4)&&(t1<=t4)) %ʱ�䴰���ڽ���
                            success = 0;
                            planSuccess = 0;
                            pathNodeIndex = i;
                            nodeOverlapIndex = j;
                            break;
                        end
                    end
                end                 
                if success == 0 %�Ѽ�⵽ʱ�䴰����
                    break;
                end
            end
            
            if success == 1 %ȫ�����һ�飬����ʱ�䴰û�н���
                planSuccess = 1;
                pathNodeIndex = 0;
                nodeOverlapIndex = 0;
                for i = 1:size(ConnectedTW,1)
                    for j = 1:4
                        eachPlannedTW(i,j) = ConnectedTW(i,j);
                    end
                end
            end      
            if pathNodeIndex == 1 %�����⵽�Ľ���TW�ǵ�һ���㣬˵�������ֲ�·����TW�滮���ɹ�
                pathPlanSuccess = 0;
            end                
        end
        
        %��ʧЧ�����˻ָ��������������ô�ʱ�䴰�滮�㷨����֮ǰ��TW�㷨����һ����ϸ�����в�ͬ
        function failureRobotReplan(obj,Number,Time,StartNode,EndNode,order) %StartNode-ʧЧ�����˵�ǰλ������Ļ��ܵ㣬EndNode-ʧЧ������������Ҫǰ����ȡ����/�Ż���
            kPlannedResult = []; %��ʱ�洢K�����·���Ĺ滮������Ż�ʱ��
            kShortestPaths = [];            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����ʱ�øò��ִ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %�滮��ʧЧ�����˵�ǰ�ڵ�ǰ��ȡ����/���ܵ��·����ֻ�����������������ڽڵ� + �ڽӾ���ڵ㣩
            if order == 1 %����������Ҫȥ�����ܵ�
                index1 = find(obj.DepotNearCrossNode(:,1) == StartNode);
                index2 = find(obj.DepotNearCrossNode(:,1) == EndNode);
                node1 = obj.DepotNearCrossNode(index1,2);
                node2 = obj.DepotNearCrossNode(index1,3);
                node3 = obj.DepotNearCrossNode(index2,2);
                node4 = obj.DepotNearCrossNode(index2,3);                
                if node1 == node3 && node2 == node4 %�����˵�ǰλ����Ҫǰ���Ļ��ܵ���ͬһ�����
                    r = obj.NodeCoordinate(EndNode,2);
                    c = obj.NodeCoordinate(EndNode,3);
                    if obj.MapSignalNode(r-1,c) == 1 %������һ��
                        middleNode = obj.MapNode(r+1,c);
                    else %������һ��
                        middleNode = obj.MapNode(r-1,c);
                    end
                    if middleNode == obj.RobotArray(obj.FailureRobotNum,1).getNode() %���ʧЧ�����˵�ǰλ�õ����������ܵ��Ե������
                        kShortestPaths{1,1}(1,1) = obj.RobotArray(obj.FailureRobotNum,1).getNode();
                        kShortestPaths{1,1}(1,2) = EndNode;
                    else %���ʧЧ�����˵�ǰλ�õ㲻��������ܵ��Ե������
                        kShortestPaths{1,1}(1,1) = obj.RobotArray(obj.FailureRobotNum,1).getNode();
                        kShortestPaths{1,1}(1,2) = middleNode;
                        kShortestPaths{1,1}(1,3) = EndNode;
                    end
                else %�����˵�ǰλ����Ҫǰ���Ļ��ܵ㲻��ͬһ�����
                    %����K���·��
                    column = obj.DepotNearCrossNode(:,1);
                    index = find(column == EndNode);
                    crossNode1 = obj.DepotNearCrossNode(index,2);
                    crossNode2 = obj.DepotNearCrossNode(index,3);
                    Index = find(obj.DepotNearCrossNode(:,1) == StartNode);
                    if obj.NodeCoordinate(StartNode,3) < obj.NodeCoordinate(EndNode,3) %ѡ�ұߵĽ���ڽڵ�
                        sourceNode = obj.DepotNearCrossNode(Index,3);
                    else
                        sourceNode = obj.DepotNearCrossNode(Index,2); %ѡ��ߵĽ���ڽڵ�
                    end
                    %������ʧЧ�����˵�ǰλ������Ľ���ڽڵ� �Ƿ���� ���ܵ㸽���Ľ���ڽڵ�
                    if sourceNode == crossNode1
                        [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, sourceNode, crossNode2, 0, EndNode, 5, 5);
                        for i = 1:size(shortestPaths,2)
                            shortestPaths{1,i} = [obj.RobotArray(obj.FailureRobotNum,1).getNode() shortestPaths{1,i}];
                        end                        
                        r = obj.NodeCoordinate(EndNode,2);
                        c = obj.NodeCoordinate(EndNode,3);
                        if obj.MapSignalNode(r-1,c) == 1 %������һ��
                            middleNode = obj.MapNode(r+1,c);
                        else %������һ��
                            middleNode = obj.MapNode(r-1,c);
                        end      
                        Column = size(shortestPaths,2);                        
                        shortestPaths{1,Column+1}(1,1) = obj.RobotArray(obj.FailureRobotNum,1).getNode();
                        shortestPaths{1,Column+1}(1,2) = sourceNode;
                        shortestPaths{1,Column+1}(1,3) = middleNode;
                        shortestPaths{1,Column+1}(1,4) = EndNode;
                    elseif sourceNode == crossNode2
                        [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, sourceNode, crossNode1, 0, EndNode, 5, 5);
                        for i = 1:size(shortestPaths,2)
                            shortestPaths{1,i} = [obj.RobotArray(obj.FailureRobotNum,1).getNode() shortestPaths{1,i}];
                        end
                        r = obj.NodeCoordinate(EndNode,2);
                        c = obj.NodeCoordinate(EndNode,3);
                        if obj.MapSignalNode(r-1,c) == 1 %������һ��
                            middleNode = obj.MapNode(r+1,c);
                        else %������һ��
                            middleNode = obj.MapNode(r-1,c);
                        end     
                        Column = size(shortestPaths,2);
                        shortestPaths{1,Column+1}(1,1) = obj.RobotArray(obj.FailureRobotNum,1).getNode();
                        shortestPaths{1,Column+1}(1,2) = sourceNode;
                        shortestPaths{1,Column+1}(1,3) = middleNode;
                        shortestPaths{1,Column+1}(1,4) = EndNode;                        
                    else %sourceNode��crossNode1��crossNode2�������
                        [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, sourceNode, crossNode1, crossNode2, EndNode, 5, 5);
                        for i = 1:size(shortestPaths,2)
                            shortestPaths{1,i} = [obj.RobotArray(obj.FailureRobotNum,1).getNode() shortestPaths{1,i}];
                        end                        
                    end
                    kShortestPaths = shortestPaths;                      
                end
            elseif order == -1 %����������Ҫȥ��ȡ����
                %����K���·��
                column = obj.DepotNearCrossNode(:,1);
                index = find(column == StartNode);
                crossNode1 = obj.DepotNearCrossNode(index,2);
                crossNode2 = obj.DepotNearCrossNode(index,3);            
                [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, EndNode, crossNode1, crossNode2, StartNode, 5, 5);
                for i = 1:size(shortestPaths,2)
                    shortestPaths{1,i}(:,end) = [];
                end                
                kShortestPaths = shortestPaths;                 
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            for i = 1:size(kShortestPaths,2)
                disp('δ����ǰ��·���ڵ�');
                disp(kShortestPaths{1,i});
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����������·���ڵ��в���ȷ֮�������޸�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if order == 1 %ȥ���ܵ�
                for i = 1:size(kShortestPaths,2)
                    if size(kShortestPaths{1,i},2) > 3 %��·��������ɵ���Ҫ�ڵ���ڵ���4��
                        Node1 = kShortestPaths{1,i}(1,end); %ʧЧ����������λ��
                        Node2 = kShortestPaths{1,i}(1,end-2); %������3����
                        Node3 = kShortestPaths{1,i}(1,end-3); %������4����
                        if (obj.NodeCoordinate(Node1,3) - obj.NodeCoordinate(Node2,3))*(obj.NodeCoordinate(Node1,3) - obj.NodeCoordinate(Node3,3)) < 0 %node1λ��node2��node3֮��
                            kShortestPaths{1,i}(:,end-2) = [];
                        end
                    end
                end                
            elseif order == -1 %ȥȡ����
                for i = 1:size(kShortestPaths,2)
                    if size(kShortestPaths{1,i},2) > 2 %��·��������ɵ���Ҫ�ڵ���ڵ���3��
                        Node1 = kShortestPaths{1,i}(1,end); %ʧЧ����������λ��
                        Node2 = kShortestPaths{1,i}(1,end-1); %������2����
                        Node3 = kShortestPaths{1,i}(1,end-2); %������3����
                        if (obj.NodeCoordinate(Node1,3) - obj.NodeCoordinate(Node2,3))*(obj.NodeCoordinate(Node1,3) - obj.NodeCoordinate(Node3,3)) < 0 %node1λ��node2��node3֮��
                            kShortestPaths{1,i}(:,end-1) = [];
                        end
                    end
                end                
            end
            for i = 1:size(kShortestPaths,2)
                disp('�������·���ڵ�');
                disp(kShortestPaths{1,i});
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��K��·���ϵĽڵ㲹������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            kPathNode = []; %�洢K��·��������·����
            for i = 1:size(kShortestPaths,2)
                pathCrossNode = kShortestPaths{1,i}; %ÿһ��·����Ӧ����� + ����ڽڵ� + �յ�
                pathNode = []; %��¼��ǰ·���е������ڵ�
                if order == 1
                    for j = 1:(size(pathCrossNode,2)-1)
                        node1 = pathCrossNode(1,j);
                        node2 = pathCrossNode(1,j+1);
                        r1 = obj.NodeCoordinate(node1,2);
                        c1 = obj.NodeCoordinate(node1,3);
                        r2 = obj.NodeCoordinate(node2,2);
                        c2 = obj.NodeCoordinate(node2,3); 
                        pathNode(size(pathNode,1)+1,1) = node1;
                        if r1 == r2
                            deltaC = abs(c2 - c1);
                            for k = 1:(deltaC-1)
                                C = c1 + k*sign(c2-c1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(r1,C);
                            end
                        elseif c1 == c2
                            deltaR = abs(r2-r1);
                            for k = 1:(deltaR-1)
                                R = r1 + k*sign(r2-r1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(R,c1);
                            end                            
                        end
                    end   
                    pathNode(size(pathNode,1)+1,1) = pathCrossNode(1,size(pathCrossNode,2));
                elseif order == -1
                    for j = size(pathCrossNode,2):-1:2
                        node1 = pathCrossNode(1,j);
                        node2 = pathCrossNode(1,j-1);
                        r1 = obj.NodeCoordinate(node1,2);
                        c1 = obj.NodeCoordinate(node1,3);
                        r2 = obj.NodeCoordinate(node2,2);
                        c2 = obj.NodeCoordinate(node2,3);  
                        pathNode(size(pathNode,1)+1,1) = node1;
                        if r1 == r2
                            deltaC = abs(c2 - c1);
                            for k = 1:(deltaC-1)
                                C = c1 + k*sign(c2-c1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(r1,C);
                            end
                        elseif c1 == c2
                            deltaR = abs(r2-r1);
                            for k = 1:(deltaR-1)
                                R = r1 + k*sign(r2-r1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(R,c1);
                            end                            
                        end                        
                    end
                    pathNode(size(pathNode,1)+1,1) = pathCrossNode(1,1);
                end 
                kPathNode{i,1} = pathNode;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ΪK��·������ʱ�䴰%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(kPathNode,1)
                pathNode = kPathNode{i,1};
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%ʱ�䴰��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                InitializedTW = zeros(size(pathNode,1),2);
                for j = 1:size(pathNode,1)
                    if j == size(pathNode,1)
                        InitializedTW(j,1) = pathNode(j,1);
                        InitializedTW(j,2) = 3;                        
                    else
                        InitializedTW(j,1) = pathNode(j,1);
                        InitializedTW(j,2) = 1;                        
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
                plannedSuccess = 0; %��¼ĳ��path��ʱ�䴰�滮�Ƿ���ɣ�0-δ��ɣ�1-��ɣ�
                pathNodeIndex = 0;
                nodeOverlapIndex = 0;
                InsertedTW = zeros(size(InitializedTW,1),4);
                eachPlannedTW = zeros(size(InitializedTW,1),4);
                k = 1;
                while plannedSuccess == 0
                    disp('pathNodeIndex');
                    disp(pathNodeIndex);
                    disp('nodeOverlapIndex');
                    disp(nodeOverlapIndex);
                    [InsertedTW, Node, t1, t2, Index] = obj.twInsert(InitializedTW,InsertedTW,Time,order,Number,pathNodeIndex,nodeOverlapIndex);
                    ConnectedTW = obj.twConnect(InsertedTW);
                    [pathNodeIndex, nodeOverlapIndex, eachPlannedTW, plannedSuccess] = obj.twOverlapDetect(ConnectedTW);
                end
                %%%%%%%%%%%%%%%%%%%%�ѹ滮�������kPlannedResult��%%%%%%%%%%%%%%%%%%%%
                kPlannedResult{size(kPlannedResult,1)+1,1} = eachPlannedTW;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����kPlannedResult��K��·����ѡ�����Ž��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            finishT = inf;
            index = 0;
            for i = 1:size(kPlannedResult,1)
                T = kPlannedResult{i,1}(size(kPlannedResult{i,1},1),3) - kPlannedResult{i,1}(1,2) + 1;
                if T < finishT
                    finishT = T;
                    index = i;
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��������ʻ��������AllNodeTW��AllRobotTW��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            try
                plannedTW = kPlannedResult{index,1};
            catch
                disp('index');
                disp(index);
                disp(kPlannedResult{1,1});
            end
            plannedTW = kPlannedResult{index,1};
            obj.AllRobotTW{Number,1} = zeros(size(plannedTW,1),3);
            for i = 1:size(plannedTW,1)
                obj.AllRobotTW{Number,1}(i,1) = plannedTW(i,1);
                obj.AllRobotTW{Number,1}(i,2) = plannedTW(i,2);
                obj.AllRobotTW{Number,1}(i,3) = plannedTW(i,3);
                if isempty(obj.AllNodeTW{plannedTW(i,1),1}) %node������ʱ�䴰   
                    obj.AllNodeTW{plannedTW(i,1),1}(1,1) = plannedTW(i,2);
                    obj.AllNodeTW{plannedTW(i,1),1}(1,2) = plannedTW(i,3);
                    obj.AllNodeTW{plannedTW(i,1),1}(1,3) = Number;
                else %node������ʱ�䴰
%                     disp('�����˱��');
%                     disp(Number);
%                     disp(i);
%                     disp(plannedTW(i,1))
%                     disp(plannedTW(i,4));
                    if plannedTW(i,4) == 1 %���ڵ�һ��
                        obj.AllNodeTW{plannedTW(i,1),1} = [[plannedTW(i,2) plannedTW(i,3) Number];obj.AllNodeTW{plannedTW(i,1),1}];
                    elseif plannedTW(i,4) == (size(obj.AllNodeTW{plannedTW(i,1),1},1) + 1) %�������һ��
                        obj.AllNodeTW{plannedTW(i,1),1} = [obj.AllNodeTW{plannedTW(i,1),1};[plannedTW(i,2) plannedTW(i,3) Number]];
                    else %�����м�
                        obj.AllNodeTW{plannedTW(i,1),1} = [obj.AllNodeTW{plannedTW(i,1),1}(1:(plannedTW(i,4)-1),:);[plannedTW(i,2) plannedTW(i,3) Number];obj.AllNodeTW{plannedTW(i,1),1}(plannedTW(i,4):end,:)];
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
        end
        
        %����ȫ�����ˡ��ٶ�1m/s��
        function updateAllWorker(obj)           
%             obj.WorkerArrayTimer=~obj.WorkerArrayTimer;
            obj.WorkerArrayTimer = true;
            if obj.WorkerArrayTimer                
                for i = 1:obj.TotalWorkerNumber
                    %��ǰ�����˵������Ϣ��״̬��Ϣ��λ����Ϣȫ�����빤��
                    obj.WorkerArray(i,1).updateRobotInfo(obj.TotalRobotNumber,obj.AllStatus,obj.AllLocation);                    
                    obj.WorkerArray(i,1).updateLocation();
                    obj.AllWorkerLocation(i,:) = obj.WorkerArray(i,1).getLocation();
                    %����Picked��Ϣ�����ץȡ�Ļ����˶�Ӧ��������1
                    temp = obj.WorkerArray(i,1).getRobotPicked();
                    if temp ~= 0                       
                        obj.AllPickedRobotSerial(temp,1) = 1; 
                    end
                end                                
            end
        end
      
        %��ͼ������
        function plotAll(obj)
                        
            show(obj.Map);
            hold on;
            %axis([0 15.5 0 10.5]);
            axis([0 obj.AllColumn/2 0 obj.AllRow/2]);
            axis manual;
            
            tempFailureR = grid2world(obj.Map,[1 1]);
            obj.g = plot(tempFailureR(:,1),tempFailureR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8);            
 
            tempFailureR = grid2world(obj.Map,[1 1]);
            obj.m = plot(tempFailureR(:,1),tempFailureR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);        
            
            tempDelayR = grid2world(obj.Map,[1 1;1 1]);
            obj.p = plot(tempFailureR(:,1),tempFailureR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8);            
 
            tempDelayR = grid2world(obj.Map,[1 1;1 1]);
            obj.q = plot(tempFailureR(:,1),tempFailureR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
            
            tempR = obj.getAllRobotLocation();  %�ݴ����л�����λ�á�
            obj.h = plot(tempR(:,1),tempR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','g','MarkerSize',8);
 
            i = 1;
            failureNum = 0;
            
            delayExist = 0;
            
            while obj.FinishedTaskNum ~= obj.TaskAmount
                %�����񣬻����ˣ����˵Ĵ���˳���Ⱥ����״̬
                RobotAllLocation = zeros(obj.TotalRobotNumber,2);
                for j = 1:obj.TotalRobotNumber
                    RobotAllLocation(j,:) = obj.RobotArray(j,1).getLocation();
                end
                obj.LastTLocation = RobotAllLocation;

                obj.taskAllocator();
                
                if i > 20
                    if failureNum < obj.FailureNumUp && obj.Failure == 0
                        if obj.delay == 0
                            obj.robotFailurePlanning(i);
                        end
                        if obj.Failure == 1 %���ڻ�����ʧЧ
                            failureNum = failureNum + 1;
                        end
                    end
                end
                 
                if (obj.FailureTime + obj.FailureLength) == i %������ʧЧ�������ָ��ڽӾ��������滮ʧЧ������
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ָ��ڽӾ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    failureNode = obj.RobotArray(obj.FailureRobotNum,1).getNode();
                    nearDepotNode = obj.MapNode(obj.NodeCoordinate(failureNode,2)-1,obj.NodeCoordinate(failureNode,3));
                    depotIndex = find(obj.DepotNearCrossNode(:,1) == nearDepotNode);
                    node1 = obj.DepotNearCrossNode(depotIndex,2); %ʧЧ�㸽�����ڽӾ���ڵ�1
                    node2 = obj.DepotNearCrossNode(depotIndex,3); %ʧЧ�㸽�����ڽӾ���ڵ�2
                    distance = abs(obj.NodeCoordinate(node1,2) - obj.NodeCoordinate(node2,2)) + abs(obj.NodeCoordinate(node1,3) - obj.NodeCoordinate(node2,3));
                    node1Index = find(obj.AdjacentMatrixNode == node1);
                    node2Index = find(obj.AdjacentMatrixNode == node2);
                    obj.AdjacentMatrix(node1Index,node2Index) = distance;
                    obj.AdjacentMatrix(node2Index,node1Index) = distance;                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�滮ʧЧ������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if obj.AllRobotTW{obj.FailureRobotNum,1}(end,1) == obj.RobotArray(obj.FailureRobotNum,1).taskStartNode %ȥȡ����
                        order = -1;
                        startNode = nearDepotNode;
                        endNode = obj.RobotArray(obj.FailureRobotNum,1).taskStartNode;
                    elseif obj.AllRobotTW{obj.FailureRobotNum,1}(end,1) == obj.RobotArray(obj.FailureRobotNum,1).taskEndNode %ȥ���ܵ�
                        order = 1;
                        startNode = nearDepotNode;
                        endNode = obj.RobotArray(obj.FailureRobotNum,1).taskEndNode;
                    end
                    obj.AllRobotTW{obj.FailureRobotNum,1} = [];
                    obj.failureRobotReplan(obj.FailureRobotNum,i-1,startNode,endNode,order);
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    obj.Failure = 0;
                    delayExist = 0;
                    obj.FailureRobotNum = 0;
%                     obj.FailureTime = 0;
%                     obj.FailureLength = 0;
                    
                    tempFailureR = grid2world(obj.Map,[1 1]);
                    obj.g.XData = tempFailureR(:,1);
                    obj.g.YData = tempFailureR(:,2);
                    obj.m.XData = tempFailureR(:,1);
                    obj.m.YData = tempFailureR(:,2);
                end
                
                obj.updateAllRobot(i);  
                obj.allRobotPlanning(i);
 
                RobotAllLocation = zeros(obj.TotalRobotNumber,2);
                for j = 1:obj.TotalRobotNumber
                    RobotAllLocation(j,:) = obj.RobotArray(j,1).getLocation();
                end
                obj.NowLocation = RobotAllLocation; 
                
                if obj.Failure == 0 && obj.delay == 0 %ϵͳ����ʧЧ������,���ӳٻ�����
                    tempR = obj.getAllRobotLocation(); 
                    obj.h.XData = tempR(:,1);
                    obj.h.YData = tempR(:,2);                  
                elseif obj.Failure == 1 && obj.delay == 0 %ϵͳ����ʧЧ������
                    failureRLocation = obj.RobotArray(obj.FailureRobotNum,1).getLocation();
                    failureRLocation = grid2world(obj.Map,failureRLocation);
                    tempFailureR = failureRLocation;
                    obj.g.XData = tempFailureR(:,1);
                    obj.g.YData = tempFailureR(:,2); 

 
                    if delayExist == 0
                        if obj.delay == 0 %��ʧЧ�����˵���δѡ������ʧЧ������
                            CandidateRobots = []; %��¼�ڵ�·���Ҵ��ڵȴ�״̬�Ļ����˱��
                            CandidateRobotsPath = []; %��¼�ڵ�·�ϵĻ����˱��
                            if i ~= 1
                                %disp('aaa');
                                for j = 1:obj.TotalRobotNumber
                                    if j ~= obj.FailureRobotNum
                                        if ((mod(obj.NowLocation(j,1),3) == 2) && ((obj.NowLocation(j,2) ~= 1) && (obj.NowLocation(j,2) ~= obj.AllColumn))) || (mod(obj.NowLocation(j,2),7) == 2) %�������ڵ�·�ڵ���
                                            CandidatePathRow = size(CandidateRobotsPath,1);
                                            CandidateRobotsPath(CandidatePathRow + 1,:) = j;
                                            if  (obj.LastTLocation(j,1) == obj.NowLocation(j,1)) && (obj.LastTLocation(j,2) == obj.NowLocation(j,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                                CandidateRow = size(CandidateRobots,1);
                                                CandidateRobots(CandidateRow+1,:) = j;
                                            end
                                        end
                                    end
                                end
                            end

                            if size(CandidateRobots,1) > 0 % CandidateRobots��������1��Ԫ��
                                if obj.delayNum == 1 %�ӳ�����Ϊ1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobots(index1,1);
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);

                                elseif obj.delayNum == 2 %�ӳ�����Ϊ2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobots(index1,1);
                                    CandidateRobots(index1,:) = [];
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobots(index2,1);
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                        CandidateRobotsPath(IndexLocation,:) = [];
                                        index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    end
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 3 %�ӳ�����Ϊ3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobots(index1,1);
                                    CandidateRobots(index1,:) = [];
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobots(index2,1);
                                        CandidateRobots(index2,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                        CandidateRobotsPath(IndexLocation,:) = [];
                                        index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobots(index3,1);
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                        CandidateRobotsPath(IndexLocation2,:) = [];
                                        index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    end
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 4 %�ӳ�����Ϊ4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobots(index1,1);
                                    CandidateRobots(index1,:) = [];
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobots(index2,1);
                                        CandidateRobots(index2,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                        CandidateRobotsPath(IndexLocation,:) = [];
                                        index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobots(index3,1);
                                        CandidateRobots(index3,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                        CandidateRobotsPath(IndexLocation2,:) = [];
                                        index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index4 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber4 = CandidateRobots(index4,1);
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                        CandidateRobotsPath(IndexLocation3,:) = [];
                                        index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                                    end
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 5 %�ӳ�����Ϊ5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobots(index1,1);
                                    CandidateRobots(index1,:) = [];
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobots(index2,1);
                                        CandidateRobots(index2,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                        CandidateRobotsPath(IndexLocation,:) = [];
                                        index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobots(index3,1);
                                        CandidateRobots(index3,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                        CandidateRobotsPath(IndexLocation2,:) = [];
                                        index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index4 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber4 = CandidateRobots(index4,1);
                                        CandidateRobots(index4,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                        CandidateRobotsPath(IndexLocation3,:) = [];
                                        index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index5 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber5 = CandidateRobots(index5,1);
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation4 = find(CandidateRobotsPath(:,1) == obj.RobotNumber4);
                                        CandidateRobotsPath(IndexLocation4,:) = [];
                                        index5 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber5 = CandidateRobotsPath(index5,1);
                                    end
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                    DelayRLocation(5,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.RobotNumber5) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 6 %�ӳ�����Ϊ6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobots(index1,1);
                                    CandidateRobots(index1,:) = [];
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobots(index2,1);
                                        CandidateRobots(index2,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                        CandidateRobotsPath(IndexLocation,:) = [];
                                        index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobots(index3,1);
                                        CandidateRobots(index3,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                        CandidateRobotsPath(IndexLocation2,:) = [];
                                        index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index4 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber4 = CandidateRobots(index4,1);
                                        CandidateRobots(index4,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                        CandidateRobotsPath(IndexLocation3,:) = [];
                                        index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index5 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber5 = CandidateRobots(index5,1);
                                        CandidateRobots(index5,:) = [];
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation4 = find(CandidateRobotsPath(:,1) == obj.RobotNumber4);
                                        CandidateRobotsPath(IndexLocation4,:) = [];
                                        index5 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber5 = CandidateRobotsPath(index5,1);
                                    end
                                    
                                    if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                        index6 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                        obj.RobotNumber6 = CandidateRobots(index6,1);
                                    else % CandidateRobots����Ԫ��
                                        IndexLocation5 = find(CandidateRobotsPath(:,1) == obj.RobotNumber5);
                                        CandidateRobotsPath(IndexLocation5,:) = [];
                                        index6 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                        obj.RobotNumber6 = CandidateRobotsPath(index6,1);
                                    end
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                    DelayRLocation(5,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                    DelayRLocation(6,:) = obj.RobotArray(obj.RobotNumber6,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.RobotNumber5) && (j ~= obj.RobotNumber6) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                end
                            else % CandidateRobots��Ԫ�ظ���Ϊ0
                                if obj.delayNum == 1 %�ӳ�����Ϊ1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    IndexLocation = find(CandidateRobotsPath(:,1) == obj.FailureRobotNum);
                                    CandidateRobotsPath(IndexLocation,:) = [];
                                    index1 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobotsPath(index1,1);   

                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);

                                elseif obj.delayNum == 2 %�ӳ�����Ϊ2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    IndexLocation = find(CandidateRobotsPath(:,1) == obj.FailureRobotNum);
                                    CandidateRobotsPath(IndexLocation,:) = [];
                                    index1 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobotsPath(index1,1);   

                                    IndexLocation1 = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                    CandidateRobotsPath(IndexLocation1,:) = [];
                                    index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 3 %�ӳ�����Ϊ3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    IndexLocation = find(CandidateRobotsPath(:,1) == obj.FailureRobotNum);
                                    CandidateRobotsPath(IndexLocation,:) = [];
                                    index1 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobotsPath(index1,1);   

                                    IndexLocation1 = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                    CandidateRobotsPath(IndexLocation1,:) = [];
                                    index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    
                                    IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                    CandidateRobotsPath(IndexLocation2,:) = [];
                                    index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 4 %�ӳ�����Ϊ4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    IndexLocation = find(CandidateRobotsPath(:,1) == obj.FailureRobotNum);
                                    CandidateRobotsPath(IndexLocation,:) = [];
                                    index1 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobotsPath(index1,1);   

                                    IndexLocation1 = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                    CandidateRobotsPath(IndexLocation1,:) = [];
                                    index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    
                                    IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                    CandidateRobotsPath(IndexLocation2,:) = [];
                                    index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    
                                    IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                    CandidateRobotsPath(IndexLocation3,:) = [];
                                    index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 5 %�ӳ�����Ϊ5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    IndexLocation = find(CandidateRobotsPath(:,1) == obj.FailureRobotNum);
                                    CandidateRobotsPath(IndexLocation,:) = [];
                                    index1 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobotsPath(index1,1);   

                                    IndexLocation1 = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                    CandidateRobotsPath(IndexLocation1,:) = [];
                                    index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    
                                    IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                    CandidateRobotsPath(IndexLocation2,:) = [];
                                    index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    
                                    IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                    CandidateRobotsPath(IndexLocation3,:) = [];
                                    index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                                    
                                    IndexLocation4 = find(CandidateRobotsPath(:,1) == obj.RobotNumber4);
                                    CandidateRobotsPath(IndexLocation4,:) = [];
                                    index5 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber5 = CandidateRobotsPath(index5,1);
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                    DelayRLocation(5,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.RobotNumber5) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                elseif obj.delayNum == 6 %�ӳ�����Ϊ6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    IndexLocation = find(CandidateRobotsPath(:,1) == obj.FailureRobotNum);
                                    CandidateRobotsPath(IndexLocation,:) = [];
                                    index1 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber1 = CandidateRobotsPath(index1,1);   

                                    IndexLocation1 = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                    CandidateRobotsPath(IndexLocation1,:) = [];
                                    index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                                    
                                    IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                    CandidateRobotsPath(IndexLocation2,:) = [];
                                    index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                                    
                                    IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                    CandidateRobotsPath(IndexLocation3,:) = [];
                                    index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                                    
                                    IndexLocation4 = find(CandidateRobotsPath(:,1) == obj.RobotNumber4);
                                    CandidateRobotsPath(IndexLocation4,:) = [];
                                    index5 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber5 = CandidateRobotsPath(index5,1);
                                    
                                    IndexLocation5 = find(CandidateRobotsPath(:,1) == obj.RobotNumber5);
                                    CandidateRobotsPath(IndexLocation5,:) = [];
                                    index6 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                    obj.RobotNumber6 = CandidateRobotsPath(index6,1);
                                    
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                    DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                    DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                    DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                    DelayRLocation(5,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                    DelayRLocation(6,:) = obj.RobotArray(obj.RobotNumber6,1).getLocation();
                                    DelayRLocation = grid2world(obj.Map,DelayRLocation);
                %                    tempFailureR = DelayRLocation;
                                    obj.p.XData = DelayRLocation(:,1);
                                    obj.p.YData = DelayRLocation(:,2);                     

                                    obj.delay = 1;
                                    obj.CurrentT = i;

                                    allLocation = [];
                                    for j = 1:obj.TotalRobotNumber
                                        if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.RobotNumber5) && (j ~= obj.RobotNumber6) && (j ~= obj.FailureRobotNum)
                                            row = size(allLocation,1);
                                            allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                        end
                                    end   
                                    allLocation = grid2world(obj.Map,allLocation);
                                    tempRobot = allLocation;
                                    obj.h.XData = tempRobot(:,1);
                                    obj.h.YData = tempRobot(:,2);
                                    
                                end

                            end
                        end
                        delayExist = 1;
                    end
                else % (obj.Failure == 0||obj.Failure == 1) && obj.delay == 1
                    if i < (obj.CurrentT + 12) %��ǰʱ��<(������ʱʱ��+12)
                        DelayRLocation = [];
                        if obj.delayNum == 1 %�ӳ�����Ϊ1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end
                            
                            if (obj.move1 == 0)
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.p.XData = DelayRLocation(:,1);
                                obj.p.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && (j ~= obj.FailureRobotNum)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 
                                obj.delay = 0;
                                obj.move1 = 0;
                                tempDelayR = grid2world(obj.Map,[1 1;1 1]);
                                obj.p.XData = tempDelayR(:,1);
                                obj.p.YData = tempDelayR(:,2); 
                            end                                                        
                        elseif obj.delayNum == 2 %�ӳ�����Ϊ2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if (obj.move1 == 0) || (obj.move2 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.p.XData = DelayRLocation(:,1);
                                obj.p.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && (j ~= obj.FailureRobotNum)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                tempDelayR = grid2world(obj.Map,[1 1;1 1]);
                                obj.p.XData = tempDelayR(:,1);
                                obj.p.YData = tempDelayR(:,2); 
                            end
                        elseif obj.delayNum == 3 %�ӳ�����Ϊ3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end
                            
                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.p.XData = DelayRLocation(:,1);
                                obj.p.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1)) && (j ~= obj.FailureRobotNum)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1 
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                tempDelayR = grid2world(obj.Map,[1 1;1 1]);
                                obj.p.XData = tempDelayR(:,1);
                                obj.p.YData = tempDelayR(:,2); 
                            end
                        elseif obj.delayNum == 4 %�ӳ�����Ϊ4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end
                            
                            if obj.move4 == 0
                                if  (obj.LastTLocation(obj.RobotNumber4,1) == obj.NowLocation(obj.RobotNumber4,1)) && (obj.LastTLocation(obj.RobotNumber4,2) == obj.NowLocation(obj.RobotNumber4,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                else %����
                                    obj.move4 = 1;
                                end
                            end
                            
                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) || (obj.move4 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.p.XData = DelayRLocation(:,1);
                                obj.p.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1)) && ((j ~= obj.RobotNumber4) || (obj.move4 == 1)) && (j ~= obj.FailureRobotNum)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1 && obj.move4 == 1 
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                obj.move4 = 0;
                                tempDelayR = grid2world(obj.Map,[1 1;1 1]);
                                obj.p.XData = tempDelayR(:,1);
                                obj.p.YData = tempDelayR(:,2); 
                            end
                        elseif obj.delayNum == 5 %�ӳ�����Ϊ5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end
                            
                            if obj.move4 == 0
                                if  (obj.LastTLocation(obj.RobotNumber4,1) == obj.NowLocation(obj.RobotNumber4,1)) && (obj.LastTLocation(obj.RobotNumber4,2) == obj.NowLocation(obj.RobotNumber4,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                else %����
                                    obj.move4 = 1;
                                end
                            end
                            
                            if obj.move5 == 0
                                if  (obj.LastTLocation(obj.RobotNumber5,1) == obj.NowLocation(obj.RobotNumber5,1)) && (obj.LastTLocation(obj.RobotNumber5,2) == obj.NowLocation(obj.RobotNumber5,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                else %����
                                    obj.move5 = 1;
                                end
                            end
                            
                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) || (obj.move4 == 0) || (obj.move5 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.p.XData = DelayRLocation(:,1);
                                obj.p.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1)) && ((j ~= obj.RobotNumber4) || (obj.move4 == 1)) && ((j ~= obj.RobotNumber5) || (obj.move5 == 1)) && (j ~= obj.FailureRobotNum)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1 && obj.move4 == 1 && obj.move5 == 1 
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                obj.move4 = 0;
                                obj.move5 = 0;
                                tempDelayR = grid2world(obj.Map,[1 1;1 1]);
                                obj.p.XData = tempDelayR(:,1);
                                obj.p.YData = tempDelayR(:,2); 
                            end
                        elseif obj.delayNum == 6 %�ӳ�����Ϊ6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end
                            
                            if obj.move4 == 0
                                if  (obj.LastTLocation(obj.RobotNumber4,1) == obj.NowLocation(obj.RobotNumber4,1)) && (obj.LastTLocation(obj.RobotNumber4,2) == obj.NowLocation(obj.RobotNumber4,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                else %����
                                    obj.move4 = 1;
                                end
                            end
                            
                            if obj.move5 == 0
                                if  (obj.LastTLocation(obj.RobotNumber5,1) == obj.NowLocation(obj.RobotNumber5,1)) && (obj.LastTLocation(obj.RobotNumber5,2) == obj.NowLocation(obj.RobotNumber5,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                else %����
                                    obj.move5 = 1;
                                end
                            end
                            
                            if obj.move6 == 0
                                if  (obj.LastTLocation(obj.RobotNumber6,1) == obj.NowLocation(obj.RobotNumber6,1)) && (obj.LastTLocation(obj.RobotNumber6,2) == obj.NowLocation(obj.RobotNumber6,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber6,1).getLocation();
                                else %����
                                    obj.move6 = 1;
                                end
                            end
                            
                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) || (obj.move4 == 0) || (obj.move5 == 0) || (obj.move6 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.p.XData = DelayRLocation(:,1);
                                obj.p.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1)) && ((j ~= obj.RobotNumber4) || (obj.move4 == 1)) && ((j ~= obj.RobotNumber5) || (obj.move5 == 1)) && ((j ~= obj.RobotNumber6) || (obj.move6 == 1)) && (j ~= obj.FailureRobotNum)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1 && obj.move4 == 1 && obj.move5 == 1 && obj.move6 == 1 
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                obj.move4 = 0;
                                obj.move5 = 0;
                                obj.move6 = 0;
                                tempDelayR = grid2world(obj.Map,[1 1;1 1]);
                                obj.p.XData = tempDelayR(:,1);
                                obj.p.YData = tempDelayR(:,2); 
                            end
                        end


                    else %��ǰʱ��>=(������ʱʱ��+6)
                        obj.delay = 0;
                        if obj.delayNum == 1
                            obj.move1 = 0;
                        elseif obj.delayNum == 2
                            obj.move1 = 0;
                            obj.move2 = 0;
                        elseif obj.delayNum == 3
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                        elseif obj.delayNum == 4
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                            obj.move4 = 0;
                        elseif obj.delayNum == 5
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                            obj.move4 = 0;
                            obj.move5 = 0;
                        elseif obj.delayNum == 6
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                            obj.move4 = 0;
                            obj.move5 = 0;
                            obj.move6 = 0;
                        end

                        tempFailureR = grid2world(obj.Map,[1 1]);
                        obj.g.XData = tempFailureR(:,1);
                        obj.g.YData = tempFailureR(:,2);

                        obj.h.XData = tempR(:,1);
                        obj.h.YData = tempR(:,2); 
                    end                    
                end
                        
                if obj.Failure == 1
                    if obj.FailureTime ~= i %��ǰʱ�̲��Ƿ���ʧЧ��ʱ��
%                         if obj.delay == 1
% 
%                             if i < (obj.CurrentT + 12) %��ǰʱ��<(������ʱʱ��+6)
%                                 DelayRLocation = [];
%                                 if obj.delayNum == 1 %�ӳ�����Ϊ1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                     if obj.move1 == 0
%                                         if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
%                                             DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
%                                         else %����
%                                             obj.move1 = 1;
%                                         end
%                                     end
% 
%                                     if (obj.move1 == 0) 
%                                         DelayRLocation = grid2world(obj.Map,DelayRLocation);
%                     %                    tempFailureR = DelayRLocation;
%                                         obj.p.XData = DelayRLocation(:,1);
%                                         obj.p.YData = DelayRLocation(:,2); 
%                                     end
% 
% 
%                                     allLocation = [];
%                                     for j = 1:obj.TotalRobotNumber
%                                         if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && (j ~= obj.FailureRobotNum)
%                                             row = size(allLocation,1);
%                                             allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
%                                         end
%                                     end   
%                                     allLocation = grid2world(obj.Map,allLocation);
%                                     tempRobot = allLocation;
%                                     obj.h.XData = tempRobot(:,1);
%                                     obj.h.YData = tempRobot(:,2); 
% 
%                                     if obj.move1 == 1 
%                                         obj.delay = 0;
%                                         obj.move1 = 0;
%                                         tempDelayR = grid2world(obj.Map,[1 1;1 1]);
%                                         obj.p.XData = tempDelayR(:,1);
%                                         obj.p.YData = tempDelayR(:,2); 
%                                     end                                                        
%                                 elseif obj.delayNum == 2 %�ӳ�����Ϊ2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                              
%                                 elseif obj.delayNum == 3 %�ӳ�����Ϊ3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                     
%                                 elseif obj.delayNum == 4 %�ӳ�����Ϊ4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                     
%                                 elseif obj.delayNum == 5 %�ӳ�����Ϊ5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                     
%                                 elseif obj.delayNum == 6 %�ӳ�����Ϊ6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                     
%                                 end
% 
% 
%                             else %��ǰʱ��>=(������ʱʱ��+6)
%                                 obj.delay = 0;
%                                 if obj.delayNum == 1
%                                     obj.move1 = 0;
%                                 elseif obj.delayNum == 2
%                                     obj.move1 = 0;
%                                     obj.move2 = 0;
%                                 elseif obj.delayNum == 3
%                                     obj.move1 = 0;
%                                     obj.move2 = 0;
%                                     obj.move3 = 0;
%                                 elseif obj.delayNum == 4
%                                     obj.move1 = 0;
%                                     obj.move2 = 0;
%                                     obj.move3 = 0;
%                                     obj.move4 = 0;
%                                 elseif obj.delayNum == 5
%                                     obj.move1 = 0;
%                                     obj.move2 = 0;
%                                     obj.move3 = 0;
%                                     obj.move4 = 0;
%                                     obj.move5 = 0;
%                                 elseif obj.delayNum == 6
%                                     obj.move1 = 0;
%                                     obj.move2 = 0;
%                                     obj.move3 = 0;
%                                     obj.move4 = 0;
%                                     obj.move5 = 0;
%                                     obj.move6 = 0;
%                                 end
% 
%                                 tempFailureR = grid2world(obj.Map,[1 1]);
%                                 obj.g.XData = tempFailureR(:,1);
%                                 obj.g.YData = tempFailureR(:,2);
%                                 
%                                 obj.h.XData = tempR(:,1);
%                                 obj.h.YData = tempR(:,2); 
%                             end                        
% 
% 
%                         elseif obj.delay == 0
                        if obj.delay == 0
                            failureRLocation = obj.RobotArray(obj.FailureRobotNum,1).getLocation();
                            failureRLocation = grid2world(obj.Map,failureRLocation);
                            tempFailureR = failureRLocation;
                            obj.g.XData = tempFailureR(:,1);
                            obj.g.YData = tempFailureR(:,2);
                            
                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if (j ~= obj.FailureRobotNum)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2);
                        end
                    end
                end
                
                
                drawnow; 
                pause(obj.PlotInterval);
                i = i + 1;
                %disp('���������');
                %disp(obj.FinishedTaskNum);
            end    
            %disp('���ʱ��');
            %disp(i);
        end
        
%****************************************д�����ݵ�Excel��***************************************
        
        function AllWorkingRobot(obj)
            filename = 'Allworkingrobot.xlsx';
            a = obj.Allworkingrobot;
            xlswrite(filename,a);
        end 
        
        function AllRobotTaskdistance(obj)
            filename = 'AllRobotTaskdistance.xlsx';
            a = obj.AllRobotTaskD;
            xlswrite(filename,a);
        end         
        
        function WorkerworkTime(obj)  
            filename = 'WorkerworkTime.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = 0.25*obj.WorkerArray(i,1).WorkTime;
            end
            xlswrite(filename,a);
        end
        
        function WorkerfreeTime(obj)   
            filename = 'WorkerfreeTime.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = 0.25*obj.WorkerArray(i,1).PatrolTime;
            end
            xlswrite(filename,a);            
        end
        
        function WorkerpatrolD(obj)    
            filename = 'WorkerpatrolD.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = obj.WorkerArray(i,1).getOdom2();
            end
            xlswrite(filename,a);            
        end
                
        function WorkerworkD(obj) 
            filename = 'WorkerworkD.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = obj.WorkerArray(i,1).getOdom1();
            end
            xlswrite(filename,a);            
        end
        
        function RobottravelTime(obj) 
            filename = 'RobottravelTime.xlsx';
            a = zeros(obj.TotalRobotNumber,1);
            for i = 1:obj.TotalRobotNumber
                a(i,1) = 0.25*obj.RobotArray(i,1).TravelTime;
            end
            xlswrite(filename,a);             
        end

        function RobotwaitTime(obj) 
            filename = 'RobotwaitTime.xlsx';
            a = zeros(obj.TotalRobotNumber,1);
            for i = 1:obj.TotalRobotNumber
                a(i,1) = 0.25*obj.RobotArray(i,1).WaitTime;
            end
            xlswrite(filename,a);            
        end
        
        function RobottravelD(obj) 
            filename = 'RobottravelD.xlsx';
            a = zeros(obj.TotalRobotNumber,1);
            for i = 1:obj.TotalRobotNumber
                a(i,1) = obj.RobotArray(i,1).getOdom();
            end
            xlswrite(filename,a);            
        end
        
        function WorkerfindRobots(obj) 
            filename = 'WorkerfindRobots.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = obj.WorkerArray(i,1).FindRobots;
            end
            xlswrite(filename,a);            
        end       
        
        function RobotStatus(obj)
            filename = 'RobotStatus';
            a = zeros(obj.TotalRobotNumber,3);
            for i = 1:obj.TotalRobotNumber
                s1 = obj.RobotArray(i,1).Status1;
                s2 = obj.RobotArray(i,1).Status2;
                s3 = obj.RobotArray(i,1).Status3;
                a(i,1) = s1/(s1+s2+s3);
                a(i,2) = s2/(s1+s2+s3);
                a(i,3) = s3/(s1+s2+s3);
            end
            xlswrite(filename,a);  
        end
        
        function WorkerStatus(obj)
            filename = 'WorkerStatus';
            a = zeros(obj.TotalWorkerNumber,3);
            for i = 1:obj.TotalWorkerNumber
                s0 = obj.WorkerArray(i,1).Status0;
                s1 = obj.WorkerArray(i,1).Status1;
                s2 = obj.WorkerArray(i,1).Status2;
                a(i,1) = s0/(s0+s1+s2);
                a(i,2) = s1/(s0+s1+s2);
                a(i,3) = s2/(s0+s1+s2);
            end
            xlswrite(filename,a);  
        end
        
        function EveryTimeWorkerStatus(obj)
            filename = 'EveryTimeWorkerStatus';
            a = obj.StatusList;
            xlswrite(filename,a);
        end
        
%***********************************************************************************************
        
        function getAllWorkerOdom1(obj)
%             for i = 1:obj.TotalWorkerNumber
%                 obj.AllWorkerOdom1 = obj.AllWorkerOdom1 + obj.WorkerArray(i,1).getOdom1();
%             end
        end
        
        function getAllWorkerOdom2(obj)
%             for i = 1:obj.TotalWorkerNumber
%                 obj.AllWorkerOdom2 = obj.AllWorkerOdom2 + obj.WorkerArray(i,1).getOdom2();
%             end
        end
        
        function getAllRobotOdom(obj)
%             for i = 1:obj.TotalRobotNumber
%                 obj.AllRobotOdom = obj.AllRobotOdom + obj.RobotArray(i,1).getOdom();
%             end
        end
        
        function close(obj)
            obj.SystemOn = false;
        end
        
    end %end of methods
    
end %end of classdef


function [shortestLocalPaths, totalLocalCosts] = LocalPathSearch(netCostMatrix, NodeCoordinate, MapSignalNode, MapNode, AdjacentMatrixNode, source, destination, k_paths)
sourceNode = find(AdjacentMatrixNode == source);
destinationNode = find(AdjacentMatrixNode == destination);
[shortestPaths, totalCosts] = kShortestPath(netCostMatrix, sourceNode, destinationNode, k_paths);

%��shortestPaths�еĵ�ת��Ϊʵ�ʵĽڵ�
for i = 1:size(shortestPaths,2)
    for j = 1:size(shortestPaths{1,i},2)
        node = shortestPaths{1,i}(1,j);
        realNode = AdjacentMatrixNode(node,1);
        shortestPaths{1,i}(1,j) = realNode;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ѡ��������̵�·��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
shortestLocalPaths = []; %������е����·��
totalLocalCosts = [];
shortestLength = totalCosts(1,1);
for i = 1:size(shortestPaths,2)
    if totalCosts(1,i) == shortestLength
        row = size(shortestLocalPaths,1);
        shortestLocalPaths{row+1,1} = shortestPaths{1,i};
        totalLocalCosts(row+1,1) = totalCosts(1,i);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
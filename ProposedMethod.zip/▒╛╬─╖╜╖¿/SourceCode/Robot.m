classdef Robot<handle
    %ROBOT �˴���ʾ�йش����ժҪ
    %   !!!!��̨����Ӧ��դ������

        properties  
            
            %��̬���ԣ���ʼ��֮��Ͳ���仯��
            
            SerialNumber  %�����˱��     
            V = 1; %�������ٶ�
            InitialRobotState %��ʼλ��Ϊ[50 3]
            
            %���ڻ����˶�̬���ԣ�ȫ������get��set������ȡ�����ã��������õ������Եķ�ʽ��
            %��̬�������ԡ� 
            
            %ȫ��Ϊ�ڲ����¡��ⲿ���½�Ϊ�����á�
            R              %դ�������� Row
            C              %դ�������� Col   
            Node           %�������������ڽڵ�
            Odom           %��������̼ơ��ڲ�դ���ʾ���ⲿ��getOdom��ȡ��Ϣ��
            EveryTaskOdom  %ÿ��������ÿ������ľ���
            Rp
            Cp
            
            
            %��̬�������ԡ�
                        
            AssignedTask %��¼��ǰ��������������ⲿ����
            TaskSerial %��¼��ǰ�������ı�š��ⲿ����
            StationNumber %��¼��ǰ���������������ⲿ����
            
            TaskCompleted %���⴫���������
            
            Picked %�ж��Ƿ��ڵ�ǰվ�㹤�˷��ϻ���ⲿ����
            
            Status %������״̬�� 0������ 1����·�� 2��ȡ��/�Ż�
            StationIndex %��¼��ǰ������վ�㡣ȡֵΪ1��StationNumber���ڲ�����     
            
            taskStartNode %��¼�������
            taskEndNode   %��¼�����յ�
            
            Planned       %��¼�켣�Ƿ�滮����1-�滮����0-δ�滮����
            
            Goal %��̬���µ�ǰ�����˵�վ��Ŀ�ꡣ����ж���㡣ȡֵΪAssignedTask�е����������ڲ�����                        
            GetintoArray %�жϻ������Ƿ����ȴ�����
            
            Column1cars %��������һ���Ƿ��г� 
            Column2cars %�������ڶ����Ƿ��г�
            Column3cars %�������������Ƿ��г�
            Column4cars %ż������һ���Ƿ��г�
            Column5cars %ż�����ڶ����Ƿ��г�
            Column6cars %ż�����������Ƿ��г�
            
            GoalChanged %�ж�Ŀ����Ƿ�ĳ��ܱߵ��ĸ���
            ArrayNumber %�洢��ǰ�����Ŷӵĳ����� 8*1�ľ���
            
            NowRobotLocation %�洢���л����˵�λ�ã����ڱ���
     
            TimeDelay1 %10��
            TimeDelay2 %5��
            TimeDelay3 %5��
        
        end
    
    methods
                
        function obj = Robot()
            %�޲�������������������
            %Robot Constructor for simulated object
            %Please check the class definition for details.
                        
            obj.Status = 0;
            obj.Picked = 0;
            obj.Odom = 0;
            obj.EveryTaskOdom = 0;
            obj.StationIndex = 1;
            obj.Goal = [0 0]; 
            obj.TimeDelay1 = 1;
            obj.TimeDelay2 = 1;
            obj.TimeDelay3 = 1;
            obj.TaskCompleted = 0;
            obj.AssignedTask = zeros(1,2);
            obj.StationNumber = 0;
            obj.TaskSerial = 0;
            obj.GoalChanged = 0;
            obj.NowRobotLocation = zeros(47,47);
%             obj.InitialRobotState = [51,2];
%             obj.setLocation(obj.InitialRobotState);
        end
        
        %���û����˱��
        function setAttribute(obj,robotNumber,R,C,Node)
            obj.SerialNumber = robotNumber;  
            i = obj.SerialNumber;
            obj.R = R;
            obj.C = C;
            obj.Node = Node;
        end
        
        %����Ϊդ������
        function setLocation(obj, location)            
            obj.R = location(1,1);  
            obj.C = location(1,2);
        end
        
        %�ⲿ���û�����״̬
        function setStatus(obj,Status)
            obj.Status = Status;
        end

        %�ⲿ���û�����Ŀ��λ��
        function setGoal(obj,start,final)
            obj.taskStartNode = start;
            obj.taskEndNode = final;
        end
        
        %�ⲿ���û��������������Ľڵ�
        function setNode(obj,Node)
            obj.Node = Node;
        end
        
        %�ⲿ���ô˻����˵Ĺ켣�Ƿ�滮��
        function setPlanned(obj,Planned)
            obj.Planned = Planned;
        end
        
        %�ⲿ��ȡ�˻����˹켣�Ƿ�滮��
        function planned = getPlanned(obj)
            planned = obj.Planned;
        end
        
        %���Ϊդ������
        function location = getLocation(obj)        
            location(1,1) = obj.R;
            location(1,2) = obj.C;
        end
        
        %���Ϊ������������߾���
        function odom = getOdom(obj)
            odom = obj.Odom*0.5*obj.V;
        end
        
        %���Ϊ��ǰ�����˵�״̬
        function status = getStatus(obj)
            status = obj.Status;
        end
        
        %�õ����������ڵĽڵ�
        function node = getNode(obj)
            node = obj.Node;
        end
        
        function number = getNumber(obj)
            number = obj.SerialNumber;
        end
        
        %���ⲿ�õ���picked��Ϣ������ΪN*1�����С�
        %����picked��Ϣ�����ⲿ�Ĺ�������Ϊ1���������ڲ����㡣��ʱ�ڹ����ڲ����
        function setPickedInfo(obj,picked)
            %�ҵ���picked��Ϣ����1֮��Ļ����������û�б�������
            aa = find(picked == 1); %����pickedλ��������
            if ~isempty(find(aa == obj.SerialNumber, 1))
                obj.Picked = 1;
            end
        end
        
        %���ⲿ��û����˵�������Ϣ����������㡣
        %����Ϊ������ţ�������㡣
        function setTask(obj,taskSerial,taskPoints)
              obj.AssignedTask(1,1) = taskPoints(taskSerial,1);
              obj.AssignedTask(1,2) = taskPoints(taskSerial,2);
              obj.TaskSerial = taskSerial;
%             a = taskPoints~=0;
%             temp = taskPoints(a);
%             obj.StationNumber = length(temp)/2;
%             obj.AssignedTask = (reshape(temp,2,obj.StationNumber))';
%             %disp(obj.AssignedTask);
%             obj.TaskSerial = taskSerial;
        end
        
        function setNowRobotLocation(obj,a)
            obj.NowRobotLocation = a;
        end
        
        function setArrayNumber(obj,number)
            obj.ArrayNumber = number;
        end
        
        %���ⲿ��������˵����������Ϣ�����������������
        function taskIndex = getTaskCompleted(obj)   
            if obj.TaskCompleted
                taskIndex = obj.TaskSerial;
                obj.TaskCompleted = 0;
                obj.TaskSerial = 0;
                obj.EveryTaskOdom = 0;
            else
                taskIndex = 0;
            end
        end
        
        function [R,C,Rp,Cp,Move] = updaterobotLocation(obj)
            if (obj.Rp ~= obj.R)||(obj.Cp ~= obj.C)
                Move = 1;
                R = obj.R;
                C = obj.C;
                Rp = obj.Rp;
                Cp = obj.Cp;
            else
                Move = 0;
                R = obj.R;
                C = obj.C;
                Rp = obj.R;
                Cp = obj.C;                
            end
        end
        
        %�ж����ĸ����� 
        function district = getdistrict(obj)
            Gr = obj.Goal(1,1);
            Gc = obj.Goal(1,2);            
            if (Gr>0)&&(Gr<=24)&&(Gc>0)&&(Gc<24)
                district = 1;
            elseif (Gr>24)&&(Gr<48)&&(Gc>0)&&(Gc<24)
                district = 2;
            elseif (Gr>24)&&(Gr<48)&&(Gc>=24)&&(Gc<48)
                district = 3;
            elseif (Gr>0)&&(Gr<=24)&&(Gc>=24)&&(Gc<48)
                district = 4;
            end            
        end
        
        % �õ���������8�������е���һ��
        function n = getdistrict8(obj,r,c)  
            if (r<=3)&&(c<=23)
                n = 1;
            elseif (c<=3)&&(r<=23)
                n = 2;
            elseif (c<=3)&&(r>=25)
                n = 3;
            elseif (r>=45)&&(c<=23)
                n = 4;
            elseif (r>=45)&&(c>=25)
                n = 5;
            elseif (c>=45)&&(r>=25)
                n = 6;
            elseif (c>=45)&&(r<=23)
                n = 7;
            elseif (r<=3)&&(c>=25)
                n = 8;
            else
                n = 0;
            end
        end
        
        function goal = GetArraygoal(obj)
            r = obj.R;
            c = obj.C;
            gr = obj.Goal(1,1);
            gc = obj.Goal(1,2);   
            a = obj.getdistrict();  %������
            if a == 1   %����1
                 for i = 5:1:22
                     if obj.NowRobotLocation(3,i) == 1
                         obj.Column1cars = 1;
                         break;
                     else
                         obj.Column1cars = 0;
                     end
                 end
                 for i = 23:(-1):5
                     if obj.NowRobotLocation(2,i) == 1
                         obj.Column2cars = 1;
                         break;
                     else
                         obj.Column2cars = 0;
                     end
                 end
                 for i = 5:1:23
                     if obj.NowRobotLocation(1,i) == 1
                         obj.Column3cars = 1;
                         break;
                     else
                         obj.Column3cars = 0;
                     end
                 end                
                 for i = 5:1:22
                     if obj.NowRobotLocation(i,3) == 1
                         obj.Column4cars = 1;
                         break;
                     else
                         obj.Column4cars = 0;
                     end
                 end
                 for i = 23:(-1):5
                     if obj.NowRobotLocation(i,2) == 1
                         obj.Column5cars = 1;
                         break;
                     else
                         obj.Column5cars = 0;
                     end
                 end
                 for i = 5:1:23
                     if obj.NowRobotLocation(i,1) == 1
                         obj.Column6cars = 1;
                         break;
                     else
                         obj.Column6cars = 0;
                     end
                 end                
                 
                 if obj.ArrayNumber(1,1)<obj.ArrayNumber(2,1)  %һ���ĳ����ڶ�����ѡ��ȥһ��
                     if obj.Column1cars == 0   %��һ��û�г�
                         if r == 4
                             if (c == 23)||(c ==24)
                                 goal(1,1) = 3;
                                 goal(1,2) = 22;                                 
                             else
                                 goal(1,1) = 3;
                                 goal(1,2) = c;
                             end
                         else
                             if mod(c,2) == 0  %cΪż��
                                 if mod(c,4) ~= 0
                                     goal(1,1) = 3;
                                     goal(1,2) = obj.C;
                                 else
                                     if obj.C == 24
                                         goal(1,1) = 3;
                                         goal(1,2) = 22;                                    
                                     else
                                         goal(1,1) = 3;
                                         goal(1,2) = obj.C + 2;                                 
                                     end
                                 end
                             else  %rΪ����
                                 c1 = obj.C + 1;
                                 c2 = obj.C - 1;
                                 if mod(c1,4) ~= 0
                                     goal(1,1) = 3;
                                     goal(1,2) = c1;                             
                                 else
                                     goal(1,1) = 3;
                                     goal(1,2) = c2;                             
                                 end
                             end
                         end
                     elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(3,5) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 3;
                         goal(1,2) = 4;
                     elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(3,5) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 1;
                         goal(1,2) = 4;                      
                     end      
%                      obj.ArrayNumber(1,1) = obj.ArrayNumber(1,1) + 1;
                 elseif obj.ArrayNumber(1,1)>obj.ArrayNumber(2,1)  %�����ĳ�����һ����ѡ��ȥ����
                     if obj.Column4cars == 0   %��һ��û�г�
                         if c == 4
                             if (r == 23)||(r == 24)
                                 goal(1,1) = 22;
                                 goal(1,2) = 3;                                
                             else
                                 goal(1,1) = r;
                                 goal(1,2) = 3;
                             end
                         else
                             if mod(r,2) == 0  %cΪż��
                                 if (mod(r,4) == 0)&&(r ~= 4)
                                     if obj.C == 24
                                         goal(1,1) = 22;
                                         goal(1,2) = 3;                                    
                                     else
                                         goal(1,1) = obj.R + 2;
                                         goal(1,2) = 3;                                 
                                     end                                     
                                 else
                                     goal(1,1) = obj.R;
                                     goal(1,2) = 3;
                                 end
                             else  %rΪ����
                                 r1 = obj.R + 1;
                                 r2 = obj.R - 1;
                                 if mod(r1,4) ~= 0
                                     goal(1,1) = r1;
                                     goal(1,2) = 3;                             
                                 else
                                     goal(1,1) = r2;
                                     goal(1,2) = 3;                             
                                 end
                             end
                         end
                     elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(5,3) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 4;
                         goal(1,2) = 3;
                     elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(5,3) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 4;
                         goal(1,2) = 1;                      
                     end  
%                      obj.ArrayNumber(2,1) = obj.ArrayNumber(2,1) + 1;
                 elseif obj.ArrayNumber(1,1) == obj.ArrayNumber(2,1)  %һ����������=�����������������ݾ���Զ����ѡ
                     if obj.R<obj.C  %ȥһ��
                         if obj.Column1cars == 0   %��һ��û�г�
                             if r == 4
                                 if (c == 23)||(c ==24)
                                     goal(1,1) = 3;
                                     goal(1,2) = 22;                                 
                                 else
                                     goal(1,1) = 3;
                                     goal(1,2) = c;
                                 end
                             else
                                 if mod(c,2) == 0  %cΪż��
                                     if mod(c,4) ~= 0
                                         goal(1,1) = 3;
                                         goal(1,2) = obj.C;
                                     else
                                         if obj.C == 24
                                             goal(1,1) = 3;
                                             goal(1,2) = 22;                                    
                                         else
                                             goal(1,1) = 3;
                                             goal(1,2) = obj.C + 2;                                 
                                         end
                                     end
                                 else  %rΪ����
                                     c1 = obj.C + 1;
                                     c2 = obj.C - 1;
                                     if mod(c1,4) ~= 0
                                         goal(1,1) = 3;
                                         goal(1,2) = c1;                             
                                     else
                                         goal(1,1) = 3;
                                         goal(1,2) = c2;                             
                                     end
                                 end
                             end
                         elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(3,5) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 3;
                             goal(1,2) = 4;
                         elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(3,5) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 1;
                             goal(1,2) = 4;                      
                         end      
%                          obj.ArrayNumber(1,1) = obj.ArrayNumber(1,1) + 1;                         
                     elseif obj.R>obj.C  %ȥ����
                         if obj.Column4cars == 0   %��һ��û�г�
                             if c == 4
                                 if (r == 23)||(r == 24)
                                     goal(1,1) = 22;
                                     goal(1,2) = 3;                                
                                 else
                                     goal(1,1) = r;
                                     goal(1,2) = 3;
                                 end
                             else
                                 if mod(r,2) == 0  %cΪż��
                                     if (mod(r,4) == 0)&&(r ~= 4)
                                         if obj.C == 24
                                             goal(1,1) = 22;
                                             goal(1,2) = 3;                                    
                                         else
                                             goal(1,1) = obj.R + 2;
                                             goal(1,2) = 3;                                 
                                         end                                     
                                     else
                                         goal(1,1) = obj.R;
                                         goal(1,2) = 3;
                                     end
                                 else  %rΪ����
                                     r1 = obj.R + 1;
                                     r2 = obj.R - 1;
                                     if mod(r1,4) ~= 0
                                         goal(1,1) = r1;
                                         goal(1,2) = 3;                             
                                     else
                                         goal(1,1) = r2;
                                         goal(1,2) = 3;                             
                                     end
                                 end
                             end
                         elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(5,3) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 4;
                             goal(1,2) = 3;
                         elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(5,3) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 4;
                             goal(1,2) = 1;                      
                         end  
%                          obj.ArrayNumber(2,1) = obj.ArrayNumber(2,1) + 1;                         
                     end
                 end

%                  %���ݲ�ͬ������ز�ͬĿ���
%                  if obj.Column1cars == 0   %��һ��û�г�
%                      if mod(c,2) == 0  %cΪż��
%                          if mod(c,4) ~= 0
%                              goal(1,1) = 3;
%                              goal(1,2) = obj.C;
%                          else
%                              if obj.C == 24
%                                  goal(1,1) = 3;
%                                  goal(1,2) = 22;                                    
%                              else
%                                  goal(1,1) = 3;
%                                  goal(1,2) = 3;                                 
%                              end
%                          end
%                      else  %rΪ����
%                          r1 = obj.R + 1;
%                          r2 = obj.R - 1;
%                          if mod(r1,4) ~= 0
%                              goal(1,1) = r1;
%                              goal(1,2) = 3;                             
%                          else
%                              goal(1,1) = r2;
%                              goal(1,2) = 3;                             
%                          end
%                      end
%                  elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(21,3) ~= 1)  %��һ���г����ڶ���û�г�
%                      goal(1,1) = 22;
%                      goal(1,2) = 3;
%                  elseif ((obj.Column3cars == 0)&&(obj.Column2cars == 1))||(obj.NowRobotLocation(21,3) == 1)  %��һ����ڶ��о��г�
%                      goal(1,1) = 22;
%                      goal(1,2) = 1;   
%                  elseif (obj.Column4cars == 0)&&(obj.Column3cars == 1)
%                      goal(1,1) = 1;
%                      goal(1,2) = 1;                     
%                  elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)
%                      goal(1,1) = 2;
%                      goal(1,2) = 1;                     
%                  elseif obj.Column5cars == 1
%                      goal(1,1) = 22;
%                      goal(1,2) = 1;                     
%                  end
                 
            elseif a == 2
                 for i = 43:(-1):26
                     if obj.NowRobotLocation(i,3) == 1
                         obj.Column1cars = 1;
                         break;
                     else
                         obj.Column1cars = 0;
                     end
                 end
                 for i = 25:1:43
                     if obj.NowRobotLocation(i,2) == 1
                         obj.Column2cars = 1;
                         break;
                     else
                         obj.Column2cars = 0;
                     end
                 end
                 for i = 43:(-1):25
                     if obj.NowRobotLocation(i,1) == 1
                         obj.Column3cars = 1;
                         break;
                     else
                         obj.Column3cars = 0;
                     end
                 end  
                 for i = 5:1:22
                     if obj.NowRobotLocation(45,i) == 1
                         obj.Column4cars = 1;
                         break;
                     else
                         obj.Column4cars = 0;
                     end
                 end                  
                 for i = 23:(-1):5
                     if obj.NowRobotLocation(46,i) == 1
                         obj.Column5cars = 1;
                         break;
                     else
                         obj.Column5cars = 0;
                     end
                 end 
                 for i = 5:1:23
                     if obj.NowRobotLocation(47,i) == 1
                         obj.Column6cars = 1;
                         break;
                     else
                         obj.Column6cars = 0;
                     end
                 end       
                 
                 if obj.ArrayNumber(3,1)<obj.ArrayNumber(4,1)  %�����ĳ�����������ѡ��ȥ����
                     if obj.Column1cars == 0   %��һ��û�г�
                         if c == 4
                             if (r == 24)||(r == 25)
                                 goal(1,1) = 26;
                                 goal(1,2) = 3;                                 
                             else
                                 goal(1,1) = r;
                                 goal(1,2) = 3;
                             end
                         else
                             if mod(r,2) == 0  %cΪż��
                                 if mod(r,4) ~= 0
                                     goal(1,1) = obj.R;
                                     goal(1,2) = 3;
                                 else
                                     if obj.C == 24
                                         goal(1,1) = 26;
                                         goal(1,2) = 3;                                    
                                     else
                                         goal(1,1) = obj.R - 2;
                                         goal(1,2) = 3;                                 
                                     end
                                 end
                             else  %rΪ����
                                 r1 = obj.R + 1;
                                 r2 = obj.R - 1;
                                 if mod(r1,4) ~= 0
                                     goal(1,1) = r1;
                                     goal(1,2) = 3;                             
                                 else
                                     goal(1,1) = r2;
                                     goal(1,2) = 3;                             
                                 end
                             end
                         end
                     elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(43,3) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 44;
                         goal(1,2) = 3;
                     elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(43,3) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 44;
                         goal(1,2) = 1;                      
                     end      
%                      obj.ArrayNumber(3,1) = obj.ArrayNumber(3,1) + 1;
                 elseif obj.ArrayNumber(3,1)>obj.ArrayNumber(4,1)  %�����ĳ�����������ѡ��ȥ����
                     if obj.Column4cars == 0   %��һ��û�г�
                         if r == 44
                             if (c == 23)||(c == 24)
                                 goal(1,1) = 45;
                                 goal(1,2) = 20;                                 
                             else
                                 goal(1,1) = 45;
                                 goal(1,2) = c;
                             end
                         else
                             if mod(c,2) == 0  %cΪż��
                                 if mod(c,4) == 0
                                     if c == 24
                                         goal(1,1) = 45;
                                         goal(1,2) = 20;                                         
                                     else
                                         goal(1,1) = 45;
                                         goal(1,2) = c;
                                     end
                                 else
                                     if obj.C == 22
                                         goal(1,1) = 45;
                                         goal(1,2) = 20;                                    
                                     else
                                         goal(1,1) = 45;
                                         goal(1,2) = c + 2;                                 
                                     end
                                 end
                             else  %rΪ����
                                 c1 = obj.C + 1;
                                 c2 = obj.C - 1;
                                 if mod(c1,4) == 0
                                     goal(1,1) = 45;
                                     goal(1,2) = c1;                             
                                 else
                                     goal(1,1) = 45;
                                     goal(1,2) = c2;                             
                                 end
                             end
                         end
                     elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(45,5) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 45;
                         goal(1,2) = 4;
                     elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(45,5) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 47;
                         goal(1,2) = 4;                      
                     end  
%                      obj.ArrayNumber(4,1) = obj.ArrayNumber(4,1) + 1;
                 elseif obj.ArrayNumber(3,1) == obj.ArrayNumber(4,1)  %һ����������=�����������������ݾ���Զ����ѡ
                     if (44-obj.R)>(obj.C-4)  %ȥ����
                         if obj.Column1cars == 0   %��һ��û�г�
                             if c == 4
                                 if (r == 24)||(r == 25)
                                     goal(1,1) = 26;
                                     goal(1,2) = 3;                                 
                                 else
                                     goal(1,1) = r;
                                     goal(1,2) = 3;
                                 end
                             else
                                 if mod(r,2) == 0  %cΪż��
                                     if mod(r,4) ~= 0
                                         goal(1,1) = obj.R;
                                         goal(1,2) = 3;
                                     else
                                         if obj.C == 24
                                             goal(1,1) = 26;
                                             goal(1,2) = 3;                                    
                                         else
                                             goal(1,1) = obj.R - 2;
                                             goal(1,2) = 3;                                 
                                         end
                                     end
                                 else  %rΪ����
                                     r1 = obj.R + 1;
                                     r2 = obj.R - 1;
                                     if mod(r1,4) ~= 0
                                         goal(1,1) = r1;
                                         goal(1,2) = 3;                             
                                     else
                                         goal(1,1) = r2;
                                         goal(1,2) = 3;                             
                                     end
                                 end
                             end
                         elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(43,3) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 44;
                             goal(1,2) = 3;
                         elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(43,3) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 44;
                             goal(1,2) = 1;                      
                         end      
%                          obj.ArrayNumber(3,1) = obj.ArrayNumber(3,1) + 1;                         
                     elseif (44-obj.R)<(obj.C-4)  %ȥ����
                         if obj.Column4cars == 0   %��һ��û�г�
                             if r == 44
                                 if (c == 23)||(c == 24)
                                     goal(1,1) = 45;
                                     goal(1,2) = 20;                                 
                                 else
                                     goal(1,1) = 45;
                                     goal(1,2) = c;
                                 end
                             else
                                 if mod(c,2) == 0  %cΪż��
                                     if mod(c,4) == 0
                                         if c == 24
                                             goal(1,1) = 45;
                                             goal(1,2) = 20;                                         
                                         else
                                             goal(1,1) = 45;
                                             goal(1,2) = c;
                                         end
                                     else
                                         if obj.C == 22
                                             goal(1,1) = 45;
                                             goal(1,2) = 20;                                    
                                         else
                                             goal(1,1) = 45;
                                             goal(1,2) = c + 2;                                 
                                         end
                                     end
                                 else  %rΪ����
                                     c1 = obj.C + 1;
                                     c2 = obj.C - 1;
                                     if mod(c1,4) == 0
                                         goal(1,1) = 45;
                                         goal(1,2) = c1;                             
                                     else
                                         goal(1,1) = 45;
                                         goal(1,2) = c2;                             
                                     end
                                 end
                             end
                         elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(45,5) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 45;
                             goal(1,2) = 4;
                         elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(45,5) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 47;
                             goal(1,2) = 4;                      
                         end  
%                          obj.ArrayNumber(4,1) = obj.ArrayNumber(4,1) + 1;                         
                     end
                 end                 
                 
%                  %���ݲ�ͬ������ز�ͬĿ���
%                  if obj.Column1cars == 0   %��һ��û�г�
%                      if mod(r,2) == 0  %rΪż��
%                          if mod(r,4) ~= 0
%                              goal(1,1) = obj.R;
%                              goal(1,2) = 3;
%                          else
%                              if obj.R == 24
%                                  goal(1,1) = 26;
%                                  goal(1,2) = 3;                                 
%                              else
%                                  goal(1,1) = obj.R - 2;
%                                  goal(1,2) = 3;                                             
%                              end
%                          end
%                      else  %rΪ����
%                          r1 = obj.R + 1;
%                          r2 = obj.R - 1;
%                          if mod(r1,4) ~= 0
%                              goal(1,1) = r1;
%                              goal(1,2) = 3;                             
%                          else
%                              goal(1,1) = r2;
%                              goal(1,2) = 3;                             
%                          end
%                      end
%                  elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(27,3) ~= 1)   %��һ���г����ڶ���û�г�
%                      goal(1,1) = 26;
%                      goal(1,2) = 3;
%                  elseif ((obj.Column3cars == 0)&&(obj.Column2cars == 1))||(obj.NowRobotLocation(27,3) == 1)  %��һ����ڶ��о��г�
%                      goal(1,1) = 26;
%                      goal(1,2) = 1;   
%                  elseif (obj.Column4cars == 0)&&(obj.Column3cars == 1)
%                      goal(1,1) = 47;
%                      goal(1,2) = 1;                     
%                  elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)
%                      goal(1,1) = 46;
%                      goal(1,2) = 1;                     
%                  elseif obj.Column5cars == 1
%                      goal(1,1) = 26;
%                      goal(1,2) = 1;                     
%                  end 
                 
            elseif a == 3
                 for i = 43:(-1):26
                     if obj.NowRobotLocation(45,i) == 1
                         obj.Column1cars = 1;
                         break;
                     else
                         obj.Column1cars = 0;
                     end
                 end
                 for i = 25:1:43
                     if obj.NowRobotLocation(46,i) == 1
                         obj.Column2cars = 1;
                         break;
                     else
                         obj.Column2cars = 0;
                     end
                 end
                 for i = 43:(-1):25
                     if obj.NowRobotLocation(47,i) == 1
                         obj.Column3cars = 1;
                         break;
                     else
                         obj.Column3cars = 0;
                     end
                 end  
                 for i = 43:(-1):26
                     if obj.NowRobotLocation(i,45) == 1
                         obj.Column4cars = 1;
                         break;
                     else
                         obj.Column4cars = 0;
                     end
                 end                  
                 for i = 25:1:43
                     if obj.NowRobotLocation(i,46) == 1
                         obj.Column5cars = 1;
                         break;
                     else
                         obj.Column5cars = 0;
                     end
                 end                   
                 for i = 43:(-1):25
                     if obj.NowRobotLocation(i,47) == 1
                         obj.Column6cars = 1;
                         break;
                     else
                         obj.Column6cars = 0;
                     end
                 end         
                 
                  if obj.ArrayNumber(5,1)<obj.ArrayNumber(6,1)  %�����ĳ�����������ѡ��ȥ����
                     if obj.Column1cars == 0   %��һ��û�г�
                         if r == 44
                             if (c == 24)||(c == 25)
                                 goal(1,1) = 45;
                                 goal(1,2) = 26;                                 
                             else
                                 goal(1,1) = 45;
                                 goal(1,2) = c;
                             end
                         else
                             if mod(c,2) == 0  %cΪż��
                                 if mod(c,4) == 0
                                     if c == 24
                                         goal(1,1) = 45;
                                         goal(1,2) = 26;     
                                     elseif c == 44
                                         goal(1,1) = 45;
                                         goal(1,2) = 40;
                                     else
                                         goal(1,1) = 45;
                                         goal(1,2) = obj.C;
                                     end
                                 else
                                     if obj.C == 26
                                         goal(1,1) = 45;
                                         goal(1,2) = 28;                                    
                                     else
                                         goal(1,1) = 45;
                                         goal(1,2) = obj.C - 2;                                 
                                     end
                                 end
                             else  %rΪ����
                                 c1 = obj.C + 1;
                                 c2 = obj.C - 1;
                                 if mod(c1,4) ~= 0
                                     goal(1,1) = 3;
                                     goal(1,2) = c1;                             
                                 else
                                     goal(1,1) = 3;
                                     goal(1,2) = c2;                             
                                 end
                             end
                         end
                     elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(45,43) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 45;
                         goal(1,2) = 44;
                     elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(45,43) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 47;
                         goal(1,2) = 44;                      
                     end      
%                      obj.ArrayNumber(5,1) = obj.ArrayNumber(5,1) + 1;
                 elseif obj.ArrayNumber(5,1)>obj.ArrayNumber(6,1)  %�����ĳ�����������ѡ������
                     if obj.Column4cars == 0   %��һ��û�г�
                         if c == 44
                             if (r == 24)||(c == 25)
                                 goal(1,1) = 28;
                                 goal(1,2) = 45;                                 
                             else
                                 goal(1,1) = r;
                                 goal(1,2) = 45;
                             end
                         else
                             if mod(r,2) == 0  %cΪż��
                                 if mod(r,4) == 0
                                     if r == 24
                                         goal(1,1) = 28;
                                         goal(1,2) = 45;                                         
                                     else
                                         goal(1,1) = obj.R;
                                         goal(1,2) = 45;
                                     end
                                 else
                                     if r == 26
                                         goal(1,1) = 28;
                                         goal(1,2) = 45;                                    
                                     else
                                         goal(1,1) = obj.R - 2;
                                         goal(1,2) = 45;                                 
                                     end
                                 end
                             else  %rΪ����
                                 if r == 25
                                     goal(1,1) = 28;
                                     goal(1,2) = 45;
                                 else
                                     r1 = obj.R + 1;
                                     r2 = obj.R - 1;
                                     if mod(r1,4) == 0
                                         goal(1,1) = r1;
                                         goal(1,2) = 3;                             
                                     else
                                         goal(1,1) = r2;
                                         goal(1,2) = 3;                             
                                     end
                                 end
                             end
                         end
                     elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(43,45) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 44;
                         goal(1,2) = 45;
                     elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(43,45) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 44;
                         goal(1,2) = 47;                      
                     end  
%                      obj.ArrayNumber(6,1) = obj.ArrayNumber(6,1) + 1;
                 elseif obj.ArrayNumber(5,1) == obj.ArrayNumber(6,1)  %������������=�����������������ݾ���Զ����ѡ
                     if (44-obj.R)<(44-obj.C)  %ȥ����
                         if obj.Column1cars == 0   %��һ��û�г�
                             if r == 44
                                 if (c == 24)||(c == 25)
                                     goal(1,1) = 45;
                                     goal(1,2) = 26;                                 
                                 else
                                     goal(1,1) = 45;
                                     goal(1,2) = c;
                                 end
                             else
                                 if mod(c,2) == 0  %cΪż��
                                     if mod(c,4) == 0
                                         if c == 24
                                             goal(1,1) = 45;
                                             goal(1,2) = 26;     
                                         elseif c == 44
                                             goal(1,1) = 45;
                                             goal(1,2) = 40;
                                         else
                                             goal(1,1) = 45;
                                             goal(1,2) = obj.C;
                                         end
                                     else
                                         if obj.C == 26
                                             goal(1,1) = 45;
                                             goal(1,2) = 28;                                    
                                         else
                                             goal(1,1) = 45;
                                             goal(1,2) = obj.C - 2;                                 
                                         end
                                     end
                                 else  %rΪ����
                                     c1 = obj.C + 1;
                                     c2 = obj.C - 1;
                                     if mod(c1,4) ~= 0
                                         goal(1,1) = 3;
                                         goal(1,2) = c1;                             
                                     else
                                         goal(1,1) = 3;
                                         goal(1,2) = c2;                             
                                     end
                                 end
                             end
                         elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(45,43) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 45;
                             goal(1,2) = 44;
                         elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(45,43) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 47;
                             goal(1,2) = 44;                      
                         end      
%                          obj.ArrayNumber(5,1) = obj.ArrayNumber(5,1) + 1;                        
                     elseif (44-obj.R)>(44-obj.C)  %ȥ����
                         if obj.Column4cars == 0   %��һ��û�г�
                             if c == 44
                                 if (r == 24)||(c == 25)
                                     goal(1,1) = 28;
                                     goal(1,2) = 45;                                 
                                 else
                                     goal(1,1) = r;
                                     goal(1,2) = 45;
                                 end
                             else
                                 if mod(r,2) == 0  %cΪż��
                                     if mod(r,4) == 0
                                         if r == 24
                                             goal(1,1) = 28;
                                             goal(1,2) = 45;                                         
                                         else
                                             goal(1,1) = obj.R;
                                             goal(1,2) = 45;
                                         end
                                     else
                                         if r == 26
                                             goal(1,1) = 28;
                                             goal(1,2) = 45;                                    
                                         else
                                             goal(1,1) = obj.R - 2;
                                             goal(1,2) = 45;                                 
                                         end
                                     end
                                 else  %rΪ����
                                     if r == 25
                                         goal(1,1) = 28;
                                         goal(1,2) = 45;
                                     else
                                         r1 = obj.R + 1;
                                         r2 = obj.R - 1;
                                         if mod(r1,4) == 0
                                             goal(1,1) = r1;
                                             goal(1,2) = 3;                             
                                         else
                                             goal(1,1) = r2;
                                             goal(1,2) = 3;                             
                                         end
                                     end
                                 end
                             end
                         elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(43,45) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 44;
                             goal(1,2) = 45;
                         elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(43,45) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 44;
                             goal(1,2) = 47;                      
                         end  
%                          obj.ArrayNumber(6,1) = obj.ArrayNumber(6,1) + 1;                     
                     end
                 end                
                 
%                  %���ݲ�ͬ������ز�ͬĿ���
%                  if obj.Column1cars == 0   %��һ��û�г�
%                      if mod(r,2) == 0  %rΪż��
%                          if mod(r,4) == 0
%                              if obj.R == 24
%                                  goal(1,1) = 22;
%                                  goal(1,2) = 45;
%                              elseif r == 4
%                                  goal(1,1) = 8;
%                                  goal(1,2) = 45;                                 
%                              else
%                                  goal(1,1) = obj.R;
%                                  goal(1,2) = 45;                                 
%                              end
%                          else
%                              if obj.R == 22
%                                  goal(1,1) = 22;
%                                  goal(1,2) = 45;                                    
%                              else
%                                  goal(1,1) = obj.R + 2;
%                                  goal(1,2) = 45;                                 
%                              end
%                          end
%                      else  %rΪ����
%                          if obj.R == 23
%                              goal(1,1) = 22;
%                              goal(1,2) = 45;
%                          else
%                              r1 = obj.R + 1;
%                              r2 = obj.R - 1;
%                              if mod(r1,4) == 0
%                                  goal(1,1) = r1;
%                                  goal(1,2) = 45;                             
%                              else
%                                  goal(1,1) = r2;
%                                  goal(1,2) = 45;                             
%                              end                             
%                          end
%                      end
%                  elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(21,45) ~= 1)  %��һ���г����ڶ���û�г�
%                      goal(1,1) = 22;
%                      goal(1,2) = 45;
%                  elseif ((obj.Column3cars == 0)&&(obj.Column2cars == 1))||(obj.NowRobotLocation(21,45) == 1)  %��һ����ڶ��о��г�
%                      goal(1,1) = 22;
%                      goal(1,2) = 47;   
%                  elseif (obj.Column4cars == 0)&&(obj.Column3cars == 1)
%                      goal(1,1) = 1;
%                      goal(1,2) = 47;                     
%                  elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)
%                      goal(1,1) = 2;
%                      goal(1,2) = 47;                     
%                  elseif obj.Column5cars == 1
%                      goal(1,1) = 22;
%                      goal(1,2) = 47;                     
%                  end            
                
            elseif a == 4
                 for i = 5:1:22
                     if obj.NowRobotLocation(i,45) == 1
                         obj.Column1cars = 1;
                         break;
                     else
                         obj.Column1cars = 0;
                     end
                 end
                 for i = 23:(-1):5
                     if obj.NowRobotLocation(i,46) == 1
                         obj.Column2cars = 1;
                         break;
                     else
                         obj.Column2cars = 0;
                     end
                 end
                 for i = 5:1:23
                     if obj.NowRobotLocation(i,47) == 1
                         obj.Column3cars = 1;
                         break;
                     else
                         obj.Column3cars = 0;
                     end
                 end  
                 for i = 43:(-1):26
                     if obj.NowRobotLocation(3,i) == 1
                         obj.Column4cars = 1;
                         break;
                     else
                         obj.Column4cars = 0;
                     end
                 end                  
                 for i = 25:1:43
                     if obj.NowRobotLocation(2,i) == 1
                         obj.Column5cars = 1;
                         break;
                     else
                         obj.Column5cars = 0;
                     end
                 end  
                 for i = 43:(-1):25
                     if obj.NowRobotLocation(1,i) == 1
                         obj.Column6cars = 1;
                         break;
                     else
                         obj.Column6cars = 0;
                     end
                 end                  
                 
                 if obj.ArrayNumber(7,1)<obj.ArrayNumber(8,1)  %�����ĳ����ڰ�����ѡ��ȥ����
                     if obj.Column1cars == 0   %��һ��û�г�
                         if c == 44
                             if (r == 23)||(r == 24)
                                 goal(1,1) = 22;
                                 goal(1,2) = 45;                                 
                             else
                                 goal(1,1) = r;
                                 goal(1,2) = 45;
                             end
                         else
                             if mod(r,2) == 0  %cΪż��
                                 if (mod(r,4) == 0)&&(r ~= 4)
                                     if r == 24
                                         goal(1,1) = 22;
                                         goal(1,2) = 45;                                         
                                     else
                                         goal(1,1) = obj.R;
                                         goal(1,2) = 45;
                                     end
                                 else
                                     if r == 22
                                         goal(1,1) = 20;
                                         goal(1,2) = 45; 
                                     elseif r == 4
                                         goal(1,1) = 8;
                                         goal(1,2) = 45;
                                     else
                                         goal(1,1) = obj.R + 2;
                                         goal(1,2) = 45;                                 
                                     end
                                 end
                             else  %rΪ����
                                 if r == 23
                                     goal(1,1) = 20;
                                     goal(1,2) = 45;
                                 else
                                     r1 = obj.R + 1;
                                     r2 = obj.R - 1;
                                     if mod(r1,4) ~= 0
                                         goal(1,1) = r1;
                                         goal(1,2) = 3;                             
                                     else
                                         goal(1,1) = r2;
                                         goal(1,2) = 3;                             
                                     end
                                 end
                             end
                         end
                     elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(5,45) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 4;
                         goal(1,2) = 45;
                     elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(5,45) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 4;
                         goal(1,2) = 47;                      
                     end      
%                      obj.ArrayNumber(7,1) = obj.ArrayNumber(7,1) + 1;
                 elseif obj.ArrayNumber(7,1)>obj.ArrayNumber(8,1)  %�����ĳ����ڰ�����ѡ��ȥ����
                     if obj.Column4cars == 0   %��һ��û�г�
                         if r == 4
                             if (c == 24)||(c == 25)
                                 goal(1,1) = 3;
                                 goal(1,2) = 26;                                 
                             else
                                 goal(1,1) = 3;
                                 goal(1,2) = c;
                             end
                         else
                             if mod(c,2) == 0  %cΪż��
                                 if (mod(c,4) == 0)&&(c ~= 44)
                                     if c == 24
                                         goal(1,1) = 3;
                                         goal(1,2) = 26;                                         
                                     else
                                         goal(1,1) = 3;
                                         goal(1,2) = c - 2;
                                     end
                                 else
                                     goal(1,1) = 3;
                                     goal(1,2) = c;                                 
                                 end
                             else  %rΪ����
                                 if c == 43
                                     goal(1,1) = 3;
                                     goal(1,2) = 42;
                                 else
                                     c1 = obj.C + 1;
                                     c2 = obj.C - 1;
                                     if mod(c1,4) == 0
                                         goal(1,1) = 3;
                                         goal(1,2) = c1;                             
                                     else
                                         goal(1,1) = 3;
                                         goal(1,2) = c2;                             
                                     end
                                 end
                             end
                         end
                     elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(3,43) ~= 1)  %��һ���г����ڶ���û�г�
                         goal(1,1) = 3;
                         goal(1,2) = 44;
                     elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(3,43) == 1)  %��һ����ڶ��о��г�
                         goal(1,1) = 1;
                         goal(1,2) = 44;                      
                     end  
%                      obj.ArrayNumber(8,1) = obj.ArrayNumber(8,1) + 1;
                 elseif obj.ArrayNumber(7,1) == obj.ArrayNumber(8,1)  %һ����������=�����������������ݾ���Զ����ѡ
                     if (obj.R-4)>(44-obj.C)  %ȥ����
                         if obj.Column1cars == 0   %��һ��û�г�
                             if c == 44
                                 if (r == 23)||(r == 24)
                                     goal(1,1) = 22;
                                     goal(1,2) = 45;                                 
                                 else
                                     goal(1,1) = r;
                                     goal(1,2) = 45;
                                 end
                             else
                                 if mod(r,2) == 0  %cΪż��
                                     if (mod(r,4) == 0)&&(r ~= 4)
                                         if r == 24
                                             goal(1,1) = 20;
                                             goal(1,2) = 45;                                         
                                         else
                                             goal(1,1) = obj.R;
                                             goal(1,2) = 45;
                                         end
                                     else
                                         if r == 22
                                             goal(1,1) = 20;
                                             goal(1,2) = 45;   
                                         elseif r == 4
                                             goal(1,1) = 8;
                                             goal(1,2) = 45;
                                         else
                                             goal(1,1) = obj.R + 2;
                                             goal(1,2) = 45;                                 
                                         end
                                     end
                                 else  %rΪ����
                                     if r == 23
                                         goal(1,1) = 20;
                                         goal(1,2) = 45;
                                     else
                                         r1 = obj.R + 1;
                                         r2 = obj.R - 1;
                                         if mod(r1,4) ~= 0
                                             goal(1,1) = r1;
                                             goal(1,2) = 3;                             
                                         else
                                             goal(1,1) = r2;
                                             goal(1,2) = 3;                             
                                         end
                                     end
                                 end
                             end
                         elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(5,45) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 4;
                             goal(1,2) = 45;
                         elseif (obj.Column2cars == 1)||(obj.NowRobotLocation(5,45) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 4;
                             goal(1,2) = 47;                      
                         end      
%                          obj.ArrayNumber(7,1) = obj.ArrayNumber(7,1) + 1;                         
                     elseif (obj.R-4)<(44-obj.C)  %ȥ����
                         if obj.Column4cars == 0   %��һ��û�г�
                             if r == 4
                                 if (c == 24)||(c == 25)
                                     goal(1,1) = 3;
                                     goal(1,2) = 26;                                 
                                 else
                                     goal(1,1) = 3;
                                     goal(1,2) = c;
                                 end
                             else
                                 if mod(c,2) == 0  %cΪż��
                                     if (mod(c,4) == 0)&&(c ~= 44)
                                         if c == 24
                                             goal(1,1) = 3;
                                             goal(1,2) = 26;                                         
                                         else
                                             goal(1,1) = 3;
                                             goal(1,2) = c - 2;
                                         end
                                     else
                                         goal(1,1) = 3;
                                         goal(1,2) = c;                                 
                                     end
                                 else  %rΪ����
                                     if c == 43
                                         goal(1,1) = 3;
                                         goal(1,2) = 42;
                                     else
                                         c1 = obj.C + 1;
                                         c2 = obj.C - 1;
                                         if mod(c1,4) == 0
                                             goal(1,1) = 3;
                                             goal(1,2) = c1;                             
                                         else
                                             goal(1,1) = 3;
                                             goal(1,2) = c2;                             
                                         end
                                     end
                                 end
                             end
                         elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)&&(obj.NowRobotLocation(3,43) ~= 1)  %��һ���г����ڶ���û�г�
                             goal(1,1) = 3;
                             goal(1,2) = 44;
                         elseif (obj.Column5cars == 1)||(obj.NowRobotLocation(3,43) == 1)  %��һ����ڶ��о��г�
                             goal(1,1) = 1;
                             goal(1,2) = 44;                      
                         end  
%                          obj.ArrayNumber(8,1) = obj.ArrayNumber(8,1) + 1;                        
                     end
                 end                   
                 
                 
%                  %���ݲ�ͬ������ز�ͬĿ���
%                  if obj.Column1cars == 0   %��һ��û�г�
%                      if mod(r,2) == 0  %rΪż��
%                          if mod(r,4) == 0
%                              if r == 24
%                                  goal(1,1) = 26;
%                                  goal(1,2) = 45;                                    
%                              else
%                                  goal(1,1) = obj.R;
%                                  goal(1,2) = 45; 
%                              end
%                          else
%                              if r == 26
%                                  goal(1,1) = 26;
%                                  goal(1,2) = 45;                                    
%                              else                                 
%                                  goal(1,1) = obj.R - 2;
%                                  goal(1,2) = 45;    
%                              end
%                          end
%                      else  %rΪ����
%                          if r == 25
%                              goal(1,1) = 26;
%                              goal(1,2) = 45;                                 
%                          else
%                              r1 = obj.R + 1;
%                              r2 = obj.R - 1;
%                              if mod(r1,4) == 0
%                                  goal(1,1) = r1;
%                                  goal(1,2) = 45;                             
%                              else
%                                  goal(1,1) = r2;
%                                  goal(1,2) = 45;                             
%                              end     
%                          end
%                      end
%                  elseif (obj.Column2cars == 0)&&(obj.Column1cars == 1)&&(obj.NowRobotLocation(27,45) ~= 1)  %��һ���г����ڶ���û�г�
%                      goal(1,1) = 26;
%                      goal(1,2) = 45;
%                  elseif ((obj.Column3cars == 0)&&(obj.Column2cars == 1))||(obj.NowRobotLocation(27,45) == 1)  %��һ����ڶ��о��г�
%                      goal(1,1) = 26;
%                      goal(1,2) = 47;   
%                  elseif (obj.Column4cars == 0)&&(obj.Column3cars == 1)
%                      goal(1,1) = 47;
%                      goal(1,2) = 47;                     
%                  elseif (obj.Column5cars == 0)&&(obj.Column4cars == 1)
%                      goal(1,1) = 46;
%                      goal(1,2) = 47;                     
%                  elseif obj.Column5cars == 1
%                      goal(1,1) = 26;
%                      goal(1,2) = 47;                     
%                  end                   
            end
        end
        
        function goLocation(obj,goal)
            obj.Rp = obj.R;   %����ԭ�ȵ�λ��
            obj.Cp = obj.C;
            m = mod(obj.R,2);
            n = mod(obj.C,2);
            r = obj.R;        %������һʱ�̵�λ��
            c = obj.C;
            gr = goal(1,1);
            gc = goal(1,2);            
            right = gc - c;
            down = gr - r;       
            
            if obj.Status == 1  %ȥж����
                if obj.GoalChanged == 1  %�������Ҳ�ж����Ŀ���ı���
                    
                    if (r == 3)||(r == 45)||(c == 3)||(c == 45)  %���ô���ɨ�봦
                        if ((r == 3)&&(c == 23))||((r == 3)&&(c ==25))
                            r = r + 1;  
                        elseif ((r == 45)&&(c ==23))||((r == 45)&&(c ==25))
                            r = r - 1;
                        elseif ((r == 23)&&(c == 3))||((r == 25)&&(c == 3))
                            c = c + 1;  
                        elseif ((r == 23)&&(c == 45))||((r == 25)&&(c == 45))
                            c = c - 1;                            
                        end
                    else
                        if (m == 0)&&(n ~= 0)   %rżc��
                            if mod(r,4) == 0   %�ж����е�/���е�
                                if r == 4
                                    c = c - 1; 
                                else
                                    c = c + 1;
                                end
                            else  
                                c = c - 1;
                            end   
                        elseif (m ~= 0)&&(n == 0)  %r��cż
                            if mod(c,4) == 0   %�ж����е�/���е�
                                if c == 44
                                    r = r - 1;
                                else
                                    r = r + 1;                                
                                end
                            else  
                                r = r - 1;
                            end                          
                        elseif (m == 0)&&(n == 0)  %rżcż
                            if (r == 4)&&(c ~= 4)&&(c ~= 44)
                                
                                if mod(gr,2) == 0   %Ŀ�������Ϊż��
                                    if right>0  %ж�������Ҳ�
                                        if down == 0
                                            if mod(c,4) == 0
                                                r = r + 1;
                                            else
                                                c = c - 1;
                                            end                                          
                                        elseif down>0  %����λ�����Ͻ�
                                            if mod(gr,4) == 0
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            else
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            end                                              
                                        end
                                        
                                    else  %ж���������
                                        if down == 0
                                            c = c - 1;                                        
                                        elseif down>0   %����λ�����Ͻ�
                                            if mod(gr,4) ~= 0
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            else
                                                c = c - 1;
                                            end                                          
                                        end
                                    end
                                    
                                else   %Ŀ�������Ϊ����
                                        if right == 0  
                                            if mod(c,4) == 0
                                                r = r + 1; 
                                            else
                                                c = c - 1;
                                            end                                            
                                        elseif right>0  %����λ�����Ͻ�
%                                             if (mod(gc,4) == 0)&&(gc ~= 44)
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    c = c - 1;
                                                end
%                                             else
%                                                 if mod(c,4) == 0
%                                                     r = r + 1;
%                                                 else
%                                                     if mod(r,4) == 0
%                                                         c = c + 1;
%                                                     else
%                                                         r = r - 1;
%                                                     end
%                                                 end
%                                             end                                              
                                        elseif right<0  %����λ�����Ͻ�
                                             if (mod(gc,4) == 0)&&(gc ~= 44)
                                                 c = c - 1;
%                                                 if mod(r,4) ~= 0
%                                                     c = c - 1;
%                                                 else

%                                                 end
                                             else
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        c = c - 1;
                                                    end                                                 
%                                                 if mod(c,4) == 0
%                                                     r = r + 1;
%                                                 else
%                                                     if mod(r,4) ~= 0
%                                                         c = c - 1;
%                                                     else
%                                                         r = r - 1;
%                                                     end
%                                                 end
%                                             end                                               
                                             end
                                        end        
                                end
                                
%                                 if down == 0
%                                     if right<0
%                                         c = c - 1;
%                                     elseif right>0
%                                         if mod(c,4) == 0
%                                             r = r + 1;
%                                         else
%                                             c = c - 1;
%                                         end
%                                     end
%                                 else
%                                     if mod(gr,2) == 0
%                                         if mod(c,4) == 0
%                                             r = r + 1;
%                                         else
%                                             c = c - 1;
%                                         end
%                                     else
%                                         if right>=0
%                                             if mod(c,4) == 0
%                                                 r = r + 1;
%                                             else
%                                                 c = c - 1;
%                                             end
%                                         else
%                                             if mod(gc,4) == 0
%                                                 c = c - 1;
%                                             else
%                                                 if mod(c,4) == 0
%                                                     r = r + 1;
%                                                 else
%                                                     c = c - 1;
%                                                 end
%                                             end                                          
%                                         end                                       
%                                     end
%                                 end
                                elseif (r == 44)&&(c ~= 4)&&(c ~= 44)
                                if mod(gr,2) == 0   %Ŀ�������Ϊż��
                                    if right>0  %ж�������Ҳ�
                                        if down == 0
                                            c = c + 1;                                          
                                        elseif down<0  %����λ�����½�
                                            if (mod(gr,4) == 0)&&(gr ~= 4)
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    c = c + 1;
                                                end
                                            else
%                                                 if mod(r,4) == 0
                                                    c = c + 1;
%                                                 else
%                                                     if mod(c,4) == 0
%                                                         r = r + 1;
%                                                     else
%                                                         c = c - 1;
%                                                     end
%                                                 end
                                            end                                               
                                        end
                                        
                                    else  %ж���������
                                        if down == 0
                                            if mod(c,4) ~= 0
                                                r = r - 1;
                                            else
                                                c = c + 1;
                                            end                                       
                                        elseif down<0   %����λ�����½�
                                            if (mod(gr,4) ~= 0)&&(gr ~= 4)
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    c = c + 1;
                                                end
                                            else
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    c = c + 1;
                                                end
                                            end                                        
                                        end
                                    end
                                    
                                else   %Ŀ�������Ϊ����
                                        if right == 0
                                            if mod(c,4) ~= 0
                                                r = r - 1; 
                                            else
                                                c = c + 1;
                                            end                                             
                                        elseif right>0  %����λ�����½�
                                            if (mod(gc,4) ~= 0)||(gc == 44)
                                                c = c + 1;
                                            else
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    c = c + 1;
                                                end
                                            end                                              
                                        elseif right<0  %����λ�����½�
                                            if mod(gc,4) ~= 0
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    c = c + 1;
                                                end
                                            else
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    c = c + 1;
                                                end                                                
                                            end 
                                        end
                                end                                

                                
%                                 if down == 0
%                                     if right>0
%                                         c = c + 1;
%                                     elseif right<0
%                                         if mod(c,4) ~= 0
%                                             r = r - 1;
%                                         else
%                                             c = c + 1;
%                                         end
%                                     end
%                                 else
%                                     if mod(gr,2) == 0
%                                         if mod(c,4) ~= 0
%                                             r = r - 1;
%                                         else
%                                             c = c + 1;
%                                         end
%                                     else
%                                         if right<=0
%                                             if mod(c,4) ~= 0
%                                                 r = r - 1;
%                                             else
%                                                 c = c + 1;
%                                             end
%                                         else
%                                             if mod(gc,4) ~= 0
%                                                 c = c + 1;
%                                             else
%                                                 if mod(c,4) ~= 0
%                                                     r = r - 1;
%                                                 else
%                                                     c = c + 1;
%                                                 end
%                                             end                                          
%                                         end                                       
%                                     end
%                                 end                                   
                            elseif (c == 4)&&(r ~= 4)&&(r ~= 44)
                                if mod(gr,2) == 0   %Ŀ�������Ϊż��
                                        if down == 0
                                            if mod(r,4) == 0
                                                c = c + 1; 
                                            else
                                                r = r + 1;
                                            end
                                        elseif down>0  %����λ�����Ͻ�
                                            if mod(gr,4) == 0
                                                r = r + 1;
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    r = r + 1;
                                                end
                                            end                                            
                                        elseif down<0  %����λ�����½�
                                            if (mod(gr,4) == 0)&&(gr ~= 4)
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    r = r + 1;
                                                end
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    r = r + 1;
                                                end
                                            end                                               
                                        end
                    
                                else   %Ŀ�������Ϊ����
                                    if down>0  %ж�������²�
                                        if right == 0  
                                            r = r + 1;
                                        elseif right>0  %����λ�����Ͻ�
                                            if (mod(gc,4) == 0)&&(gc ~= 44)
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    r = r + 1;
                                                end
                                            else
                                                r = r + 1;
                                            end                                                                                           
                                        end
                                    else  %ж�������ϲ�
                                        if right == 0
                                            if mod(r,4) == 0
                                                c = c + 1;
                                            else
                                                r = r + 1;
                                            end                                          
                                        elseif right>0  %����λ�����½�
                                            if (mod(gc,4) ~= 0)||(gc == 44)
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    r = r + 1;
                                                end
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    r = r + 1;
                                                end
                                            end                                               
                                        end
                                    end
                                end                                
      
%                                 if right == 0
%                                     if down>0
%                                         r = r + 1;
%                                     elseif down<0
%                                         if mod(r,4) == 0
%                                             c = c + 1;
%                                         else
%                                             r = r + 1;
%                                         end
%                                     end
%                                 else
%                                     if mod(gc,2) == 0
%                                         if mod(r,4) == 0
%                                             c = c + 1;
%                                         else
%                                             r = r + 1;
%                                         end
%                                     else
%                                         if down<=0
%                                             if mod(r,4) == 0
%                                                 c = c + 1;
%                                             else
%                                                 r = r + 1;
%                                             end
%                                         else
%                                             if mod(gr,4) == 0
%                                                 r = r + 1;
%                                             else
%                                                 if mod(r,4) == 0
%                                                     c = c + 1;
%                                                 else
%                                                     r = r + 1;
%                                                 end
%                                             end                                          
%                                         end                                       
%                                     end
%                                 end  
                            elseif (c == 44)&&(r ~= 4)&&(r ~= 44)
                                if mod(gr,2) == 0   %Ŀ�������Ϊż��
                                        if down == 0
                                            if mod(r,4) ~= 0
                                                c = c - 1; 
                                            else
                                                r = r - 1;
                                            end
                                        elseif down>0  %����λ�����Ͻ�
                                            if mod(r,4) ~= 0
                                                c = c - 1;
                                            else
                                                r = r - 1;
                                            end                                           
                                        elseif down<0  %����λ�����½�
                                            if (mod(gr,4) ~= 0)||(gr == 4)
                                                r = r - 1;
                                            else
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    r = r - 1;
                                                end
                                            end                                               
                                        end
                    
                                else   %Ŀ�������Ϊ����
                                    if down>0  %ж�������²�
                                        if right == 0  
                                            if mod(r,4) ~= 0
                                                c = c - 1;
                                            else
                                                r = r - 1;
                                            end
                                        elseif right<0  %����λ�����Ͻ�
                                            if mod(gc,4) == 0
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    r = r - 1;
                                                end
                                            else
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    r = r - 1;
                                                end
                                            end                                                                                           
                                        end
                                    else  %ж�������ϲ�
                                        if right == 0
                                            r = r - 1;                                         
                                        elseif right<0  %����λ�����½�
                                            if mod(gc,4) ~= 0
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    r = r - 1;
                                                end
                                            else
                                                r = r - 1;
                                            end                                               
                                        end
                                    end
                                end                                  
 
%                                 if right == 0
%                                     if down<0
%                                         r = r - 1;
%                                     elseif down>0
%                                         if mod(r,4) ~= 0
%                                             c = c - 1;
%                                         else
%                                             r = r - 1;
%                                         end
%                                     end
%                                 else
%                                     if mod(gc,2) == 0
%                                         if mod(r,4) ~= 0
%                                             c = c - 1;
%                                         else
%                                             r = r - 1;
%                                         end
%                                     else
%                                         if down>=0
%                                             if mod(r,4) ~= 0
%                                                 c = c - 1;
%                                             else
%                                                 r = r - 1;
%                                             end
%                                         else
%                                             if mod(gr,4) ~= 0
%                                                 r = r - 1;
%                                             else
%                                                 if mod(r,4) ~= 0
%                                                     c = c - 1;
%                                                 else
%                                                     r = r - 1;
%                                                 end
%                                             end                                          
%                                         end                                       
%                                     end
%                                 end                                  
                            elseif (r == 4)&&(c == 4)
                                r = r + 1;
                            elseif (r == 44)&&(c == 4)
                                c = c + 1;
                            elseif (r == 4)&&(c == 44)
                                c = c - 1;
                            elseif (r == 44)&&(c == 44)
                                r = r - 1;
                            else
                                if mod(gr,2) == 0   %Ŀ�������Ϊż��
                                    if right>0  %ж�������Ҳ�
                                        if down == 0
                                            if mod(r,4) == 0
                                                c = c + 1; 
                                            else
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    r = r - 1;
                                                end
                                            end
                                        elseif down>0  %����λ�����Ͻ�
                                            if mod(gr,4) == 0
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    if mod(r,4) == 0
                                                        c = c + 1;
                                                    else
                                                        r = r - 1;
                                                    end
                                                end
                                            else
                                                if (gc == 43)&&(c == 42)   %*************************�������*************************
                                                    if mod(c,4) == 0
                                                        r = r + 1; 
                                                    else 
                                                        if mod(r,4) ~= 0
                                                            c = c - 1;
                                                        else
                                                            r = r - 1;
                                                        end
                                                    end
                                                elseif (gc == 43)&&(c ~= 42)
                                                    if mod(c,4) == 0
                                                        r = r + 1; 
                                                    else
                                                        if mod(r,4) == 0
                                                            c = c + 1;
                                                        else
                                                            r = r - 1;
                                                        end                                                        
                                                    end
                                                elseif (c == 40)&&(gc>=41)
                                                    r = r + 1;
                                                else
                                                    if mod(r,4) == 0
                                                        c = c + 1;
                                                    else
                                                        if mod(c,4) == 0
                                                            r = r + 1;
                                                        else
                                                            c = c - 1;
                                                        end
                                                    end
                                                end
                                            end                                            
                                        elseif down<0  %����λ�����½�
                                            if (mod(gr,4) == 0)&&(gr ~= 4)
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    if mod(r,4) == 0
                                                        c = c + 1;
                                                    else
                                                        r = r + 1;
                                                    end
                                                end
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                end
                                            end                                               
                                        end
                                        
                                    else  %ж���������
                                        if down == 0
                                            if mod(r,4) ~= 0
                                                c = c - 1; 
                                            else
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    r = r - 1;
                                                end
                                            end
                                        elseif down>0   %����λ�����Ͻ�
                                            if mod(gr,4) ~= 0
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    if mod(r,4) ~= 0
                                                        c = c - 1;
                                                    else
                                                        r = r - 1;
                                                    end
                                                end
                                            else
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        c = c + 1;
                                                    end
                                                end
                                            end                                          
                                        elseif down<0   %����λ�����½�
                                            if (mod(gr,4) ~= 0)||(gr == 4)
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    if mod(r,4) ~= 0
                                                        c = c - 1;
                                                    else
                                                        r = r + 1;
                                                    end
                                                end
                                            else
                                                if (gc == 5)&&(c == 6)   %*************************�������*************************
                                                    if mod(c,4) ~= 0
                                                        r = r - 1; 
                                                    else 
                                                        if mod(r,4) == 0
                                                            c = c + 1;
                                                        else
                                                            r = r + 1;
                                                        end
                                                    end
                                                elseif (gc == 5)&&(c ~= 6)
                                                    if mod(c,4) ~= 0
                                                        r = r - 1; 
                                                    else
                                                        if mod(r,4) ~= 0
                                                            c = c - 1;
                                                        else
                                                            r = r + 1;
                                                        end                                                        
                                                    end
                                                else
                                                    if mod(r,4) ~= 0
                                                        c = c - 1;
                                                    else
                                                        if mod(c,4) ~= 0
                                                            r = r - 1;
                                                        else
                                                            c = c + 1;
                                                        end
                                                    end
                                                end
                                            end                                        
                                        end
                                    end
                                    
                                else   %Ŀ�������Ϊ����
                                    if down>0  %ж�������²�
                                        if right == 0  
                                            if mod(c,4) == 0
                                                r = r + 1; 
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            end                                            
                                        elseif right>0  %����λ�����Ͻ�
                                            if (mod(gc,4) == 0)&&(gc ~= 44)
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                end
                                            else
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    if mod(r,4) == 0
                                                        c = c + 1;
                                                    else
                                                        r = r - 1;
                                                    end
                                                end
                                            end                                              
                                        elseif right<0  %����λ�����Ͻ�
                                            if mod(gc,4) == 0
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        c = c + 1;
                                                    end
                                                end
                                            else
                                                if (gr == 43)&&(r == 42)   %*************************�������*************************
                                                    if mod(r,4) ~= 0
                                                        c = c - 1; 
                                                    else 
                                                        if mod(c,4) ~= 0
                                                            r = r - 1;
                                                        else
                                                            c = c + 1;
                                                        end
                                                    end
                                                elseif (gr == 43)&&(r ~= 42)
                                                    if mod(r,4) ~= 0
                                                        c = c + 1; 
                                                    else
                                                        if mod(c,4) == 0
                                                            r = r + 1;
                                                        else
                                                            c = c - 1;
                                                        end                                                        
                                                    end
                                                else
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        if mod(r,4) ~= 0
                                                            c = c - 1;
                                                        else
                                                            r = r - 1;
                                                        end
                                                    end
                                                end
                                            end                                               
                                        end
                                    else  %ж�������ϲ�
                                        if right == 0
                                            if mod(c,4) ~= 0
                                                r = r - 1; 
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            end                                             
                                        elseif right>0  %����λ�����½�
                                            if (mod(gc,4) ~= 0)||(gc == 44)
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    if mod(c,4) ~= 0
                                                        r = r - 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                end
                                            else
                                                if (gr == 5)&&(r == 6)   %*************************�������*************************
                                                    if mod(r,4) == 0
                                                        c = c + 1; 
                                                    else 
                                                        if mod(c,4) == 0
                                                            r = r + 1;
                                                        else
                                                            c = c - 1;
                                                        end
                                                    end
                                                elseif (gr == 5)&&(r ~= 6)
                                                    if mod(r,4) == 0
                                                        c = c + 1; 
                                                    else
                                                        if mod(c,4) ~= 0
                                                            r = r - 1;
                                                        else
                                                            c = c - 1;
                                                        end                                                        
                                                    end
                                                elseif (r == 8)&&(gr<=7)
                                                    c = c + 1;
                                                else                                                
                                                    if mod(c,4) ~= 0
                                                        r = r - 1;
                                                    else
                                                        if mod(r,4) == 0
                                                            c = c + 1;
                                                        else
                                                            r = r + 1;
                                                        end
                                                    end
                                                end
                                            end                                              
                                        elseif right<0  %����λ�����½�
                                            if mod(gc,4) ~= 0
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    if mod(c,4) ~= 0
                                                        r = r - 1;
                                                    else
                                                        c = c + 1;
                                                    end
                                                end
                                            else
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    if mod(r,4) ~= 0
                                                        c = c - 1;
                                                    else
                                                        r = r + 1;
                                                    end
                                                end
                                            end 
                                        end
                                    end
                                end

%                                 if (down == 1)||(down == -1)
%                                     if ((right>0)&&(mod(r,4) == 0))||((right<0)&&(mod(r,4) ~= 0))
%                                         c = c + sign(right);
%                                     else
%                                         if mod(c,4) == 0
%                                             r = r + 1;
%                                         else
%                                             r = r - 1;
%                                         end
%                                     end
%                                 else 
%                                     if (r == 8)&&(gr == 5)    %�������
%                                         if (right == 1)||(right == -1)
%                                             if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
%                                                 r = r + sign(down);
%                                             else
%                                                 if mod(r,4) == 0
%                                                     c = c + 1;
%                                                 else
%                                                     c = c - 1;
%                                                 end
%                                             end
%                                         else
%                                             if right>0
%                                                c = c + 1; 
%                                             else
%                                                 if mod(c,4) ~= 0
%                                                     r = r - 1;
%                                                 else
%                                                     c = c + 1; 
%                                                 end
%                                             end                                        
%                                         end
%                                     else
%                                         if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
%                                             r = r + sign(down);
%                                         else
%                                             if mod(r,4) == 0
%                                                 c = c + 1;
%                                             else
%                                                 c = c - 1;  
%                                             end
%                                         end
%                                     end
%                                 end   
                            end
                        end
                    end 
                    
                    
                else   %���������Ҳ�ж��
                    if (r == 3)||(r == 45)||(c == 3)||(c == 45)  %���ô���ɨ�봦
                        if ((r == 3)&&(c == 23))||((r == 3)&&(c == 25))
                            r = r + 1;  
                        elseif ((r == 45)&&(c == 23))||((r == 45)&&(c == 25))
                            r = r - 1;
                        elseif ((r == 23)&&(c == 3))||((r == 25)&&(c == 3))
                            c = c + 1;
                        elseif ((r == 23)&&(c == 45))||((r == 25)&&(c == 45))
                            c = c - 1;
                        end
                    else
                        if (m == 0)&&(n ~= 0)   %rżc��
                            if mod(r,4) == 0   %�ж����е�/���е�
                                if r == 4
                                    c = c - 1; 
                                else
                                    c = c + 1;
                                end
                            else  
                                c = c - 1;
                            end   
                        elseif (m ~= 0)&&(n == 0)  %r��cż
                            if mod(c,4) == 0   %�ж����е�/���е�
                                if c == 44
                                    r = r - 1;
                                else
                                    r = r + 1;                                
                                end
                            else  
                                r = r - 1;
                            end                          
                        elseif (m == 0)&&(n == 0)  %rżcż
                            if (r == 4)&&(c == 4)
                                r = r + 1;
                            elseif (r == 44)&&(c == 4)
                                c = c + 1;
                            elseif (r == 4)&&(c == 44)
                                c = c - 1;
                            elseif (r == 44)&&(c == 44)
                                r = r - 1;
                            elseif r == 4
                                if (down>0)&&(mod(c,4) == 0)
                                    r = r + sign(down); 
                                else
                                    c = c - 1;
                                end
                            elseif r == 44
                                if (down<0)&&(mod(c,4) ~= 0)
                                    r = r + sign(down); 
                                else
                                    c = c + 1;
                                end    
                            elseif c == 4
                                if (right>0)&&(mod(r,4) == 0)
                                    c = c + sign(right); 
                                else
                                    r = r + 1;
                                end                                
                            elseif c == 44
                                if (right<0)&&(mod(r,4) ~= 0)
                                    c = c + sign(right);
                                else
                                    r = r - 1;
                                end                                
                            else
                                if (down == 1)||(down == -1)
                                    if ((right>0)&&(mod(r,4) == 0))||((right<0)&&(mod(r,4) ~= 0))
                                        c = c + sign(right);
                                    else
                                        if mod(c,4) == 0
                                            r = r + 1;
                                        else
                                            r = r - 1;
                                        end
                                    end
                                else 
                                    if (r == 8)&&(gr == 5)    %�������
                                        if (right == 1)||(right == -1)
                                            if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
                                                r = r + sign(down);
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            end
                                        else
                                            if right>0
                                               c = c + 1; 
                                            else
                                                if mod(c,4) ~= 0
                                                    r = r - 1;
                                                else
                                                    c = c + 1; 
                                                end
                                            end                                        
                                        end
                                    else
                                        if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
                                            r = r + sign(down);
                                        else
                                            if mod(r,4) == 0
                                                c = c + 1;
                                            else
                                                c = c - 1;  
                                            end
                                        end
                                    end
                                end   
                            end
                        end
                    end
                end
                        
%                             if (right == 1)||(right == -1)
%                                 if ((down>0)&&(mod(c,4) == 0)&&(c ~= 44))||((down<0)&&(mod(c,4) ~= 0))
%                                     r = r + sign(down);
%                                 else
%                                     if mod(r,4) == 0
%                                         c = c + 1;
%                                     else
%                                         c = c - 1;
%                                     end
%                                 end
%                             else 
%                                 if ((right>0)&&(mod(r,4) == 0))||((right<0)&&(mod(r,4) ~= 0))
%                                     c = c + sign(right);
%                                 else
%                                     if mod(c,4) == 0
%                                         if c == 44
%                                             r = r - 1;
%                                         else
%                                             r = r + 1;                                           
%                                         end
%                                     else
%                                         r = r - 1;  
%                                     end
%                                 end
%                             end
                        
                        
                        
                        
%                         if ((right>0)&&(mod(r,4) == 0))||((right<0)&&(mod(r,4) ~= 0))
%                             if (right == 1)||(right == -1) 
%                                 if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
%                                     r = r + sign(down);
%                                 else
%                                     c = c + sign(right);
%                                 end
%                             else
%                                 c = c + sign(right);
%                             end
%                         else
%                             if mod(c,4) == 0
%                                 r = r + 1;
%                             else
%                                 r = r - 1;
%                             end                            
%                         end
                        
                        
%                         if((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0)) %�ж�Ŀ��㷽���Ƿ�����ڵ�·����һ��
%                             if (down == 1)||(down == -1) 
%                                 if ((right>0)&&(mod(r,4) == 0))||((right<0)&&(mod(r,4) ~= 0))
%                                     c = c + sign(right);
%                                 else
%                                     r = r + sign(down);
%                                 end
%                             else
%                                 r = r + sign(down);                                
%                             end
%                         else
%                             if mod(r,4) == 0
%                                 c = c + 1;
%                             else
%                                 c = c - 1;
%                             end
%                         end
                        
%                         if (right == 1)||(right == -1)  %�з������ж����ֻ��һ����
%                             if ((down<0)&&(mod(c,4) ~= 0))||((down>0)&&(mod(c,4) == 0)) %ж�������Ϸ����ҵ�·�����е�/ж�������·����ҵ�·�����е�
%                                 if (down<0)
%                                     r = r - 1;
%                                 else
%                                     r = r + 1;
%                                 end
%                             else 
%                                 if mod(r,4) == 0
%                                     c = c + 1;
%                                 else
%                                     c = c - 1;
%                                 end
%                             end
%                         else    %�з������ж���㲢����ֻ��һ����
%                             if mod(r,4) == 0
%                                 c = c + 1;
%                             else
%                                 c = c - 1;
%                             end
%                         end
                if (r == 0)||(r == 48)||(c == 0)||(c == 48)
                    disp(obj.SerialNumber);
                else
                    if obj.NowRobotLocation(r,c) == 0
                        obj.R = r;
                        obj.C = c;
                        obj.Odom = obj.Odom + 1;
                        obj.EveryTaskOdom = obj.EveryTaskOdom + 1;
                    else
                        obj.R = obj.Rp;
                        obj.C = obj.Cp;                    
                    end
                end
   
            elseif obj.Status == 2   %ȥ�ŶӴ�
                number = obj.getdistrict(); %��ȡ������
%                 disp(number);
                if number == 1 
                    if gr<=3  %һ��
                        if (r == gr)&&(c == gc)
                            if (gr == 3)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation(r,(c+1)) == 0
                                    c = c + 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 1)&&(gc == 4)  %���Ҫ����ڶ�/����
                                if obj.Column3cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation(r,(c+1)) == 0
                                        c = c + 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation(r,(c+1)) == 0
                                        c = c + 1; 
                                    end
                                end                       
                            end   
                        elseif ((c>4)&&(c<23))&&(r == 1)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation((r+1),c) == 0
                                 r = r + 1;
                                 obj.GetintoArray = 1;
                            else
                                 c = c + 1;
                            end
                        elseif (r == 1)&&(c == 23)
                            if obj.NowRobotLocation((r+1),c) == 0
                                 r = r + 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (c == 4)&&((r == 2)||(r == 3))
                            r = r - 1;
                        elseif (r == 4)&&((gr == 3)||(gr == 1))&&(right == 0)
                            r = r - 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if gc ~= 4
                                    if right ~= 0
                                        if r == 4
                                            if right>0
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            elseif right<0
                                                c = c - 1;
                                            end
                                        else
                                            if ((right>0)&&(mod(r,4) == 0)&&(r ~= 4))||((right<0)&&(mod(r,4) ~= 0))
                                                c = c + sign(right);
                                            else
                                                if r == 6
                                                    if mod(c,4) ~= 0
                                                        c = c - 1;
                                                    else
                                                        r = r + 1;
                                                    end
                                                else
                                                    if mod(c,4) ~= 0
                                                        r = r - 1;
                                                    else
                                                        r = r + 1;
                                                    end
                                                end
                                            end
                                        end
                                    else
                                        r = r - 1;
                                    end
                                elseif gc == 4
                                    if r == 4
                                        c = c - 1;
                                    else
                                        if right ~= -2
                                            if ((right>-2)&&(mod(r,4) == 0)&&(r ~= 4))||((right<-2)&&(mod(r,4) ~= 0))
                                                c = c + sign(right+2);
                                            else
                                                if c == 4
                                                    r = r + 1;
                                                else
                                                    if mod(c,4) ~= 0
                                                        r = r - 1;
                                                    else
                                                        r = r + 1;
                                                    end
                                                end
                                            end
                                        else
                                            r = r - 1;
                                        end 
                                    end
                                end  
                            end   
                        end
                        
                    elseif gr>3  %����
                        if (r == gr)&&(c == gc)
                            if (gc == 3)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation((r+1),c) == 0
                                    r = r + 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 4)&&(gc == 1)  %���Ҫ����ڶ�/����
                                if obj.Column6cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation((r+1),c) == 0
                                        r = r + 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation((r+1),c) == 0
                                        r = r + 1; 
                                    end
                                end                       
                            end   
                        elseif ((r>4)&&(r<23))&&(c == 1)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation(r,(c+1)) == 0
                                 c = c + 1;
                                 obj.GetintoArray = 1;
                            else
                                 r = r + 1;
                            end
                        elseif (r == 23)&&(c == 1)
                            if obj.NowRobotLocation(r,(c+1)) == 0
                                 c = c + 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (r == 4)&&((c == 2)||(c == 3))
                            c = c - 1;
                        elseif (c == 4)&&((gc == 3)||(gc == 1))&&(down == 0)
                            c = c - 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if down ~= 0
                                    if c == 4
                                        if down<0
                                            if (mod(r,4) == 0)&&(r ~= 4)
                                                c = c + 1;
                                            else
                                                r = r + 1;
                                            end
                                        elseif down>0
                                            r = r + 1;
                                        end
                                    else
                                        if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
                                            r = r + sign(down);
                                        else
                                            if (mod(r,4) == 0)&&(r ~= 4)
                                                c = c + 1;
                                            else
                                                c = c - 1;
                                            end
                                        end
                                    end
                                else
                                    c = c - 1;
                                end
                            end   
                        end
                        
                    end
                   
                elseif number == 2 
                    if gr<=44  %ȥ����
                        if (r == gr)&&(c == gc)
                            if (gc == 3)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation((r-1),c) == 0
                                    r = r - 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 44)&&(gc == 1)  %���Ҫ����ڶ�/����
                                if obj.Column3cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation((r-1),c) == 0
                                        r = r - 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation((r-1),c) == 0
                                        r = r - 1; 
                                    end
                                end                       
                            end   
                        elseif ((r>25)&&(r<44))&&(c == 1)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation(r,(c+1)) == 0
                                 c = c + 1;
                                 obj.GetintoArray = 1;
                            else
                                 r = r - 1;
                            end
                        elseif (r == 25)&&(c == 1)
                            if obj.NowRobotLocation(r,(c+1)) == 0
                                 c = c + 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (r == 44)&&((c == 2)||(c == 3))
                            c = c - 1;
                        elseif (c == 4)&&((gc == 3)||(gc == 1))&&(down == 0)
                            c = c - 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if gr ~= 44
                                    if down ~= 0
                                        if c == 4
                                            if down<0
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    r = r + 1;
                                                end
                                            elseif down>0
                                                r = r + 1;
                                            end
                                        else
                                            if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
                                                r = r + sign(down);
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            end
                                        end
                                    else
                                        c = c - 1;
                                    end
                                elseif gr == 44
                                    if c == 4
                                        r = r + 1;
                                    else
                                        if down ~= 2
                                            if ((down>2)&&(mod(c,4) == 0))||((down<2)&&(mod(c,4) ~= 0))
                                                r = r + sign(down-2);
                                            else
                                                if r == 44
                                                    c = c + 1;
                                                else
                                                    if mod(r,4) ~= 0
                                                        c = c - 1;
                                                    else
                                                        c = c + 1;
                                                    end
                                                end
                                            end
                                        else
                                            c = c - 1;
                                        end 
                                    end                                    
                                end
                            end   
                        end
                        
                    elseif gr>44  %ȥ����
                        if (r == gr)&&(c == gc)
                            if (gr == 45)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation(r,(c+1)) == 0
                                    c = c + 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 47)&&(gc == 4)  %���Ҫ����ڶ�/����
                                if obj.Column3cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation(r,(c+1)) == 0
                                        c = c + 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation(r,(c+1)) == 0
                                        c = c + 1; 
                                    end
                                end                       
                            end   
                        elseif ((c>4)&&(c<23))&&(r == 47)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation((r-1),c) == 0
                                 r = r - 1;
                                 obj.GetintoArray = 1;
                            else
                                 c = c + 1;
                            end
                        elseif (r == 47)&&(c == 23)
                            if obj.NowRobotLocation((r-1),c) == 0
                                 r = r - 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (c == 4)&&((r == 45)||(r == 46))
                            r = r + 1;
                        elseif (r == 44)&&((gr == 45)||(gr == 47))&&(right == 0)
                            r = r + 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if right ~= 0
                                    if r == 44
                                        if right<0
                                            if mod(c,4) ~= 0
                                                r = r - 1;
                                            else
                                                c = c + 1;
                                            end
                                        elseif right>0
                                            c = c + 1;
                                        end
                                    else
                                        if ((right>0)&&(mod(r,4) == 0))||((right<0)&&(mod(r,4) ~= 0))
                                            c = c + sign(right);
                                        else
                                            if mod(c,4) == 0
                                                r = r + 1;
                                            else
                                                r = r - 1;
                                            end
                                        end
                                    end
                                else
                                    r = r + 1;
                                end
                            end   
                        end
                        
                    end

                elseif number == 3 
                    if gr>44  %ȥ����
                        if (r == gr)&&(c == gc)
                            if (gr == 45)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation(r,(c-1)) == 0
                                    c = c - 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 47)&&(gc == 44)  %���Ҫ����ڶ�/����
                                if obj.Column3cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation(r,(c-1)) == 0
                                        c = c - 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation(r,(c-1)) == 0
                                        c = c - 1; 
                                    end
                                end                       
                            end   
                        elseif ((c>25)&&(c<44))&&(r == 47)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation((r-1),c) == 0
                                 r = r - 1;
                                 obj.GetintoArray = 1;
                            else
                                 c = c - 1;
                            end
                        elseif (r == 47)&&(c == 25)
                            if obj.NowRobotLocation((r-1),c) == 0
                                 r = r - 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (c == 44)&&((r == 45)||(r == 46))
                            r = r + 1;
                        elseif (r == 44)&&((gr == 45)||(gr == 47))&&(right == 0)
                            r = r + 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if gc ~= 44
                                    if right ~= 0
                                        if r == 44
                                            if right<0
                                                if (mod(c,4) ~= 0)||(c == 44)
                                                    r = r - 1;
                                                else
                                                    c = c + 1;
                                                end
                                            elseif right>0
                                                c = c + 1;
                                            end
                                        else
                                            if ((right>0)&&(mod(r,4) == 0))||((right<0)&&(mod(r,4) ~= 0))
                                                c = c + sign(right);
                                            else
                                                if (mod(c,4) == 0)&&(c ~= 44)
                                                    r = r + 1;
                                                else
                                                    r = r - 1;
                                                end
                                            end
                                        end
                                    else
                                        r = r + 1;
                                    end
                                elseif gc == 44
                                    if r == 44
                                        c = c + 1;
                                    else
                                        if right ~= 4
                                            if ((right>4)&&(mod(r,4) == 0))||((right<4)&&(mod(r,4) ~= 0))
                                                c = c + sign(right-4);
                                            else
                                                if c == 44
                                                    r = r - 1;
                                                else
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        r = r - 1;
                                                    end
                                                end
                                            end
                                        else
                                            r = r + 1;
                                        end 
                                    end
                                end  
                            end   
                        end                        
                    elseif gr<=44  %ȥ����
                        if (r == gr)&&(c == gc)
                            if (gc == 45)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation((r-1),c) == 0
                                    r = r - 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 44)&&(gc == 47)  %���Ҫ����ڶ�/����
                                if obj.Column6cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation((r-1),c) == 0
                                        r = r - 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation((r-1),c) == 0
                                        r = r - 1; 
                                    end
                                end                       
                            end   
                        elseif ((r>25)&&(r<44))&&(c == 47)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation(r,(c-1)) == 0
                                 c = c - 1;
                                 obj.GetintoArray = 1;
                            else
                                 r = r - 1;
                            end
                        elseif (r == 25)&&(c == 47)
                            if obj.NowRobotLocation(r,(c-1)) == 0
                                 c = c - 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (r == 44)&&((c == 45)||(c == 46))
                            c = c + 1;
                        elseif (c == 44)&&((gc == 45)||(gc == 47))&&(down == 0)
                            c = c + 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if down ~= 0
                                    if c == 44
                                        if down>0
                                            if mod(r,4) ~= 0
                                                c = c - 1;
                                            else
                                                r = r - 1;
                                            end
                                        elseif down<0
                                            r = r - 1;
                                        end
                                    else
                                        if ((down>0)&&(mod(c,4) == 0))||((down<0)&&(mod(c,4) ~= 0))
                                            r = r + sign(down);
                                        else
                                            if c == 42
                                                if mod(r,4) ~= 0
                                                    c = c - 1;
                                                else
                                                    r = r - 1;
                                                end
                                            else
                                                if mod(r,4) == 0
                                                    c = c + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            end
                                        end
                                    end
                                else
                                    c = c + 1;
                                end
                            end   
                        end
                        
                    end
                    
                elseif number == 4
                    if gr>3  %ȥ����
                        if (r == gr)&&(c == gc)
                            if (gc == 45)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation((r+1),c) == 0
                                    r = r + 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 4)&&(gc == 47)  %���Ҫ����ڶ�/����
                                if obj.Column3cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation((r+1),c) == 0
                                        r = r + 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation((r+1),c) == 0
                                        r = r + 1; 
                                    end
                                end                       
                            end   
                        elseif ((r>4)&&(r<23))&&(c == 47)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation(r,(c-1)) == 0
                                 c = c - 1;
                                 obj.GetintoArray = 1;
                            else
                                 r = r + 1;
                            end
                        elseif (r == 23)&&(c == 47)
                            if obj.NowRobotLocation(r,(c-1)) == 0
                                 c = c - 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (r == 4)&&((c == 45)||(c == 46))
                            c = c + 1;
                        elseif (c == 44)&&((gc == 45)||(gc == 47))&&(down == 0)
                            c = c + 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if gr ~= 4
                                    if down ~= 0
                                        if c == 44
                                            if down>0
                                                if (mod(r,4) == 0)&&(r ~= 4)
                                                    r = r - 1;
                                                else
                                                    c = c - 1;
                                                end
                                            elseif down<0
                                                r = r - 1;
                                            end
                                        else
                                            if ((down>0)&&(mod(c,4) == 0)&&(c ~= 44))||((down<0)&&(mod(c,4) ~= 0))
                                                r = r + sign(down);
                                            else
                                                if c == 42
                                                    if (mod(r,4) == 0)&&(r ~= 4)
                                                        r = r - 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                else
                                                    if (mod(r,4) == 0)&&(r ~= 4)
                                                        c = c + 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                end
                                            end
                                        end
                                    else
                                        c = c + 1;
                                    end
                                elseif gr == 4
                                    if c == 44
                                        r = r - 1;
                                    else
                                        if down ~= -4
                                            if ((down>-4)&&(mod(c,4) == 0)&&(c ~= 44))||((down<-4)&&(mod(c,4) ~= 0))
                                                r = r + sign(down+4);
                                            else
                                                if r == 4
                                                    if (mod(c,4) == 0)&&(c ~= 44)
                                                        r = r + 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                else
                                                    if mod(r,4) == 0
                                                        c = c + 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                end
                                            end
                                        else
                                            c = c + 1;
                                        end 
                                    end                                    
                                end
                            end   
                        end
                        
                    elseif gr<=3  %ȥ����
                        if (r == gr)&&(c == gc)
                            if (gr == 3)   %���Ҫ��ĩ�˽����һ��
                                if obj.NowRobotLocation(r,(c-1)) == 0
                                    c = c - 1;
                                    obj.GetintoArray = 1;
                                end
                            elseif (gr == 1)&&(gc == 44)  %���Ҫ����ڶ�/����
                                if obj.Column6cars == 1  %���Ҫ������ǵ�����
                                    if obj.NowRobotLocation(r,(c-1)) == 0
                                        c = c - 1;
                                        obj.GetintoArray = 1;
                                    end                                
                                else  %���Ҫ������ǵڶ���
                                    if obj.NowRobotLocation(r,(c-1)) == 0
                                        c = c - 1; 
                                    end
                                end                       
                            end   
                        elseif ((c>25)&&(c<44))&&(r == 1)&&(obj.GetintoArray == 0)
                            if obj.NowRobotLocation((r+1),c) == 0
                                 r = r + 1;
                                 obj.GetintoArray = 1;
                            else
                                 c = c - 1;
                            end
                        elseif (r == 1)&&(c == 25)
                            if obj.NowRobotLocation((r+1),c) == 0
                                 r = r + 1;
                                 obj.GetintoArray = 1;
                            end                                       
                        elseif (c == 44)&&((r == 2)||(r == 3))
                            r = r - 1;
                        elseif (r == 4)&&((gr == 3)||(gr == 1))&&(right == 0)
                            r = r - 1;
                        else 
                            if (m == 0)&&(n ~= 0)   %rżc��
                                if mod(r,4) == 0   %�ж����е�/���е�
                                    if r == 4    %******************************************************************
                                        c = c - 1;
                                    else
                                        c = c + 1;
                                    end
                                else  
                                    c = c - 1;
                                end  
                            elseif (m ~= 0)&&(n == 0)  %r��cż
                                if (mod(c,4) == 0)&&(c ~= 44)   %�ж����е�/���е�
                                    r = r + 1;
                                else  
                                    r = r - 1;
                                end                             
                            elseif (m == 0)&&(n == 0)  %rżcż
                                if gc ~= 44
                                    if right ~= 0
                                        if r == 4
                                            if right>0
                                                if mod(c,4) == 0
                                                    r = r + 1;
                                                else
                                                    c = c - 1;
                                                end
                                            elseif right<0
                                                c = c - 1;
                                            end
                                        else
                                            if ((right>0)&&(mod(r,4) == 0)&&(r ~= 4))||((right<0)&&(mod(r,4) ~= 0))
                                                c = c + sign(right);
                                            else
                                                if r == 6
                                                    if mod(c,4) ~= 0
                                                       c = c - 1; 
                                                    else
                                                        r = r + 1;
                                                    end
                                                else
                                                    if (mod(c,4) == 0)&&(c ~= 44)
                                                        r = r + 1;
                                                    else
                                                        r = r - 1;
                                                    end
                                                end
                                            end
                                        end
                                    else
                                        r = r - 1;
                                    end
                                elseif gc == 44
                                    if r == 4
                                        if mod(c,4) == 0
                                            r = r + 1;
                                        else
                                            c = c - 1;
                                        end
                                    else
                                        if right ~= 0
                                            if ((right>0)&&(mod(r,4) == 0)&&(r ~= 4))||((right<0)&&(mod(r,4) ~= 0))
                                                c = c + sign(right);
                                            else
                                                if c == 44
                                                    r = r - 1;
                                                elseif r == 6
                                                    if mod(c,4) == 0
                                                        r = r + 1;
                                                    else
                                                        c = c - 1;
                                                    end
                                                else
                                                    if mod(c,4) ~= 0
                                                        r = r - 1;
                                                    else
                                                        r = r + 1;
                                                    end
                                                end
                                            end
                                        else
                                            r = r - 1;
                                        end 
                                    end
                                end  
                            end   
                        end
                        
                    end
                end  
                
                if (r == 0)||(r == 48)||(c == 0)||(c == 48)
                    disp(obj.SerialNumber);
                else
                    if obj.NowRobotLocation(r,c) == 0
                        obj.R = r;
                        obj.C = c;
                    else
                        obj.R = obj.Rp;
                        obj.C = obj.Cp;                    
                    end  
                end
            end 
            
        end
        
        function updateLocation(obj)
            obj.Rp = obj.R;
            obj.Cp = obj.C;

            switch obj.Status
            
                case 0 %���ڵȴ�����׼��ȥ��ɨ�봦
                    if (obj.R<=3)&&(obj.C<24) %����1
                        if (obj.R == 3)&&(obj.C == 23)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2);  
                                if c<24  %**********************ע��˴��ж����ֵ�ѡ��*************************
                                    if (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c+1),4) == 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end
                                elseif c>24
                                    if (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end                                    
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(1,1) = obj.ArrayNumber(1,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.R == 3)&&((obj.C>4)&&(obj.C<23))
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end
                        elseif (obj.R == 2)&&(obj.C == 5)
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end       
                        elseif (obj.R == 2)&&((obj.C>5)&&(obj.C<24))
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end    
                        elseif (obj.R == 1)&&(obj.C == 23)
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end                            
                        elseif (obj.R == 1)&&((obj.C>4)&&(obj.C<23))
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end                            
                        end
                        
                    elseif (obj.C<=3)&&(obj.R<24) %����2
                        if (obj.R == 23)&&(obj.C == 3)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2); 
                                if r<24
                                    if mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;    
                                        obj.GoalChanged = 1;
                                    end            
                                elseif r>24
                                    if mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r-1),4) == 0
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;    
                                        obj.GoalChanged = 1;
                                    end                                   
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(2,1) = obj.ArrayNumber(2,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.C == 3)&&((obj.R>4)&&(obj.R<23))
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end
                        elseif (obj.C == 2)&&(obj.R == 5)
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end                            
                        elseif (obj.C == 2)&&((obj.R>5)&&(obj.R<24))
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end                            
                        elseif (obj.C == 1)&&(obj.R == 23)
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end    
                        elseif (obj.C == 1)&&((obj.R>4)&&(obj.R<23))
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end 
                        end
                            
                    elseif (obj.C<=3)&&(obj.R>24) %����3
                        if (obj.R == 25)&&(obj.C == 3)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2); 
                                if r<24
                                    if mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;    
                                        obj.GoalChanged = 1;
                                    end            
                                elseif r>24
                                    if mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r-1),4) == 0
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;    
                                        obj.GoalChanged = 1;
                                    end                                   
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(3,1) = obj.ArrayNumber(3,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.C == 3)&&((obj.R>25)&&(obj.R<44))
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end
                        elseif (obj.C == 2)&&(obj.R == 43)
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end                            
                        elseif (obj.C == 2)&&((obj.R>24)&&(obj.R<43))
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end                            
                        elseif (obj.C == 1)&&(obj.R == 25)
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end    
                        elseif (obj.C == 1)&&((obj.R>25)&&(obj.R<44))
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end   
                        end

                    elseif (obj.R>44)&&(obj.C<24) %����4
                        if (obj.R == 45)&&(obj.C == 23)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2); 
                                if c<24
                                    if mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c+1),4) == 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end            
                                elseif c>24
                                    if mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end                                     
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(4,1) = obj.ArrayNumber(4,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.R == 45)&&((obj.C>4)&&(obj.C<23))
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end
                        elseif (obj.R == 46)&&(obj.C == 5)
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end       
                        elseif (obj.R == 46)&&((obj.C>5)&&(obj.C<24))
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end    
                        elseif (obj.R == 47)&&(obj.C == 23)
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end                            
                        elseif (obj.R == 47)&&((obj.C>4)&&(obj.C<23))
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end                            
                        end
                         
                    elseif (obj.R>44)&&(obj.C>24) %����5
                        if (obj.R == 45)&&(obj.C == 25)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2); 
                                if c<24
                                    if mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c+1),4) == 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end            
                                elseif c>24
                                    if mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end                                     
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(5,1) = obj.ArrayNumber(5,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.R == 45)&&((obj.C>25)&&(obj.C<44))
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end
                        elseif (obj.R == 46)&&(obj.C == 43)
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end       
                        elseif (obj.R == 46)&&((obj.C>24)&&(obj.C<43))
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end    
                        elseif (obj.R == 47)&&(obj.C == 25)
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end                            
                        elseif (obj.R == 47)&&((obj.C>25)&&(obj.C<44))
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end                            
                        end
                        
                    elseif (obj.C>=45)&&(obj.R>24) %����6
                        if (obj.R == 25)&&(obj.C == 45)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2); 
                                if r<24
                                    if (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;    
                                        obj.GoalChanged = 1;
                                    end            
                                elseif r>24
                                    if (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r-1),4) == 0
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;    
                                        obj.GoalChanged = 1;
                                    end                                   
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(6,1) = obj.ArrayNumber(6,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.C == 45)&&((obj.R>25)&&(obj.R<44))
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end
                        elseif (obj.C == 46)&&(obj.R == 43)
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end                            
                        elseif (obj.C == 46)&&((obj.R>24)&&(obj.R<43))
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end                            
                        elseif (obj.C == 47)&&(obj.R == 25)
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end    
                        elseif (obj.C == 47)&&((obj.R>25)&&(obj.R<44))
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end     
                        end
               
                    elseif (obj.C>=45)&&(obj.R<24) %����7
                        if (obj.R == 23)&&(obj.C == 45)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2); 
                                if r<24
                                    if (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;    
                                        obj.GoalChanged = 1;
                                    end            
                                elseif r>24
                                    if (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;
                                        obj.GoalChanged = 1;
                                    elseif mod((r-1),4) == 0
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;    
                                        obj.GoalChanged = 1;
                                    end                                   
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(7,1) = obj.ArrayNumber(7,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.C == 45)&&((obj.R>4)&&(obj.R<23))
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end
                        elseif (obj.C == 46)&&(obj.R == 5)
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end                            
                        elseif (obj.C == 46)&&((obj.R>5)&&(obj.R<24))
                            if obj.NowRobotLocation((obj.R-1),obj.C) == 0
                                obj.R = obj.R - 1;
                            end                            
                        elseif (obj.C == 47)&&(obj.R == 23)
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end    
                        elseif (obj.C == 47)&&((obj.R>4)&&(obj.R<23))
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end        
                        end
                        
                    elseif (obj.R<=3)&&(obj.C>24) %����8
                        if (obj.R == 3)&&(obj.C == 25)
                            if obj.TimeDelay1 == 10
                                obj.Goal = obj.AssignedTask(1,:);
                                r = obj.Goal(1,1);
                                c = obj.Goal(1,2); 
                                if c<24  %**********************ע��˴��ж����ֵ�ѡ��*************************
                                    if (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c+1),4) == 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end
                                elseif c>24
                                    if (mod((r-1),4) == 0)&&((r-1) ~= 4)
                                        obj.Goal(1,1) = r - 1;
                                        obj.Goal(1,2) = c;
                                        obj.GoalChanged = 1;
                                    elseif mod((c-1),4) ~= 0
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c - 1;   
                                        obj.GoalChanged = 1;
                                    elseif (mod((c+1),4) == 0)&&((c+1) ~= 44)
                                        obj.Goal(1,1) = r;
                                        obj.Goal(1,2) = c + 1;   
                                        obj.GoalChanged = 1;
                                    elseif mod((r+1),4) ~= 0
                                        obj.Goal(1,1) = r + 1;
                                        obj.Goal(1,2) = c;    
                                        obj.GoalChanged = 1;
                                    end                                    
                                end
                                obj.Status = 1;
                                obj.TimeDelay1 = 1;
                                obj.GetintoArray = 0;
%                                 obj.ArrayNumber(8,1) = obj.ArrayNumber(8,1) - 1;
                            else
                                obj.TimeDelay1 = obj.TimeDelay1 + 1;
                            end
                        elseif (obj.R == 3)&&((obj.C>25)&&(obj.C<44))
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end
                        elseif (obj.R == 2)&&(obj.C == 43)
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end       
                        elseif (obj.R == 2)&&((obj.C>24)&&(obj.C<43))
                            if obj.NowRobotLocation(obj.R,(obj.C+1)) == 0
                                obj.C = obj.C + 1;
                            end    
                        elseif (obj.R == 1)&&(obj.C == 25)
                            if obj.NowRobotLocation((obj.R+1),obj.C) == 0
                                obj.R = obj.R + 1;
                            end                            
                        elseif (obj.R == 1)&&((obj.C>25)&&(obj.C<44))
                            if obj.NowRobotLocation(obj.R,(obj.C-1)) == 0
                                obj.C = obj.C - 1;
                            end                            
                        end
                    end
    
                case 1 %����������㣬ȥ�������
                    down = obj.Goal(1,1) - obj.R;
                    right = obj.Goal(1,2) - obj.C;
                    if obj.GoalChanged == 1  %�������Ҳ�ж����Ŀ��㱻��Ϊ��Χ�ĸ����е�һ��
                        if (down == 0)&&(right == 0)
                            if obj.TimeDelay2 == 4
                                obj.TimeDelay2 = 1;
                                obj.Status = 2;
                                obj.TaskCompleted = 1;
                                obj.GoalChanged = 0;
                                obj.Goal = obj.GetArraygoal();
                            else
                                obj.TimeDelay2 = obj.TimeDelay2 + 1;
                            end                                 
                        else
                            obj.goLocation(obj.Goal);
                        end
                    else   %���������Ҳ�ж��
                        if ((down == 0)&&((right == 1)||(right == -1)))||((right == 0)&&((down == 1)||(down == -1)))
                            if obj.TimeDelay2 == 12
                                obj.TimeDelay2 = 1;
                                obj.Status = 2;
                                obj.TaskCompleted = 1;
                                obj.GoalChanged = 0;
                                obj.Goal = obj.GetArraygoal();
                            else
                                obj.TimeDelay2 = obj.TimeDelay2 + 1;
                            end                                
                        else
                            obj.goLocation(obj.Goal);
                        end
                    end

%                     if ((down == 0)&&((right == 1)||(right == -1)))||((right == 0)&&((down == 1)||(down == -1)))
%                         if ((right == 1)&&(mod(obj.C,4) ~= 0))||((right == -1)&&(mod(obj.C,4) == 0))||((down == 1)&&(mod(obj.R,4) == 0))||((down == -1)&&(mod(obj.R,4) ~= 0))
%                             if obj.TimeDelay2 == 6
%                                 obj.TimeDelay2 = 1;
%                                 obj.Status = 2;
%                                 obj.TaskCompleted = 1;
%                                 obj.Goal = obj.GetArraygoal();
%                             else
%                                 obj.TimeDelay2 = obj.TimeDelay2 + 1;
%                             end                            
%                         else
%                             if obj.TimeDelay2 == 16
%                                 obj.TimeDelay2 = 1;
%                                 obj.Status = 2;
%                                 obj.TaskCompleted = 1;
%                                 obj.Goal = obj.GetArraygoal();
%                             else
%                                 obj.TimeDelay2 = obj.TimeDelay2 + 1;
%                             end                            
%                         end
% 
%                     else
%                         obj.goLocation(obj.Goal);
%                     end
                         
                case 2 %�����ж����ɣ�ȥ���Ⱥ���
                    obj.goLocation(obj.Goal);
                    if obj.GetintoArray == 1
                        obj.Status = 0;
                    end
            end 
        end
         
    end %end of methods
    
end %end of the class
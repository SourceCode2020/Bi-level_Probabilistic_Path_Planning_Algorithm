map = robotics.BinaryOccupancyGrid(23.5,23.5,2);
for i =1:20
    for j = 1:20
        a = (2.5+(j-1)*1):0.01:(2.5+(j-1)*1);
        b = (2.5+(i-1)*1):0.01:(2.5+(i-1)*1);
        [x,y] = meshgrid(a,b);
        setOccupancy(map,[x(:) y(:)],1);
    end
end
%����Ϊ4���ּ�ڵ�����
a = (11.5):0.01:(11.5);
b = (1.5):0.01:(1.5);
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

a = (12.5):0.01:(12.5);
b = (1.5):0.01:(1.5);
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

a = (11.5):0.01:(11.5);
b = (22.5):0.01:(22.5);
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

a = (12.5):0.01:(12.5);  %��
b = (22.5):0.01:(22.5);  %��
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

a = (1.5):0.01:(1.5);
b = (11.5):0.01:(11.5);
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

a = (1.5):0.01:(1.5);
b = (12.5):0.01:(12.5);
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

a = (22.5):0.01:(22.5);
b = (11.5):0.01:(11.5);
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

a = (22.5):0.01:(22.5);
b = (12.5):0.01:(12.5);
[x,y] = meshgrid(a,b);
setOccupancy(map,[x(:) y(:)],1);

figure;
show(map);

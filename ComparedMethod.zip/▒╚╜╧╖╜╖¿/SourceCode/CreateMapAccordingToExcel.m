filename = '10Pick288Depot.xlsx';
mapMatrix = xlsread(filename);
map = robotics.BinaryOccupancyGrid(15.5,10.5,2);
for i = 1:size(mapMatrix,2)
    for j = 1:size(mapMatrix,1)
        if mapMatrix(j,i) == 1 || mapMatrix(j,i) == 3
            setOccupancy(map,[i/2 j/2],1);
        end
    end
end
figure;
show(map);

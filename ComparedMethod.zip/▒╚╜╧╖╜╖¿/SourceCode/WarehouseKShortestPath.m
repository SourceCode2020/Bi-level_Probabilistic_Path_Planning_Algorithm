function [shortestPaths, totalCosts] = WarehouseKShortestPath(netCostMatrix, NodeCoordinate, MapSignalNode, MapNode, AdjacentMatrixNode, source, destination1, destination2, final, k_paths1, k_paths2)
sourceNode = find(AdjacentMatrixNode == source);
destination1Node = find(AdjacentMatrixNode == destination1);
destination2Node = find(AdjacentMatrixNode == destination2);
[shortestPaths1, totalCosts1] = kShortestPath(netCostMatrix, sourceNode, destination1Node, k_paths2);
[shortestPaths2, totalCosts2] = kShortestPath(netCostMatrix, sourceNode, destination2Node, k_paths2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��destination��final�ľ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
column1 = NodeCoordinate(:,1);
destination1Index = find(column1 == destination1);
destination2Index = find(column1 == destination2);
finalIndex = find(column1 == final);
d1 = abs(NodeCoordinate(destination1Index,2) - NodeCoordinate(finalIndex,2)) + abs(NodeCoordinate(destination1Index,3) - NodeCoordinate(finalIndex,3));
d2 = abs(NodeCoordinate(destination2Index,2) - NodeCoordinate(finalIndex,2)) + abs(NodeCoordinate(destination2Index,3) - NodeCoordinate(finalIndex,3));
for i = 1:size(totalCosts1,2)
    totalCosts1(i) = totalCosts1(i) + d1;
end
for i = 1:size(totalCosts2,2)
    totalCosts2(i) = totalCosts2(i) + d2;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%totalCosts1��totalCosts2����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:size(totalCosts2,2)
    cost = totalCosts2(1,i);
    if size(totalCosts1,2) == 1 %ȥdestination1��·��ֻ��һ��
        if cost < totalCosts1(1,1) %����totalCosts1��һ��Ԫ��֮ǰ
            shortestPaths1 = [shortestPaths2{i} shortestPaths1];
            totalCosts1 = [totalCosts2(i) totalCosts1];
        else %����totalCosts1��һ��Ԫ��֮��
            shortestPaths1 = [shortestPaths1 shortestPaths2];
            totalCosts1 = [totalCosts1 totalCosts2];
            break;
        end        
    else %ȥdestination1��·����ֹһ��
        for j = 1:size(totalCosts1,2)
            if j == 1
                if cost < totalCosts1(1,j)
                    shortestPaths1 = [shortestPaths2{i} shortestPaths1];
                    totalCosts1 = [totalCosts2(i) totalCosts1];
                    break;
                end
            elseif j == size(totalCosts1,2)
                if cost > totalCosts1(1,j) || cost == totalCosts1(1,j)
                    shortestPaths1 = [shortestPaths1 shortestPaths2{i}];
                    totalCosts1 = [totalCosts1 totalCosts2(i)];
                    break;
                end
            else
                if (cost>totalCosts1(1,j-1) ||  cost == totalCosts1(1,j-1)) && cost<totalCosts1(1,j)
                    shortestPaths1 = [shortestPaths1(:,1:j-1) shortestPaths2{i} shortestPaths1(:,j:end)];
                    totalCosts1 = [totalCosts1(:,1:j-1) totalCosts2(i) totalCosts1(:,j:end)];
                    break;
                elseif (cost>totalCosts1(1,j) ||  cost == totalCosts1(1,j)) && cost<totalCosts1(1,j+1)
                    shortestPaths1 = [shortestPaths1(:,1:j) shortestPaths2{i} shortestPaths1(:,j+1:end)];
                    totalCosts1 = [totalCosts1(:,1:j) totalCosts2(i) totalCosts1(:,j+1:end)];
                    break;
                end
            end
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

shortestPaths = [];
totalCosts = [];
if size(totalCosts1,2) < k_paths1
    for i = 1:size(totalCosts1,2)
        shortestPaths{i} = shortestPaths1{i};
        totalCosts(i) = totalCosts1(i);
    end       
else
    for i = 1:k_paths1
        shortestPaths{i} = shortestPaths1{i};
        totalCosts(i) = totalCosts1(i);
    end    
end

%��shortestPaths�еĵ�ת��Ϊʵ�ʵĽڵ�
for i = 1:size(shortestPaths,2)
    for j = 1:size(shortestPaths{1,i},2)
        node = shortestPaths{1,i}(1,j);
        realNode = AdjacentMatrixNode(node,1);
        shortestPaths{1,i}(1,j) = realNode;
    end
end

for i = 1:size(shortestPaths,2)
    r = NodeCoordinate(final,2);
    c = NodeCoordinate(final,3);
    if MapSignalNode(r-1,c) == 1 %���ܵ���һ��
        middleNode = MapNode(r+1,c);
    else %���ܵ���һ��
        middleNode = MapNode(r-1,c);
    end
    shortestPaths{1,i}(1,size(shortestPaths{1,i},2)+1) = middleNode;
    shortestPaths{1,i}(1,size(shortestPaths{1,i},2)+1) = final;
end
end
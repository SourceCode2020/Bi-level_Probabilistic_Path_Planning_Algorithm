classdef Warehouse<handle
    %WAREHOUSE �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    % ע��ǰ��̨��λת����ǰ̨m����̨grid����
    %������ʾ��Ϣȫ���ڱ����д�ӡ
    properties
        
        %��̬���ԣ���ʼ��֮��Ͳ���仯��
        Accelerate
        PlotInterval
        Map
        
        TotalRobotNumber
        TotalWorkerNumber
        TotalTaskNumber
                
        h   %��ʾ����handle
        g   %��ʾ����handle
        m
        %��̬�������ԡ�        
        SystemOn  %ϵͳ��ʼ��Ϣ����GUI��ʼ������ֵ        
        WorkerArrayTimer  %��ʱ����ÿ0.5�����һ�ι��˵�λ����Ϣ
                
        RobotArray = Robot; %Robot - ������˶����������������ΪN��������
        WorkerArray = Worker; %Worker -���˶���������������ΪM��������
        TaskArray ;  %Task -�������������������2000��4*4������
          
        AllStatus   %��̬ά�������˵�״̬��Ϣ��N*1������������͹��˶�ȡ��       
        AllLocation  %��̬ά�������˵�λ����Ϣ��N*2�����˶�ȡ��        
        AllWorkerLocation %��̬ά�����˵�λ����Ϣ��M*2������ʾ��  
        AllNowRobotLocation %��̬ά������������λ�ã�����Robot�࣬��������
        ArrayNumber  %��̬ά��ÿ��С����Ļ����������������жϻص�����ʱĿ�������ѡ��
        Allworkingrobot  %�洢���ڹ����Ļ�����
        AllRobotTaskD  %�洢ÿ�����������һ���������ߵľ���
        EveryRobotCompletedT  %�洢ÿ��������������������
        LastTLocation %�洢��һ��ʱ�䲽���л����˵�λ�ã�������
        NowLocation %�洢��ǰʱ�䲽���л����˵�λ�ã�������
        
        RobotNumber1
        RobotNumber2
        RobotNumber3
        RobotNumber4
        RobotNumber5
        RobotNumber6
        CurrentT
        move1
        move2
        move3
        move4
        move5
        move6
        delay
        delayNum
        
        AllRow                 %��ͼ����
        AllColumn              %��ͼ����
        
        AllPickedRobotSerial  %��̬ά��������ͣ��վ������Ʒ���úõ���Ϣ��N*1��Ĭ��Ϊ0����Ϊ1�ı�ʾ���Ѿ��źá�������ֵΪ��������š�������һ��ѭ�����û����˵�Picked״̬
        AllTaskCompleted %��̬ά�������˵�����������Ϣ��N*1��1��������ʾ��Ӧ�Ļ����ˣ�������ֵ��ʾ��ɵ���������������ֵΪ��������š�   
        AllWorkerOdom1 %���������ߵľ���
        AllWorkerOdom2
        AllRobotOdom
        TaskCounter
        
        TimeCounter
        TaskIndex %��¼��ǰ�����б�
        StatusList
        
        %��¼��ͼ�еĳ���ڣ���λ�ڵ���Ϣ
        MapNode             %��ͼ�нڵ�����ƣ���������
        MapSignalNode       %��¼��ͼ�и���ڵ㣨0-ȡ���㣬1-�Ż��㣬2-��·��ʻ�㣬3-�ϰ���/��Ե��
        AllNodeNum          %���нڵ����Ŀ
        PickupDepotNodeNum  %ȡ����ͷŻ���Ľڵ���֮�ͣ�Ϊ�ڽӾ�������
        PickUpNodeNum       %ȡ����Ľڵ���Ŀ
        DepotNodeNum        %�Ż���Ľڵ���Ŀ
        
        PickUpDepotNode     %���е�ȡ����ͷŻ���
        PickUpNode          %���е�ȡ����
        DepotNode           %���еķŻ���
        
        NodeCoordinate      %��¼���е������
        AllPickUpNode       %��¼����ȡ�������Ϣ
        AllDepotNode        %��¼���зŻ������Ϣ
        
        AllCrissOverNode    %��¼����ʮ��·�ڽڵ㣨���ڼ���K���·����   
        AllCrissOverNodeNum %��¼����ʮ��·�ڽڵ�����
        
        NodePairEdge           %���-��,��һ�����󣬵�һ��Ϊ�ڵ�1���ڶ���Ϊ�ڵ�2��������Ϊ�ߵı��
        NodeAdjacent           %ÿ������ھӵ�
        AdjacentMatrix         %�ڽӾ���
        AdjacentMatrixNode     %�ڽӾ���ڵ�
        AdjacentMatrixNodeNum  %�ڽӾ���ڵ�
        
        DepotNearCrossNode     %���ܵ㸽���Ľ���ڵ�       
        
        K                      %K���·����K��ȡֵ
        KShortestPaths         %�������K���·��
        KShortestPathsNodePair %K���·����Ӧ�ĵ��
        
        AllRobotTW             %��¼���л����˵�·��ʱ�䴰
        AllNodeTW              %��¼���нڵ��ʱ�䴰
        
        PlanningRobotNumUp     %����滮����һ�������Թ滮�Ļ���������
        
        TaskAmount             %��������
        TaskList               %�����б�
        TaskRobot              %��¼�ӵ������Ӧ�Ļ�����
        LeftTaskList           %��¼ʣ��δ�·�������
        FinishedTaskNum        %��¼�ܹ���ɵ���������
        
        PickUpNodeOccupancy    %��̬��¼ȡ�����Ȩ��ռ��
        DepotNodeOccupancy     %��̬��¼�Ż����Ȩ��ռ��
    end
    
    methods
        %�����ֿ���ĳ�ʼ��������������λ�á�״̬��ʼ�����Լ�һЩ��־λ�ĳ�ʼ��
        function obj = Warehouse()
            load('10Pick288Depot.mat');
            obj.Map = map;
            obj.TotalRobotNumber = 30;
            obj.TaskAmount = 100;
            obj.PickUpNodeNum = 10;
            obj.DepotNodeNum = 288;
            obj.K = 5;
            obj.PlanningRobotNumUp = 3;
            obj.TaskIndex = 1; 
            obj.FinishedTaskNum = 0;

            obj.AllRow = 21;
            obj.AllColumn = 31;

            if obj.TotalRobotNumber < 10
                obj.delayNum = 1;
            else
                obj.delayNum = floor(0.1*obj.TotalRobotNumber);
            end
            
            obj.move1 = 0;
            obj.move2 = 0;
            obj.move3 = 0;
            obj.move4 = 0;
            obj.move5 = 0;
            obj.move6 = 0;
            obj.delay = 0;
            
            obj.ReadMap(); %����ͼ����ʼ��
%             [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, 444, 22, 29, 57, 5, 5);
            
            obj.AllRobotTW = [];
            obj.AllNodeTW = [];
            for i = 1:obj.TotalRobotNumber
                obj.AllRobotTW{i,1} = [];
            end
            for i = 1:obj.AllNodeNum
                obj.AllNodeTW{i,1} = [];
            end
            
            obj.initializeRobot();
            obj.initializeTask();
%             obj.taskAllocator();
            
            %%%%%%%%%%%���߹滮���е�·��%%%%%%%%%%����������ʱ�ã�
%             obj.KShortestPathPlanning();
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            obj.Accelerate = 0.3;
            
%             obj.TotalWorkerNumber = 40;
            obj.TotalTaskNumber = 30000;
            
            %GUI��������
            obj.SystemOn = true;
            
            obj.PlotInterval = 0.5*obj.Accelerate;  
            obj.WorkerArrayTimer = false;
                       
            obj.AllStatus = zeros(obj.TotalRobotNumber,1);
            obj.AllLocation = zeros(obj.TotalRobotNumber,2);
            obj.AllWorkerLocation = repmat([1.25,26.25],obj.TotalRobotNumber,1);
            obj.AllNowRobotLocation = zeros(47,47);           
     
            obj.AllPickedRobotSerial = zeros(obj.TotalRobotNumber,1);
            obj.AllTaskCompleted = zeros(obj.TotalRobotNumber,1);
            obj.AllWorkerOdom1 = 0;
            obj.AllWorkerOdom2 = 0;
            obj.AllRobotOdom = 0;
            obj.TimeCounter = 1;
            obj.TaskCounter = 0;
            obj.StatusList = zeros(43200,40);
            obj.Allworkingrobot = zeros(12,1);
            obj.AllRobotTaskD = zeros(300,10000);
            obj.EveryRobotCompletedT = zeros(300,1);
           
%             obj.initializeWorker();                    
        end  
        
        %��ȡ��ͼ�е���Ϣ
        function ReadMap(obj)
            MapMatrix = xlsread('10Pick288Depot.xlsx');
            obj.MapSignalNode = MapMatrix;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%�ڵ���Ϣ��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.AllNodeNum = 0;
            obj.PickUpNode = zeros(obj.PickUpNodeNum,1); %������е�ȡ����
            obj.DepotNode = zeros(obj.DepotNodeNum,1); %������еķŻ���
            obj.NodeCoordinate = [];
            obj.PickUpDepotNode = [];
            obj.AdjacentMatrixNode = [];
            obj.DepotNearCrossNode = [];
            obj.PickUpNodeOccupancy = [];
            obj.DepotNodeOccupancy = [];
            obj.AdjacentMatrixNodeNum = 0;
            obj.MapNode = zeros(size(MapMatrix,1),size(MapMatrix,2)); %��ͼ�нڵ�����ƣ���������
            filename = '10Pick288depotMapNode.xlsx';
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%���ڵ���/��������/ʶ��ȡ���㡢�Ż���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(MapMatrix,1)
                for j = 1:size(MapMatrix,2)
                    if MapMatrix(i,j) ~= 3
                        obj.AllNodeNum = obj.AllNodeNum + 1;
                        obj.MapNode(i,j) = obj.AllNodeNum; %�ڵ���
                        %%%%%%%%%%%%%%%%%%��ʼ���ڵ�λ��%%%%%%%%%%%%%%%%%%
                        rows = size(obj.NodeCoordinate,1);
                        obj.NodeCoordinate(rows+1,1) = obj.MapNode(i,j);
                        obj.NodeCoordinate(rows+1,2) = i;
                        obj.NodeCoordinate(rows+1,3) = j;
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if MapMatrix(i,j) == 0 %����ڵ���ȡ����
                            obj.PickUpNodeNum = obj.PickUpNodeNum + 1;
                            ZeroElement = find(obj.PickUpNode == 0);
                            FirstZero = ZeroElement(1);
                            obj.PickUpNode(FirstZero,1) = obj.MapNode(i,j);
                            row = size(obj.PickUpNodeOccupancy,1);
                            obj.PickUpNodeOccupancy(row+1,1) = obj.MapNode(i,j);
                            obj.PickUpNodeOccupancy(row+1,2) = 0; %�Ƿ�ռ��
                            obj.PickUpNodeOccupancy(row+1,3) = 0; %ռ�øýڵ�����˵ı��
                        elseif MapMatrix(i,j) == 1 %����ڵ��ǷŻ���
                            obj.DepotNodeNum = obj.DepotNodeNum + 1;
                            ZeroElement = find(obj.DepotNode == 0);
                            FirstZero = ZeroElement(1);
                            obj.DepotNode(FirstZero,1) = obj.MapNode(i,j);
                            row = size(obj.DepotNodeOccupancy,1);
                            obj.DepotNodeOccupancy(row+1,1) = obj.MapNode(i,j);
                            obj.DepotNodeOccupancy(row+1,2) = 0; %�Ƿ�ռ��
                            obj.DepotNodeOccupancy(row+1,3) = 0; %ռ�øýڵ�����˵ı��
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            xlswrite(filename,obj.MapNode); %�����ŵ�ͼ���ɵĽڵ�����д��excel��
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%��¼���ܵ㸽���Ľ���ڽڵ�%%%%%%%%%%%%%%%%%%%%%%%%%%
            for  i = 1:size(MapMatrix,1)
                for  j = 1:size(MapMatrix,2)
                    if MapMatrix(i,j) == 1 %����
                        if MapMatrix(i-1,j) == 1 %������һ��
                            crossNode1 = obj.MapNode(i+1,j-mod(j-2,7));
                            crossNode2 = obj.MapNode(i+1,j-mod(j-2,7)+7);
                            row = size(obj.DepotNearCrossNode,1);
                            obj.DepotNearCrossNode(row+1,1) = obj.MapNode(i,j);
                            obj.DepotNearCrossNode(row+1,2) = crossNode1;
                            obj.DepotNearCrossNode(row+1,3) = crossNode2;
                        else %������һ��
                            crossNode1 = obj.MapNode(i-1,j-mod(j-2,7));
                            crossNode2 = obj.MapNode(i-1,j-mod(j-2,7)+7);
                            row = size(obj.DepotNearCrossNode,1);
                            obj.DepotNearCrossNode(row+1,1) = obj.MapNode(i,j);
                            obj.DepotNearCrossNode(row+1,2) = crossNode1;
                            obj.DepotNearCrossNode(row+1,3) = crossNode2;
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����ڽӾ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%�ҳ������ڽӾ����еĵ�%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(MapMatrix,1)
                for j = 1:size(MapMatrix,2)
                    if MapMatrix(i,j) == 0 || MapMatrix(i,j) == 4
                        obj.AdjacentMatrixNodeNum = obj.AdjacentMatrixNodeNum + 1;
                        obj.AdjacentMatrixNode(size(obj.AdjacentMatrixNode,1)+1,1) = obj.MapNode(i,j);
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.AdjacentMatrix = 1./zeros(obj.AdjacentMatrixNodeNum);
            column2 = obj.AdjacentMatrixNode(:,1);
            for i = 1:size(MapMatrix,1)
                for j = 1:size(MapMatrix,2)
                    node = obj.MapNode(i,j);
                    index = find(column2 == node); %�ҵ���ǰ��������Ӧ��obj.AdjacentMatrixNode�еı�ţ���1��ʼ��
                    if MapMatrix(i,j) == 0
                        if j == 1
                            adjacentNode = obj.MapNode(i,j+1);
                            index2 = find(column2 == adjacentNode);
                            obj.AdjacentMatrix(index,index2) = 1;
                        else
                            adjacentNode = obj.MapNode(i,j-1);
                            index2 = find(column2 == adjacentNode);
                            obj.AdjacentMatrix(index,index2) = 1;
                        end
                    elseif MapMatrix(i,j) == 4
                        if MapMatrix(i-1,j) ~= 3
                            if (i-2) > 0 %����������һ�е�4
                                adjacentNode = obj.MapNode(i-3,j);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 3;
                            end
                        end
                        if MapMatrix(i+1,j) ~= 3
                            if (i+2) < 22 %����������һ�е�4
                                adjacentNode = obj.MapNode(i+3,j);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 3;
                            end 
                        end
                        if MapMatrix(i,j-1) ~= 3
                            if j == 2 %�������һ�е�4
                                adjacentNode = obj.MapNode(i,j-1);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 1;                              
                            else
                                adjacentNode = obj.MapNode(i,j-7);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 7;                                
                            end
                        end
                        if MapMatrix(i,j+1) ~= 3
                            if j == 30 %�����ұ�һ�е�4
                                adjacentNode = obj.MapNode(i,j+1);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 1;                                
                            else
                                adjacentNode = obj.MapNode(i,j+7);
                                index2 = find(column2 == adjacentNode);
                                obj.AdjacentMatrix(index,index2) = 7;                                
                            end                            
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        
        %����K���·��
        function KShortestPathPlanning(obj)
            obj.KShortestPaths = [];
            obj.KShortestPathsNodePair = [];
            for i = 1:size(obj.PickUpNode,1)
                for j = 1:size(obj.DepotNode,1)
                    column = obj.DepotNearCrossNode(:,1);
                    index = find(column == obj.DepotNode(j,1));
                    crossNode1 = obj.DepotNearCrossNode(index,2);
                    crossNode2 = obj.DepotNearCrossNode(index,3);
                    [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, obj.PickUpNode(i,1), crossNode1, crossNode2, obj.DepotNode(j,1), 5, 5);
                    row = size(obj.KShortestPaths,1);
                    obj.KShortestPaths{row+1,1} = obj.PickUpNode(i,1);
                    obj.KShortestPaths{row+1,2} = obj.DepotNode(j,1);
                    obj.KShortestPaths{row+1,3} = shortestPaths;
                    obj.KShortestPathsNodePair(row+1,1) = obj.PickUpNode(i,1);
                    obj.KShortestPathsNodePair(row+1,2) = obj.DepotNode(j,1);
                    %%%%%%%%%%%%%%%%%%������%%%%%%%%%%%%%%%%%%
                    disp(obj.PickUpNode(i,1));
                    disp('��');
                    disp(obj.DepotNode(j,1));
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                end
            end
        end

        %�����˳�ʼ���������û��������кš���ʼλ���ڻ������������ʼ��
        function initializeRobot(obj)
            obj.RobotArray(obj.TotalRobotNumber,1) = Robot;
            for i = 1:obj.TotalRobotNumber
                obj.RobotArray(i,1) = Robot;
                for j = 1:10000
                    startIndex = unidrnd(size(obj.DepotNode,1));
                    robotNode = obj.DepotNode(startIndex,1); %�ڷŻ���������ɻ����˵ĳ�ʼλ��
                    column = obj.DepotNodeOccupancy(:,1);
                    index = find(column == robotNode);
                    if obj.DepotNodeOccupancy(index,2) == 0 %û�б�Ļ�����ռ��
                        obj.DepotNodeOccupancy(index,2) = 1;
                        obj.DepotNodeOccupancy(index,3) = i;
                        break;
                    end
                end
                robotNodeR = obj.NodeCoordinate(robotNode,2);
                robotNodeC = obj.NodeCoordinate(robotNode,3);
                obj.RobotArray(i,1).setAttribute(i,robotNodeR,robotNodeC,robotNode);
            end            
        end
        
        %�����б���ʼ��
        function initializeTask(obj)
            obj.TaskList = [];
            depotNodeCopy = obj.DepotNode;
            for i = 1:obj.TaskAmount
                startIndex = unidrnd(size(obj.PickUpNode,1));
                start = obj.PickUpNode(startIndex,1);
                %%%%%%%%%%%%%��֤�����յ㲻�ظ�%%%%%%%%%%
                finalIndex = unidrnd(size(depotNodeCopy,1));
                final = depotNodeCopy(finalIndex,1);
                depotNodeCopy(finalIndex,:) = []; 
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                row = size(obj.TaskList,1);
                obj.TaskList(row+1,1) = start;
                obj.TaskList(row+1,2) = final;
            end
            obj.LeftTaskList = obj.TaskList;
        end
                
        %���˳�ʼ���������ù������кš���������Ѳ��������ʼλ���ڹ��������ʼ��
        function initializeWorker(obj)
            obj.WorkerArray(obj.TotalWorkerNumber,1) = Worker;
            for i = 1:obj.TotalWorkerNumber
                obj.WorkerArray(i,1) = Worker;
                obj.WorkerArray(i,1).setAttribute(i);
            end
        end
        
        %ȫ��������λ���趨����������Ϊ�������꣬�����ڲ�ת��Ϊդ�����ꡣ�������ã����в���Ҫ������
        function setAllRobotLocation(obj,allLocation)
            allLocation = world2grid(obj.Map,allLocation);
            for i = 1:obj.TotalRobotNumber
                obj.RobotArray(i,1).setLocation(allLocation(i,:));
            end   
        end
        
        %ȫ��������λ�ö�ȡ������������Ϊ�������꣬�ڲ���դ������ת��������
        function allLocation = getAllRobotLocation(obj)
            allLocation = zeros(obj.TotalRobotNumber,2);
            for i = 1:obj.TotalRobotNumber
                allLocation(i,:) = obj.RobotArray(i,1).getLocation();
            end
            %disp(allLocation);
            allLocation = grid2world(obj.Map,allLocation);
        end
        
        %ȫ��������gridλ�ö�ȡ������������Ϊgrid���꣬�������˴������е�λ����Ϣ��
        function allLocation = getAllRobotGridLocation(obj)
            allLocation = zeros(obj.TotalRobotNumber,2);
            for i = 1:obj.TotalRobotNumber
                allLocation(i,:) = obj.RobotArray(i,1).getLocation();
            end
        end
                
        %ȫ������λ���趨����������Ϊ�������꣬�ڲ�ת��Ϊդ�����ꡣ�������ã����в�����Ҫ������
        function setAllWorkerLocation(obj,allLocation)        
            allLocation = world2grid(obj.Map,allLocation);
            for i = 1:obj.TotalWorkerNumber
                obj.WorkerArray(i,1).setLocation(allLocation(i,:));
            end   
        end
        
        %ȫ������λ�ö�ȡ������������Ϊ�������꣬�ڲ���դ������ת��������
        function allLocation = getAllWorkerLocation(obj)  
            allLocation = zeros(obj.TotalWorkerNumber,2);
            for i = 1:obj.TotalWorkerNumber
                allLocation(i,:) = obj.WorkerArray(i,1).getLocation();
            end
            allLocation = grid2world(obj.Map,allLocation);             
        end
 
        %�����������ѯ�����˵�״̬�������������״̬��ϢΪ0������������������
        function taskAllocator(obj)
            disp('taskAllocator');
            if obj.TaskIndex < obj.TaskAmount || obj.TaskIndex == obj.TaskAmount %�������л���δ�·�������
                freeRobot = [];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��¼���л�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                for i = 1:obj.TotalRobotNumber
                    if obj.RobotArray(i,1).getStatus() == 0
                        row = size(freeRobot,1);
                        freeRobot(row+1,1) = obj.RobotArray(i,1).getNumber();
                    end
                end
                disp('���л�����');
                disp(freeRobot);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if size(freeRobot,1) ~= 0 %���ڿ��л�����
                    for j = 1:size(freeRobot,1)
                        try
                            endNode = obj.TaskList(obj.TaskIndex,2);
                        catch
                            disp('obj.TaskIndex');
                            disp(obj.TaskIndex);
                        end
                        endNode = obj.TaskList(obj.TaskIndex,2);
                        %%%%%%%%%%%%%%�ж����п��л����˵ĵ�ǰλ�ýڵ����Ƿ��е��������յ��%%%%%%%%%%%%%
                        for l = 1:size(freeRobot,1)
                            a = [];
                            robotNumber = freeRobot(l,1);
                            robotNode = obj.RobotArray(robotNumber,1).getNode();
                            if endNode == robotNode
                                obj.RobotArray(robotNumber,1).setStatus(1);
                                obj.RobotArray(robotNumber,1).setGoal(obj.TaskList(obj.TaskIndex,1),obj.TaskList(obj.TaskIndex,2));
                                obj.RobotArray(robotNumber,1).setPlanned(0);
                                obj.TaskRobot(obj.TaskIndex,1) = robotNumber;
                                freeRobot(find(freeRobot == robotNumber),:) = [];
                                obj.TaskIndex = obj.TaskIndex + 1; 
                                a(1,1) = robotNumber;
                                column1 = obj.PickUpNodeOccupancy(:,1);
                                column2 = obj.DepotNodeOccupancy(:,1);
                                index1 = find(column1 == obj.RobotArray(robotNumber,1).taskStartNode);
                                index2 = find(column2 == obj.RobotArray(robotNumber,1).taskEndNode);
                                if obj.PickUpNodeOccupancy(index1,2) == 0
                                    obj.PickUpNodeOccupancy(index1,2) = 1;
                                    obj.PickUpNodeOccupancy(index1,3) = robotNumber;                                    
                                end
                                if obj.DepotNodeOccupancy(index2,2) == 0
                                    obj.DepotNodeOccupancy(index2,2) = 1;
                                    obj.DepotNodeOccupancy(index2,3) = robotNumber;                                    
                                end
%                                 obj.PickUpNodeOccupancy(index1,2) = 1;
%                                 obj.PickUpNodeOccupancy(index1,3) = robotNumber;
%                                 obj.DepotNodeOccupancy(index1,2) = 1;
%                                 obj.DepotNodeOccupancy(index1,3) = robotNumber;
                                break;
                            end
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���п��л��������ڵ�λ�ö����ǵ�ǰ������յ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if isempty(a)
                            startNode = obj.TaskList(obj.TaskIndex,1);
                            distance = inf;
                            robotNumber = 0;
                            %%%%%%%%%%%%%%%%%%%%%%%�Ե�ǰ����Ѱ��freeRobot�о���������������%%%%%%%%%%%%%%%%%%%%%
                            for i = 1:size(freeRobot,1)
                                number = freeRobot(i,1);
                                robotNode = obj.RobotArray(number,1).getNode();
                                row = obj.NodeCoordinate(robotNode,2);
                                column = obj.NodeCoordinate(robotNode,3);
                                %%%%%%%%%%%%%%%%%%%������ܵ�֮ǰ��һ����%%%%%%%%%%%%%%%%%%
                                if obj.MapSignalNode(row-1,column) == 1 %������һ�еĵ�
                                    destinationNode = obj.MapNode(row+1,column);
                                else %������һ�еĵ�
                                    destinationNode = obj.MapNode(row-1,column);
                                end
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                d = abs(obj.NodeCoordinate(startNode,2) - obj.NodeCoordinate(destinationNode,2)) + abs(obj.NodeCoordinate(startNode,3) - obj.NodeCoordinate(destinationNode,3));
                                if d < distance
                                    distance = d;
                                    robotNumber = number;
                                end
                            end 
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            obj.RobotArray(robotNumber,1).setStatus(1);
                            obj.RobotArray(robotNumber,1).setGoal(obj.TaskList(obj.TaskIndex,1),obj.TaskList(obj.TaskIndex,2));
                            obj.RobotArray(robotNumber,1).setPlanned(0);
                            obj.TaskRobot(obj.TaskIndex,1) = robotNumber;
                            freeRobot(find(freeRobot == robotNumber),:) = [];
                            obj.TaskIndex = obj.TaskIndex + 1;   
                            column1 = obj.PickUpNodeOccupancy(:,1);
                            column2 = obj.DepotNodeOccupancy(:,1);
                            index1 = find(column1 == obj.RobotArray(robotNumber,1).taskStartNode);
                            index2 = find(column2 == obj.RobotArray(robotNumber,1).taskEndNode);
                            if obj.PickUpNodeOccupancy(index1,2) == 0
                                obj.PickUpNodeOccupancy(index1,2) = 1;
                                obj.PickUpNodeOccupancy(index1,3) = robotNumber;                                    
                            end
                            if obj.DepotNodeOccupancy(index2,2) == 0
                                obj.DepotNodeOccupancy(index2,2) = 1;
                                obj.DepotNodeOccupancy(index2,3) = robotNumber;                                    
                            end                                                       
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        if obj.TaskIndex > obj.TaskAmount %�����Ѿ������꣬���������Ƿ��п��л����ˣ��������������ѭ��
                            break;
                        end
                    end
                end
            end
                        
%             for i=1:obj.TotalRobotNumber
%                 %���ݻ�����״̬��������
%                 if (obj.TaskIndex <=obj.TotalTaskNumber)
%                     if (obj.RobotArray(i,1).getStatus() == 0)&&(obj.RobotArray(i,1).TimeDelay1 == 10)
%                         obj.RobotArray(i,1).setTask(obj.TaskIndex,obj.TaskArray);
%                             obj.TaskIndex = obj.TaskIndex + 1;
%                     end
%                 end                
%             end
%            temp = obj.AllTaskCompleted;
%            temp = temp(temp~=0);
%            obj.TaskCounter = obj.TaskCounter + length(temp);
%            disp(obj.TaskCounter);
%            obj.AllTaskCompleted = zeros(obj.TotalRobotNumber,1); 
        end
        
        %���ݹ滮�õ�ʱ�䴰�жϻ������Ƿ��ƶ�,����Ȩ��ռ��
        function updateAllRobot(obj,Time)  
            disp('updateAllRobot');
            for i = 1:obj.TotalRobotNumber
                TWSerial = obj.AllRobotTW{i,1};
                if ~isempty(TWSerial)
                    robotNode = obj.RobotArray(i,1).getNode();
                    TWSerialC1 = TWSerial(:,1);
                    index = find(TWSerialC1 == robotNode);
                    robotNodeEndT = TWSerial(index,3);
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ж��ǲ���TWSerial�����һ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if index == size(TWSerial,1) %��TWSerial�����һ����
                        if Time == robotNodeEndT %�õ�ռ�ý���
                            obj.AllRobotTW{i,1} = []; %ʱ�䴰���
                            if robotNode == obj.RobotArray(i,1).taskStartNode %���ڴ������λ�� 
                                obj.RobotArray(i,1).setPlanned(0);
                                column = obj.DepotNodeOccupancy(:,1);
                                index1 = find(column == obj.RobotArray(i,1).taskEndNode);                                
                                if obj.DepotNodeOccupancy(index1,2) == 0 || ((obj.DepotNodeOccupancy(index1,2) == 1)&&(obj.DepotNodeOccupancy(index1,3) == i))
                                    startNode = obj.RobotArray(i,1).taskStartNode;
                                    endNode = obj.RobotArray(i,1).taskEndNode;                                
                                    obj.TWPathPlanning(i,(Time+1),startNode,endNode,1);
                                    obj.DepotNodeOccupancy(index1,2) = 1;
                                    obj.DepotNodeOccupancy(index1,3) = i;   
                                    obj.RobotArray(i,1).setPlanned(1);
                                end                                 
                            elseif robotNode == obj.RobotArray(i,1).taskEndNode %���ڴ����յ�λ��
                                obj.RobotArray(i,1).setStatus(0);
                                obj.RobotArray(i,1).setPlanned(0);
                                obj.FinishedTaskNum = obj.FinishedTaskNum + 1;
                            end
                        end
                    else %����TWSerial�����һ����
                        if Time == (robotNodeEndT + 1)
                            %%%%%%%%%%%%%%%%%%%%%%%%��ǰ�㲻�ǹ滮��·�����������һ����,������ǰ��%%%%%%%%%%%%%%%%%%%%%%
                            nextNode = TWSerialC1(index+1,1);
                            location = [];
                            location(1,1) = obj.NodeCoordinate(nextNode,2);
                            location(1,2) = obj.NodeCoordinate(nextNode,3);
                            obj.RobotArray(i,1).setLocation(location);
                            obj.RobotArray(i,1).setNode(nextNode);
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Ȩ�޵��ͷ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if robotNode == TWSerialC1(1,1) %��TWSerial�е�һ����
                                if robotNode == obj.RobotArray(i,1).taskStartNode %��Ҫ�뿪�������
                                    occupancyColumn = obj.PickUpNodeOccupancy(:,1);
                                    Index = find(occupancyColumn == robotNode);
                                    obj.PickUpNodeOccupancy(Index,2) = 0;
                                    obj.PickUpNodeOccupancy(Index,3) = 0;                                    
                                else 
                                    if robotNode ~= obj.RobotArray(i,1).taskEndNode %ֻ�е��������������ڽڵ��������յ㲻һ��ʱ���ſ��ͷŸõ��Ȩ��
                                        occupancyColumn = obj.DepotNodeOccupancy(:,1);
                                        Index = find(occupancyColumn == robotNode);
                                        obj.DepotNodeOccupancy(Index,2) = 0;
                                        obj.DepotNodeOccupancy(Index,3) = 0;
                                    end                                    
                                end
                            end
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        end                        
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                end
            end
        end
        
        %��������Ҫ���й켣�滮�Ļ����˽��й滮
        function allRobotPlanning(obj,Time)
            disp('allRobotPlanning');
            plannedRobotNum = 0;
            for i = 1:obj.TotalRobotNumber
                if plannedRobotNum < obj.PlanningRobotNumUp %�ж��Ƿ񵽴�滮����
                    if obj.RobotArray(i,1).getPlanned() == 0 && obj.RobotArray(i,1).getStatus() == 1 %�������������һ�δ�滮
                        robotNode = obj.RobotArray(i,1).getNode();
                        startNode = obj.RobotArray(i,1).taskStartNode;
                        endNode = obj.RobotArray(i,1).taskEndNode;
                        a = find(obj.DepotNodeOccupancy(:,1) == robotNode); %�жϻ����˵�ǰλ���Ƿ��ǷŻ���
                        if robotNode == startNode %�����˵�ǰλ���������
                            column = obj.DepotNodeOccupancy(:,1);
                            index = find(column == endNode);                            
                            if (obj.DepotNodeOccupancy(index,2) == 0) || ((obj.DepotNodeOccupancy(index,2) == 1)&&(obj.DepotNodeOccupancy(index,3) == i)) %�����յ��Ȩ���ѱ��ͷ�
                                obj.TWPathPlanning(i,(Time+1),startNode,endNode,1);
                                obj.RobotArray(i,1).setPlanned(1);
                                plannedRobotNum = plannedRobotNum + 1;     
                                obj.DepotNodeOccupancy(index,2) = 1;
                                obj.DepotNodeOccupancy(index,3) = i;  
                            end
                        elseif ~isempty(a) %������λ�ڷŻ��� 
                            column = obj.PickUpNodeOccupancy(:,1);
                            index = find(column == startNode);
                            if (obj.PickUpNodeOccupancy(index,2) == 0) || ((obj.PickUpNodeOccupancy(index,2) == 1)&&(obj.PickUpNodeOccupancy(index,3) == i)) %��������Ȩ���ѱ��ͷ�
                                obj.TWPathPlanning(i,Time,startNode,robotNode,-1);
                                obj.RobotArray(i,1).setPlanned(1);
                                plannedRobotNum = plannedRobotNum + 1;                              
                                obj.PickUpNodeOccupancy(index,2) = 1;
                                obj.PickUpNodeOccupancy(index,3) = i;                                
                            end
                        end
                    end                    
                end
            end
        end
        
        %ʱ�䴰�滮�㷨
        function TWPathPlanning(obj,Number,Time,StartNode,EndNode,order) %order,1:��ȡ�������Ż���/-1:�ӷŻ�����ȡ����
            kPlannedResult = []; %��ʱ�洢K�����·���Ĺ滮������Ż�ʱ��
            kShortestPaths = [];            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��KShortestPaths��������K���·��%%%%%%%%%%%%%%%%%%%%%%%%%%%%(��������ʱ��)
%             index = find(obj.KShortestPathsNodePair(:,1) == StartNode);
%             for i = 1:size(index,1)
%                 if obj.KShortestPathsNodePair(index(i,1),2) == EndNode %ƥ����
%                     kShortestPaths = obj.KShortestPaths{index(i,1),3};
%                     break;
%                 end
%             end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����ʱ�øò��ִ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            column = obj.DepotNearCrossNode(:,1);
            index = find(column == EndNode);
            crossNode1 = obj.DepotNearCrossNode(index,2);
            crossNode2 = obj.DepotNearCrossNode(index,3);            
            [shortestPaths, totalCosts] = WarehouseKShortestPath(obj.AdjacentMatrix, obj.NodeCoordinate, obj.MapSignalNode, obj.MapNode, obj.AdjacentMatrixNode, StartNode, crossNode1, crossNode2, EndNode, 5, 5);
            kShortestPaths = shortestPaths;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��K��·���ϵĽڵ㲹������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            kPathNode = []; %�洢K��·��������·����
            for i = 1:size(kShortestPaths,2)
                pathCrossNode = kShortestPaths{1,i}; %ÿһ��·����Ӧ����� + ����ڽڵ� + �յ�
                pathNode = []; %��¼��ǰ·���е������ڵ�
                if order == 1
                    for j = 1:(size(pathCrossNode,2)-1)
                        node1 = pathCrossNode(1,j);
                        node2 = pathCrossNode(1,j+1);
                        r1 = obj.NodeCoordinate(node1,2);
                        c1 = obj.NodeCoordinate(node1,3);
                        r2 = obj.NodeCoordinate(node2,2);
                        c2 = obj.NodeCoordinate(node2,3); 
                        pathNode(size(pathNode,1)+1,1) = node1;
                        if r1 == r2
                            deltaC = abs(c2 - c1);
                            for k = 1:(deltaC-1)
                                C = c1 + k*sign(c2-c1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(r1,C);
                            end
                        elseif c1 == c2
                            deltaR = abs(r2-r1);
                            for k = 1:(deltaR-1)
                                R = r1 + k*sign(r2-r1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(R,c1);
                            end                            
                        end
                    end   
                    pathNode(size(pathNode,1)+1,1) = pathCrossNode(1,size(pathCrossNode,2));
                elseif order == -1
                    for j = size(pathCrossNode,2):-1:2
                        node1 = pathCrossNode(1,j);
                        node2 = pathCrossNode(1,j-1);
                        r1 = obj.NodeCoordinate(node1,2);
                        c1 = obj.NodeCoordinate(node1,3);
                        r2 = obj.NodeCoordinate(node2,2);
                        c2 = obj.NodeCoordinate(node2,3);  
                        pathNode(size(pathNode,1)+1,1) = node1;
                        if r1 == r2
                            deltaC = abs(c2 - c1);
                            for k = 1:(deltaC-1)
                                C = c1 + k*sign(c2-c1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(r1,C);
                            end
                        elseif c1 == c2
                            deltaR = abs(r2-r1);
                            for k = 1:(deltaR-1)
                                R = r1 + k*sign(r2-r1);
                                pathNode(size(pathNode,1)+1,1) = obj.MapNode(R,c1);
                            end                            
                        end                        
                    end
                    pathNode(size(pathNode,1)+1,1) = pathCrossNode(1,1);
                end 
                kPathNode{i,1} = pathNode;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ΪK��·������ʱ�䴰%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for i = 1:size(kPathNode,1)
                pathNode = kPathNode{i,1};
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%ʱ�䴰��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                InitializedTW = zeros(size(pathNode,1),2);
                for j = 1:size(pathNode,1)
                    if j == size(pathNode,1)
                        InitializedTW(j,1) = pathNode(j,1);
                        InitializedTW(j,2) = 3;                        
                    else
                        InitializedTW(j,1) = pathNode(j,1);
                        InitializedTW(j,2) = 1;                        
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
                plannedSuccess = 0; %��¼ĳ��path��ʱ�䴰�滮�Ƿ���ɣ�0-δ��ɣ�1-��ɣ�
                pathNodeIndex = 0;
                nodeOverlapIndex = 0;
                InsertedTW = zeros(size(InitializedTW,1),4);
                eachPlannedTW = zeros(size(InitializedTW,1),4);
                k = 1;
                while plannedSuccess == 0
                    [InsertedTW, Node, t1, t2, Index] = obj.twInsert(InitializedTW,InsertedTW,Time,order,Number,pathNodeIndex,nodeOverlapIndex);
                    ConnectedTW = obj.twConnect(InsertedTW);
                    [pathNodeIndex, nodeOverlapIndex, eachPlannedTW, plannedSuccess] = obj.twOverlapDetect(ConnectedTW);
                    %%%%%%%%%%%%%%%%%%���Ǵ�ȡ�������Ż��㣬���·�������е�һ�����ʱ�䴰����%%%%%%%%%%%%%%%%%
%                     if order == 1 
%                         if ~((i == obj.K)&&(plannedSuccess == 1))
%                             if isempty(obj.AllNodeTW{Node,1}) %Node������û��ʱ�䴰
%                                 obj.AllNodeTW{Node,1}(1,1) = t1;
%                                 obj.AllNodeTW{Node,1}(1,2) = t2;
%                                 obj.AllNodeTW{Node,1}(1,3) = Number;
%                             else %Node��������ʱ�䴰
%                                 if Index == 1 %���ڵ�һ��
%                                     obj.AllNodeTW{Node,1} = [[t1 t2 Number];obj.AllNodeTW{Node,1}];
%                                 elseif Index == (size(obj.AllNodeTW{Node,1},1) + 1)
%                                     obj.AllNodeTW{Node,1} = [obj.AllNodeTW{Node,1};[t1 t2 Number]];
%                                 else
%                                     obj.AllNodeTW{Node,1} = [obj.AllNodeTW{Node,1}(1:Index-1,:);[t1 t2 Number];obj.AllNodeTW{Node,1}(Index:end,:)];
%                                 end
%                             end
%                         end
%                     end
                    
%                     if k < 20
%                         disp('�����˱��');disp(Number);
%                         disp('pathNodeIndex');disp(pathNodeIndex);disp('nodeOverlapIndex');disp(nodeOverlapIndex);                        
%                         k = k + 1;
%                     end

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                end
                %%%%%%%%%%%%%%%%%%%%�ѹ滮�������kPlannedResult��%%%%%%%%%%%%%%%%%%%%
                kPlannedResult{size(kPlannedResult,1)+1,1} = eachPlannedTW;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����kPlannedResult��K��·����ѡ�����Ž��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            finishT = inf;
            index = 0;
            for i = 1:size(kPlannedResult,1)
                T = kPlannedResult{i,1}(size(kPlannedResult{i,1},1),3) - kPlannedResult{i,1}(1,2) + 1;
                if T < finishT
                    finishT = T;
                    index = i;
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��������ʻ��������AllNodeTW��AllRobotTW��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            plannedTW = kPlannedResult{index,1};
            obj.AllRobotTW{Number,1} = zeros(size(plannedTW,1),3);
            for i = 1:size(plannedTW,1)
                obj.AllRobotTW{Number,1}(i,1) = plannedTW(i,1);
                obj.AllRobotTW{Number,1}(i,2) = plannedTW(i,2);
                obj.AllRobotTW{Number,1}(i,3) = plannedTW(i,3);
                if isempty(obj.AllNodeTW{plannedTW(i,1),1}) %node������ʱ�䴰   
                    obj.AllNodeTW{plannedTW(i,1),1}(1,1) = plannedTW(i,2);
                    obj.AllNodeTW{plannedTW(i,1),1}(1,2) = plannedTW(i,3);
                    obj.AllNodeTW{plannedTW(i,1),1}(1,3) = Number;
                else %node������ʱ�䴰
%                     disp('�����˱��');
%                     disp(Number);
%                     disp(i);
%                     disp(plannedTW(i,1))
%                     disp(plannedTW(i,4));
                    if plannedTW(i,4) == 1 %���ڵ�һ��
                        obj.AllNodeTW{plannedTW(i,1),1} = [[plannedTW(i,2) plannedTW(i,3) Number];obj.AllNodeTW{plannedTW(i,1),1}];
                    elseif plannedTW(i,4) == (size(obj.AllNodeTW{plannedTW(i,1),1},1) + 1) %�������һ��
                        obj.AllNodeTW{plannedTW(i,1),1} = [obj.AllNodeTW{plannedTW(i,1),1};[plannedTW(i,2) plannedTW(i,3) Number]];
                    else %�����м�
                        obj.AllNodeTW{plannedTW(i,1),1} = [obj.AllNodeTW{plannedTW(i,1),1}(1:(plannedTW(i,4)-1),:);[plannedTW(i,2) plannedTW(i,3) Number];obj.AllNodeTW{plannedTW(i,1),1}(plannedTW(i,4):end,:)];
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ʱ�䴰�㷨1����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %ʱ�䴰����
        function [InsertedTW, Node, t1, t2, Index] = twInsert(obj,InitializedTW,InsertedTW,Time,order,Number,pathNodeIndex,nodeOverlapIndex) 
            Node = 0;
            t1 = 0;
            t2 = 0;
            Index = 0;
            if pathNodeIndex == 0 %��һ�β���
                for i = 1:size(InitializedTW,1)
                    node = InitializedTW(i,1); %��ǰ��Ҫ����ʱ�䴰����Ľڵ�
                    if i == 1 %·�������ϵ�һ����
%                         if order == 1 %��ȡ�������Ż���
%                             disp(Number);
%                             if isempty(obj.AllNodeTW{node,1}) %node1�ϻ�û���κε�ʱ�䴰
%                                 InsertedTW(i,1) = node;
%                                 InsertedTW(i,2) = Time;
%                                 InsertedTW(i,3) = Time;
%                                 InsertedTW(i,4) = 1;
%                             else %node1���Ѿ���ʱ�䴰
%                                 indexList = find(obj.AllNodeTW{node,1}(:,3) == Number);
%                                 disp('�û�����ռ�øõ�ʱ�䴰��index');
%                                 disp(indexList);
%                                 index = indexList(size(indexList,1),1);
%                                 InsertedTW(i,1) = node;
%                                 InsertedTW(i,2) = obj.AllNodeTW{node,1}(index,1);
%                                 InsertedTW(i,3) = obj.AllNodeTW{node,1}(index,2);
%                                 InsertedTW(i,4) = index;    
%                                 obj.AllNodeTW{node,1}(index,:) = [];
%                                 Node = node;
%                                 t1 = InsertedTW(i,2);
%                                 t2 = InsertedTW(i,3);
%                                 Index = InsertedTW(i,4);
%                             end
%                         elseif order == -1 %�ӷŻ�����ȡ����
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = Time;
                            InsertedTW(i,3) = Time;
                            InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                        
%                         end                    
                    else %·�������ϵ�һ����֮��
                        lastNodeEndTime = InsertedTW(i-1,3);
                        nodeTimeLength = InitializedTW(i,2);
                        if size(obj.AllNodeTW{node,1},1) == 0 %node�ϻ�û���κ�ʱ�䴰
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = lastNodeEndTime + 1;
                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                            InsertedTW(i,4) = 1;                        
                        elseif size(obj.AllNodeTW{node,1},1) == 1 %node��ֻ��һ��ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                             
                            else %���ڵ�һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(1,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(1,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(1,2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(1,2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                    
                                end
                                InsertedTW(i,4) = 2;                                  
                            end
                        else %node������������ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                            
                            elseif (lastNodeEndTime+1) > obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) || (lastNodeEndTime+1) == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) %�������һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                              
                            else
                                success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                                for j = 1:(size(obj.AllNodeTW{node,1},1)-1) 
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(j,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(j,2) %��node�ϵ�j��ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) > (nodeTimeLength+2) || (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) == (nodeTimeLength+2) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 1 + 1;
                                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 1 + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = lastNodeEndTime + 1;
                                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    end
                                end
                                if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                    InsertedTW(i,1) = node;
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = lastNodeEndTime + 1;
                                        InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                    end
                                    InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                   
                                end
                            end
                        end
                    end
                end
            elseif pathNodeIndex ~= 0 %ʱ�䴰�н��棬���²���
%                 if order == 1
%                     node = InitializedTW(1,1);
%                     indexList = find(obj.AllNodeTW{node,1}(:,3) == Number);
%                     index = indexList(size(indexList,1),1);  
%                     Node = node;
%                     t1 = obj.AllNodeTW{node,1}(index,1);
%                     t2 = obj.AllNodeTW{node,1}(index,2);
%                     Index = index;                 
%                     obj.AllNodeTW{node,1}(index,:) = [];
%                 end
                try
                    lastNodeEndTime = InsertedTW(pathNodeIndex-1,3);
                catch
                    disp(order);
                    disp(Number);
                    disp(Time);
                    disp(pathNodeIndex);
                    disp(nodeOverlapIndex);
                    disp(InsertedTW(1,1));
                    disp(InsertedTW(1,:));
                    disp(obj.AllNodeTW{InsertedTW(1,1),1});
                end
                %%%%%%%%%%%%%%%%%%InsertedTW��pathNodeIndex���Ժ�Ķ���0%%%%%%%%%%%%%%%%
                for i = pathNodeIndex:size(InsertedTW,1)
                    for j = 1:4
                        InsertedTW(i,j) = 0;
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                for i = pathNodeIndex:size(InsertedTW,1)
                    node = InitializedTW(i,1);
                    lastNodeEndTime = InsertedTW(i-1,3);
                    nodeTimeLength = InitializedTW(i,2);                    
                    if i == pathNodeIndex %ʱ�䴰�н�����Ǹ���,����nodeOverlapIndex���в���
                        if nodeOverlapIndex == size(obj.AllNodeTW{node,1},1) %���������һ��
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                            InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                             
                        else
                            success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                            for j = nodeOverlapIndex:(size(obj.AllNodeTW{node,1},1)-1) 
                                if (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) > (nodeTimeLength+2) || (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) == (nodeTimeLength+2) %���ڵ�j��ʱ�䴰֮��
                                    InsertedTW(i,1) = node;
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 1 + nodeTimeLength;
                                    InsertedTW(i,4) = j + 1;  
                                    success = 1;
                                    break;
                                end                                        
                            end
                            if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                
                            end                            
                        end
                    else %·�������ϵ�һ����֮��
                        if size(obj.AllNodeTW{node,1},1) == 0 %node�ϻ�û���κ�ʱ�䴰
                            InsertedTW(i,1) = node;
                            InsertedTW(i,2) = lastNodeEndTime + 1;
                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                            InsertedTW(i,4) = 1;                        
                        elseif size(obj.AllNodeTW{node,1},1) == 1 %node��ֻ��һ��ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                             
                            else %���ڵ�һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(1,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(1,2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(1,2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(1,2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                    
                                end
                                InsertedTW(i,4) = 2;                                  
                            end
                        else %node������������ʱ�䴰
                            if (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %�ɲ��ڵ�һ��ʱ�䴰֮ǰ
                                InsertedTW(i,1) = node;
                                InsertedTW(i,2) = lastNodeEndTime + 1;
                                InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                InsertedTW(i,4) = 1;                            
                            elseif (lastNodeEndTime+1) > obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) || (lastNodeEndTime+1) == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),1) %�������һ��ʱ�䴰֮��
                                InsertedTW(i,1) = node;
                                if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                    InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                    InsertedTW(i,2) = lastNodeEndTime + 1;
                                    InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                end
                                InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                              
                            else
                                success = 0; %�ж�node���м�ʱ�䴰�Ŀ�϶�ܷ���ȥ
                                for j = 1:(size(obj.AllNodeTW{node,1},1)-1) 
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(j,2) || lastNodeEndTime == obj.AllNodeTW{node,1}(j,2) %��node�ϵ�j��ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) > (nodeTimeLength+2) || (obj.AllNodeTW{node,1}(j+1,1) - (obj.AllNodeTW{node,1}(j,2)+1)) == (nodeTimeLength+2) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = obj.AllNodeTW{node,1}(j,2) + 1 + 1;
                                            InsertedTW(i,3) = obj.AllNodeTW{node,1}(j,2) + 1 + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        if (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) > (nodeTimeLength+1) || (obj.AllNodeTW{node,1}(j+1,1) - (lastNodeEndTime+1)) == (nodeTimeLength+1) %���ڵ�j��ʱ�䴰֮��
                                            InsertedTW(i,1) = node;
                                            InsertedTW(i,2) = lastNodeEndTime + 1;
                                            InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;
                                            InsertedTW(i,4) = j + 1;  
                                            success = 1;
                                            break;
                                        end                                        
                                    end
                                end
                                if success == 0 %node���м�ʱ�䴰�Ŀ�϶���ܲ��ȥ,ֻ�ܲ������
                                    InsertedTW(i,1) = node;
                                    if lastNodeEndTime < obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) || lastNodeEndTime == obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) %��node�����һ��ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + 1;
                                        InsertedTW(i,3) = obj.AllNodeTW{node,1}(size(obj.AllNodeTW{node,1},1),2) + 1 + nodeTimeLength;
                                    else %��nodeǰһ����ʱ�䴰����ֹʱ��Ϊ��׼
                                        InsertedTW(i,2) = lastNodeEndTime + 1;
                                        InsertedTW(i,3) = lastNodeEndTime + nodeTimeLength;                                       
                                    end
                                    InsertedTW(i,4) = size(obj.AllNodeTW{node,1},1) + 1;                                   
                                end
                            end
                        end
                    end
                end
            end
        end        
        
        %ʱ�䴰����
        function ConnectedTW = twConnect(obj,InsertedTW) 
            ConnectedTW = zeros(size(InsertedTW,1),4);
            for i = 1:(size(InsertedTW,1)-1)
                ConnectedTW(i,1) = InsertedTW(i,1);
                ConnectedTW(i,2) = InsertedTW(i,2);
                ConnectedTW(i,3) = InsertedTW(i+1,2) - 1;
                ConnectedTW(i,4) = InsertedTW(i,4);
            end
            ConnectedTW(size(ConnectedTW,1),1) = InsertedTW(size(InsertedTW,1),1);
            ConnectedTW(size(ConnectedTW,1),2) = InsertedTW(size(InsertedTW,1),2);
            ConnectedTW(size(ConnectedTW,1),3) = InsertedTW(size(InsertedTW,1),3);
            ConnectedTW(size(ConnectedTW,1),4) = InsertedTW(size(InsertedTW,1),4);
        end        
        
        %ʱ�䴰Overlap���
        % pathNodeIndex:path�ϵ�һ������ʱ�䴰�������path�ϵڼ�����,0-δ����,��������-�н���
        % nodeOverlapIndex:��node�ϵ�ʱ�䴰���������ʱ�䴰��ŵ����һ��,0-δ����,��������-�н���
        function [pathNodeIndex, nodeOverlapIndex, eachPlannedTW, plannedSuccess] = twOverlapDetect(obj,ConnectedTW) 
            success = 1;%��¼�Ƿ���ʱ�䴰���棬0-�н��棬1-û�н���
            eachPlannedTW = zeros(size(ConnectedTW,1),4);
            for i = 1:(size(ConnectedTW,1)-1)
                node = ConnectedTW(i,1);
                t1 = ConnectedTW(i,2);
                t2 = ConnectedTW(i,3);
                if size(obj.AllNodeTW{node,1},1) == 0 %node��û��ʱ�䴰����
                    continue;
                else %node����ʱ�䴰����
                    for j = size(obj.AllNodeTW{node,1},1):-1:1
                        t3 = obj.AllNodeTW{node,1}(j,1);
                        t4 = obj.AllNodeTW{node,1}(j,2);
                        if ((t1<=t3)&&(t2>=t3)) || ((t2>=t4)&&(t1<=t4)) %ʱ�䴰���ڽ���
                            success = 0;
                            plannedSuccess = 0;
                            pathNodeIndex = i;
                            nodeOverlapIndex = j;
                            break;
                        end
                    end
                end                 
                if success == 0 %�Ѽ�⵽ʱ�䴰����
                    break;
                end
            end
            if success == 1 %ȫ�����һ�飬����ʱ�䴰û�н���
                plannedSuccess = 1;
                pathNodeIndex = 0;
                nodeOverlapIndex = 0;
                for i = 1:size(ConnectedTW,1)
                    for j = 1:4
                        eachPlannedTW(i,j) = ConnectedTW(i,j);
                    end
                end
            end
        end        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %����ȫ�����ˡ��ٶ�1m/s��
        function updateAllWorker(obj)           
%             obj.WorkerArrayTimer=~obj.WorkerArrayTimer;
            obj.WorkerArrayTimer = true;
            if obj.WorkerArrayTimer                
                for i = 1:obj.TotalWorkerNumber
                    %��ǰ�����˵������Ϣ��״̬��Ϣ��λ����Ϣȫ�����빤��
                    obj.WorkerArray(i,1).updateRobotInfo(obj.TotalRobotNumber,obj.AllStatus,obj.AllLocation);                    
                    obj.WorkerArray(i,1).updateLocation();
                    obj.AllWorkerLocation(i,:) = obj.WorkerArray(i,1).getLocation();
                    %����Picked��Ϣ�����ץȡ�Ļ����˶�Ӧ��������1
                    temp = obj.WorkerArray(i,1).getRobotPicked();
                    if temp ~= 0                       
                        obj.AllPickedRobotSerial(temp,1) = 1; 
                    end
                end                                
            end
        end
      
        %��ͼ������
        function plotAll(obj)
                        
            show(obj.Map);
            hold on;
            axis([0 15.5 0 10.5]);
            axis manual;
     
            tempFailureR = grid2world(obj.Map,[1 1;1 1]);
            obj.g = plot(tempFailureR(:,1),tempFailureR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8);            
 
            tempFailureR = grid2world(obj.Map,[1 1;1 1]);
            obj.m = plot(tempFailureR(:,1),tempFailureR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);              
                      
            tempR = obj.getAllRobotLocation();  %�ݴ����л�����λ�á�
            obj.h = plot(tempR(:,1),tempR(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor','g','MarkerSize',8);
            
            
            i = 1;
            while obj.FinishedTaskNum ~= obj.TaskAmount
                %�����񣬻����ˣ����˵Ĵ���˳���Ⱥ����״̬
                RobotAllLocation = zeros(obj.TotalRobotNumber,2);
                for j = 1:obj.TotalRobotNumber
                    RobotAllLocation(j,:) = obj.RobotArray(j,1).getLocation();
                end
                obj.LastTLocation = RobotAllLocation;
                
                
                
                obj.taskAllocator();
                obj.updateAllRobot(i);  
                obj.allRobotPlanning(i);
%                 obj.updateAllWorker();
                tempR = obj.getAllRobotLocation(); 
            
%                 tempW = obj.getAllWorkerLocation(); 
                obj.h.XData = tempR(:,1);
                obj.h.YData = tempR(:,2);
%                 obj.g.XData = tempW(:,1);
%                 obj.g.YData = tempW(:,2);

                RobotAllLocation = zeros(obj.TotalRobotNumber,2);
                for j = 1:obj.TotalRobotNumber
                    RobotAllLocation(j,:) = obj.RobotArray(j,1).getLocation();
                end
                obj.NowLocation = RobotAllLocation;  


                if obj.delay == 0
                    CandidateRobots = []; %��¼�ڵ�·���Ҵ��ڵȴ�״̬�Ļ����˱��
                    CandidateRobotsPath = []; %��¼�ڵ�·�ϵĻ����˱��
                    if i ~= 1
                        disp('aaa');
                        for j = 1:obj.TotalRobotNumber
                            if ((mod(obj.NowLocation(j,1),3) == 2) && ((obj.NowLocation(j,2) ~= 1) && (obj.NowLocation(j,2) ~= obj.AllColumn))) || (mod(obj.NowLocation(j,2),7) == 2) %�������ڵ�·�ڵ����Ҵ��ڵȴ�״̬
                                CandidatePathRow = size(CandidateRobotsPath,1);
                                CandidateRobotsPath(CandidatePathRow + 1,:) = j;
                                if  (obj.LastTLocation(j,1) == obj.NowLocation(j,1)) && (obj.LastTLocation(j,2) == obj.NowLocation(j,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    CandidateRow = size(CandidateRobots,1);
                                    CandidateRobots(CandidateRow+1,:) = j;
                                end
                            end
                        end
                    end
                    
                    if size(CandidateRobots,1) > 0 % CandidateRobots��������1��Ԫ��
                        if obj.delayNum == 1 %�ӳ�����Ϊ1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                            obj.RobotNumber1 = CandidateRobots(index1,1);

                            DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                            DelayRLocation = grid2world(obj.Map,DelayRLocation);
        %                    tempFailureR = DelayRLocation;
                            obj.g.XData = DelayRLocation(:,1);
                            obj.g.YData = DelayRLocation(:,2);                     

                            obj.delay = 1;
                            obj.CurrentT = i;

                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if (j ~= obj.RobotNumber1)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2);
                                                        
                        elseif obj.delayNum == 2 %�ӳ�����Ϊ2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                            obj.RobotNumber1 = CandidateRobots(index1,1);
                            CandidateRobots(index1,:) = [];
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobots(index2,1);
                            else % CandidateRobots����Ԫ��
                                IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                CandidateRobotsPath(IndexLocation,:) = [];
                                index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                            end

                            DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                            DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                            DelayRLocation = grid2world(obj.Map,DelayRLocation);
        %                    tempFailureR = DelayRLocation;
                            obj.g.XData = DelayRLocation(:,1);
                            obj.g.YData = DelayRLocation(:,2);                     

                            obj.delay = 1;
                            obj.CurrentT = i;

                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2);
                            
                        elseif obj.delayNum == 3 %�ӳ�����Ϊ3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                            obj.RobotNumber1 = CandidateRobots(index1,1);
                            CandidateRobots(index1,:) = [];
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobots(index2,1);
                                CandidateRobots(index2,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                CandidateRobotsPath(IndexLocation,:) = [];
                                index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                            end
                            
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobots(index3,1);
                            else % CandidateRobots����Ԫ��
                                %IndexLocation1 = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                %CandidateRobotsPath(IndexLocation1,:) = [];
                                CandidateRobotsPath(IndexLocation2,:) = [];
                                index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                            end

                            DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                            DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                            DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                            DelayRLocation = grid2world(obj.Map,DelayRLocation);
        %                    tempFailureR = DelayRLocation;
                            obj.g.XData = DelayRLocation(:,1);
                            obj.g.YData = DelayRLocation(:,2);                     

                            obj.delay = 1;
                            obj.CurrentT = i;

                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2);
                            
                        elseif obj.delayNum == 4 %�ӳ�����Ϊ4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                            obj.RobotNumber1 = CandidateRobots(index1,1);
                            CandidateRobots(index1,:) = [];
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobots(index2,1);
                                CandidateRobots(index2,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                CandidateRobotsPath(IndexLocation,:) = [];
                                index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                            end
                            
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobots(index3,1);
                                CandidateRobots(index3,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                CandidateRobotsPath(IndexLocation2,:) = [];
                                index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                            end

                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index4 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber4 = CandidateRobots(index4,1);
                            else % CandidateRobots����Ԫ��
                                IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                CandidateRobotsPath(IndexLocation3,:) = [];
                                index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                            end
                            
                            DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                            DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                            DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                            DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                            DelayRLocation = grid2world(obj.Map,DelayRLocation);
        %                    tempFailureR = DelayRLocation;
                            obj.g.XData = DelayRLocation(:,1);
                            obj.g.YData = DelayRLocation(:,2);                     

                            obj.delay = 1;
                            obj.CurrentT = i;

                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2);
                            
                        elseif obj.delayNum == 5 %�ӳ�����Ϊ5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                            obj.RobotNumber1 = CandidateRobots(index1,1);
                            CandidateRobots(index1,:) = [];
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobots(index2,1);
                                CandidateRobots(index2,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                CandidateRobotsPath(IndexLocation,:) = [];
                                index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                            end
                            
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobots(index3,1);
                                CandidateRobots(index3,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                CandidateRobotsPath(IndexLocation2,:) = [];
                                index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                            end

                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index4 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber4 = CandidateRobots(index4,1);
                                CandidateRobots(index4,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                CandidateRobotsPath(IndexLocation3,:) = [];
                                index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                            end
                            
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index5 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber5 = CandidateRobots(index5,1);
                            else % CandidateRobots����Ԫ��
                                IndexLocation4 = find(CandidateRobotsPath(:,1) == obj.RobotNumber4);
                                CandidateRobotsPath(IndexLocation4,:) = [];
                                index5 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber5 = CandidateRobotsPath(index5,1);
                            end
                            
                            DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                            DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                            DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                            DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                            DelayRLocation(5,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                            DelayRLocation = grid2world(obj.Map,DelayRLocation);
        %                    tempFailureR = DelayRLocation;
                            obj.g.XData = DelayRLocation(:,1);
                            obj.g.YData = DelayRLocation(:,2);                     

                            obj.delay = 1;
                            obj.CurrentT = i;

                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.RobotNumber5)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2);
                            
                        elseif obj.delayNum == 6 %�ӳ�����Ϊ6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            index1 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                            obj.RobotNumber1 = CandidateRobots(index1,1);
                            CandidateRobots(index1,:) = [];
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index2 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobots(index2,1);
                                CandidateRobots(index2,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation = find(CandidateRobotsPath(:,1) == obj.RobotNumber1);
                                CandidateRobotsPath(IndexLocation,:) = [];
                                index2 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber2 = CandidateRobotsPath(index2,1);
                            end
                            
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index3 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobots(index3,1);
                                CandidateRobots(index3,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation2 = find(CandidateRobotsPath(:,1) == obj.RobotNumber2);
                                CandidateRobotsPath(IndexLocation2,:) = [];
                                index3 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber3 = CandidateRobotsPath(index3,1);
                            end

                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index4 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber4 = CandidateRobots(index4,1);
                                CandidateRobots(index4,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation3 = find(CandidateRobotsPath(:,1) == obj.RobotNumber3);
                                CandidateRobotsPath(IndexLocation3,:) = [];
                                index4 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber4 = CandidateRobotsPath(index4,1);
                            end
                            
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index5 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber5 = CandidateRobots(index5,1);
                                CandidateRobots(index5,:) = [];
                            else % CandidateRobots����Ԫ��
                                IndexLocation4 = find(CandidateRobotsPath(:,1) == obj.RobotNumber4);
                                CandidateRobotsPath(IndexLocation4,:) = [];
                                index5 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber5 = CandidateRobotsPath(index5,1);
                            end
                            
                            if size(CandidateRobots,1) > 0 % CandidateRobots����Ȼ������1��Ԫ��
                                index6 = round(rand(1,1)*(size(CandidateRobots,1)-1)) + 1;
                                obj.RobotNumber6 = CandidateRobots(index6,1);
                            else % CandidateRobots����Ԫ��
                                IndexLocation5 = find(CandidateRobotsPath(:,1) == obj.RobotNumber5);
                                CandidateRobotsPath(IndexLocation5,:) = [];
                                index6 = round(rand(1,1)*(size(CandidateRobotsPath,1)-1)) + 1;
                                obj.RobotNumber6 = CandidateRobotsPath(index6,1);
                            end
                            
                            
                            DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                            DelayRLocation(2,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                            DelayRLocation(3,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                            DelayRLocation(4,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                            DelayRLocation(5,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                            DelayRLocation(6,:) = obj.RobotArray(obj.RobotNumber6,1).getLocation();
                            DelayRLocation = grid2world(obj.Map,DelayRLocation);
        %                    tempFailureR = DelayRLocation;
                            obj.g.XData = DelayRLocation(:,1);
                            obj.g.YData = DelayRLocation(:,2);                     

                            obj.delay = 1;
                            obj.CurrentT = i;

                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if (j ~= obj.RobotNumber1) && (j ~= obj.RobotNumber2) && (j ~= obj.RobotNumber3) && (j ~= obj.RobotNumber4) && (j ~= obj.RobotNumber5) && (j ~= obj.RobotNumber6)
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2);
                            
                        end
 
                    else % CandidateRobots��Ԫ�ظ���Ϊ0
                        tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                        obj.g.XData = tempFailureR(:,1);
                        obj.g.YData = tempFailureR(:,2);
                        obj.m.XData = tempFailureR(:,1);
                        obj.m.YData = tempFailureR(:,2);                        
                        obj.h.XData = tempR(:,1);
                        obj.h.YData = tempR(:,2);                        
                    end
                else %��ǰdelay = 1
                    if i < (obj.CurrentT + 6) %��ǰʱ��<(������ʱʱ��+6)
                        DelayRLocation = [];
                        if obj.delayNum == 1 %�ӳ�����Ϊ1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if (obj.move1 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.g.XData = DelayRLocation(:,1);
                                obj.g.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) 
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                                obj.g.XData = tempFailureR(:,1);
                                obj.g.YData = tempFailureR(:,2);
                                obj.m.XData = tempFailureR(:,1);
                                obj.m.YData = tempFailureR(:,2);  
                            end                                                        
                        elseif obj.delayNum == 2 %�ӳ�����Ϊ2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end

                            if (obj.move1 == 0) || (obj.move2 == 0)
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.g.XData = DelayRLocation(:,1);
                                obj.g.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1))
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                                obj.g.XData = tempFailureR(:,1);
                                obj.g.YData = tempFailureR(:,2);
                                obj.m.XData = tempFailureR(:,1);
                                obj.m.YData = tempFailureR(:,2);  
                            end                            
                        elseif obj.delayNum == 3 %�ӳ�����Ϊ3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end

                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.g.XData = DelayRLocation(:,1);
                                obj.g.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1))
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                                obj.g.XData = tempFailureR(:,1);
                                obj.g.YData = tempFailureR(:,2);
                                obj.m.XData = tempFailureR(:,1);
                                obj.m.YData = tempFailureR(:,2);  
                            end
                        elseif obj.delayNum == 4 %�ӳ�����Ϊ4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end
                            
                            if obj.move4 == 0
                                if  (obj.LastTLocation(obj.RobotNumber4,1) == obj.NowLocation(obj.RobotNumber4,1)) && (obj.LastTLocation(obj.RobotNumber4,2) == obj.NowLocation(obj.RobotNumber4,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                else %����
                                    obj.move4 = 1;
                                end
                            end

                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) || (obj.move4 == 0)  
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.g.XData = DelayRLocation(:,1);
                                obj.g.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1)) && ((j ~= obj.RobotNumber4) || (obj.move4 == 1))
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1 && obj.move4 == 1
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                obj.move4 = 0;
                                tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                                obj.g.XData = tempFailureR(:,1);
                                obj.g.YData = tempFailureR(:,2);
                                obj.m.XData = tempFailureR(:,1);
                                obj.m.YData = tempFailureR(:,2);  
                            end
                        elseif obj.delayNum == 5 %�ӳ�����Ϊ5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end
                            
                            if obj.move4 == 0
                                if  (obj.LastTLocation(obj.RobotNumber4,1) == obj.NowLocation(obj.RobotNumber4,1)) && (obj.LastTLocation(obj.RobotNumber4,2) == obj.NowLocation(obj.RobotNumber4,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                else %����
                                    obj.move4 = 1;
                                end
                            end
                            
                            if obj.move5 == 0
                                if  (obj.LastTLocation(obj.RobotNumber5,1) == obj.NowLocation(obj.RobotNumber5,1)) && (obj.LastTLocation(obj.RobotNumber5,2) == obj.NowLocation(obj.RobotNumber5,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                else %����
                                    obj.move5 = 1;
                                end
                            end

                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) || (obj.move4 == 0) || (obj.move5 == 0) 
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.g.XData = DelayRLocation(:,1);
                                obj.g.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1)) && ((j ~= obj.RobotNumber4) || (obj.move4 == 1)) && ((j ~= obj.RobotNumber5) || (obj.move5 == 1))
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1 && obj.move4 == 1 && obj.move5 == 1
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                obj.move4 = 0;
                                obj.move5 = 0;
                                tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                                obj.g.XData = tempFailureR(:,1);
                                obj.g.YData = tempFailureR(:,2);
                                obj.m.XData = tempFailureR(:,1);
                                obj.m.YData = tempFailureR(:,2);  
                            end
                        elseif obj.delayNum == 6 %�ӳ�����Ϊ6 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            if obj.move1 == 0
                                if  (obj.LastTLocation(obj.RobotNumber1,1) == obj.NowLocation(obj.RobotNumber1,1)) && (obj.LastTLocation(obj.RobotNumber1,2) == obj.NowLocation(obj.RobotNumber1,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    DelayRLocation(1,:) = obj.RobotArray(obj.RobotNumber1,1).getLocation();
                                else %����
                                    obj.move1 = 1;
                                end
                            end

                            if obj.move2 == 0
                                if  (obj.LastTLocation(obj.RobotNumber2,1) == obj.NowLocation(obj.RobotNumber2,1)) && (obj.LastTLocation(obj.RobotNumber2,2) == obj.NowLocation(obj.RobotNumber2,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber2,1).getLocation();
                                else %����
                                    obj.move2 = 1;
                                end
                            end
                            
                            if obj.move3 == 0
                                if  (obj.LastTLocation(obj.RobotNumber3,1) == obj.NowLocation(obj.RobotNumber3,1)) && (obj.LastTLocation(obj.RobotNumber3,2) == obj.NowLocation(obj.RobotNumber3,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber3,1).getLocation();
                                else %����
                                    obj.move3 = 1;
                                end
                            end
                            
                            if obj.move4 == 0
                                if  (obj.LastTLocation(obj.RobotNumber4,1) == obj.NowLocation(obj.RobotNumber4,1)) && (obj.LastTLocation(obj.RobotNumber4,2) == obj.NowLocation(obj.RobotNumber4,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber4,1).getLocation();
                                else %����
                                    obj.move4 = 1;
                                end
                            end
                            
                            if obj.move5 == 0
                                if  (obj.LastTLocation(obj.RobotNumber5,1) == obj.NowLocation(obj.RobotNumber5,1)) && (obj.LastTLocation(obj.RobotNumber5,2) == obj.NowLocation(obj.RobotNumber5,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber5,1).getLocation();
                                else %����
                                    obj.move5 = 1;
                                end
                            end
                            
                            if obj.move6 == 0
                                if  (obj.LastTLocation(obj.RobotNumber6,1) == obj.NowLocation(obj.RobotNumber6,1)) && (obj.LastTLocation(obj.RobotNumber6,2) == obj.NowLocation(obj.RobotNumber6,2)) %�����˵�ǰλ������һ��ʱ�䲽����λ�����
                                    row = size(DelayRLocation,1);
                                    DelayRLocation(row+1,:) = obj.RobotArray(obj.RobotNumber6,1).getLocation();
                                else %����
                                    obj.move6 = 1;
                                end
                            end

                            if (obj.move1 == 0) || (obj.move2 == 0) || (obj.move3 == 0) || (obj.move4 == 0) || (obj.move5 == 0) || (obj.move6 == 0)
                                DelayRLocation = grid2world(obj.Map,DelayRLocation);
            %                    tempFailureR = DelayRLocation;
                                obj.g.XData = DelayRLocation(:,1);
                                obj.g.YData = DelayRLocation(:,2); 
                            end


                            allLocation = [];
                            for j = 1:obj.TotalRobotNumber
                                if ((j ~= obj.RobotNumber1) || (obj.move1 == 1)) && ((j ~= obj.RobotNumber2) || (obj.move2 == 1)) && ((j ~= obj.RobotNumber3) || (obj.move3 == 1)) && ((j ~= obj.RobotNumber4) || (obj.move4 == 1)) && ((j ~= obj.RobotNumber5) || (obj.move5 == 1)) && ((j ~= obj.RobotNumber6) || (obj.move6 == 1))
                                    row = size(allLocation,1);
                                    allLocation(row+1,:) = obj.RobotArray(j,1).getLocation();
                                end
                            end   
                            allLocation = grid2world(obj.Map,allLocation);
                            tempRobot = allLocation;
                            obj.h.XData = tempRobot(:,1);
                            obj.h.YData = tempRobot(:,2); 

                            if obj.move1 == 1 && obj.move2 == 1 && obj.move3 == 1 && obj.move4 == 1 && obj.move5 == 1  && obj.move6 == 1
                                obj.delay = 0;
                                obj.move1 = 0;
                                obj.move2 = 0;
                                obj.move3 = 0;
                                obj.move4 = 0;
                                obj.move5 = 0;
                                obj.move6 = 0;
                                tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                                obj.g.XData = tempFailureR(:,1);
                                obj.g.YData = tempFailureR(:,2);
                                obj.m.XData = tempFailureR(:,1);
                                obj.m.YData = tempFailureR(:,2);  
                            end
                        end
                            
                        
                    else %��ǰʱ��>=(������ʱʱ��+6)
                        obj.delay = 0;
                        if obj.delayNum == 1
                            obj.move1 = 0;
                        elseif obj.delayNum == 2
                            obj.move1 = 0;
                            obj.move2 = 0;
                        elseif obj.delayNum == 3
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                        elseif obj.delayNum == 4
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                            obj.move4 = 0;
                        elseif obj.delayNum == 5
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                            obj.move4 = 0;
                            obj.move5 = 0;
                        elseif obj.delayNum == 6
                            obj.move1 = 0;
                            obj.move2 = 0;
                            obj.move3 = 0;
                            obj.move4 = 0;
                            obj.move5 = 0;
                            obj.move6 = 0;
                        end

                        tempFailureR = grid2world(obj.Map,[1 1;1 1]);
                        obj.g.XData = tempFailureR(:,1);
                        obj.g.YData = tempFailureR(:,2);
                        obj.m.XData = tempFailureR(:,1);
                        obj.m.YData = tempFailureR(:,2);                        
                        obj.h.XData = tempR(:,1);
                        obj.h.YData = tempR(:,2); 
                    end
                end
    

                drawnow;                
                pause(obj.PlotInterval);
                i = i + 1;
                disp('���������');
                disp(obj.FinishedTaskNum);
            end    
            disp('���ʱ��');
            disp(i);
%         obj.AllWorkingRobot();
%         obj.RobottravelD();
%         obj.AllRobotTaskdistance();
        end
        
%****************************************д�����ݵ�Excel��***************************************
        
        function AllWorkingRobot(obj)
            filename = 'Allworkingrobot.xlsx';
            a = obj.Allworkingrobot;
            xlswrite(filename,a);
        end 
        
        function AllRobotTaskdistance(obj)
            filename = 'AllRobotTaskdistance.xlsx';
            a = obj.AllRobotTaskD;
            xlswrite(filename,a);
        end         
        
        function WorkerworkTime(obj)  
            filename = 'WorkerworkTime.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = 0.25*obj.WorkerArray(i,1).WorkTime;
            end
            xlswrite(filename,a);
        end
        
        function WorkerfreeTime(obj)   
            filename = 'WorkerfreeTime.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = 0.25*obj.WorkerArray(i,1).PatrolTime;
            end
            xlswrite(filename,a);            
        end
        
        function WorkerpatrolD(obj)    
            filename = 'WorkerpatrolD.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = obj.WorkerArray(i,1).getOdom2();
            end
            xlswrite(filename,a);            
        end
                
        function WorkerworkD(obj) 
            filename = 'WorkerworkD.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = obj.WorkerArray(i,1).getOdom1();
            end
            xlswrite(filename,a);            
        end
        
        function RobottravelTime(obj) 
            filename = 'RobottravelTime.xlsx';
            a = zeros(obj.TotalRobotNumber,1);
            for i = 1:obj.TotalRobotNumber
                a(i,1) = 0.25*obj.RobotArray(i,1).TravelTime;
            end
            xlswrite(filename,a);             
        end

        function RobotwaitTime(obj) 
            filename = 'RobotwaitTime.xlsx';
            a = zeros(obj.TotalRobotNumber,1);
            for i = 1:obj.TotalRobotNumber
                a(i,1) = 0.25*obj.RobotArray(i,1).WaitTime;
            end
            xlswrite(filename,a);            
        end
        
        function RobottravelD(obj) 
            filename = 'RobottravelD.xlsx';
            a = zeros(obj.TotalRobotNumber,1);
            for i = 1:obj.TotalRobotNumber
                a(i,1) = obj.RobotArray(i,1).getOdom();
            end
            xlswrite(filename,a);            
        end
        
        function WorkerfindRobots(obj) 
            filename = 'WorkerfindRobots.xlsx';
            a = zeros(obj.TotalWorkerNumber,1);
            for i = 1:obj.TotalWorkerNumber
                a(i,1) = obj.WorkerArray(i,1).FindRobots;
            end
            xlswrite(filename,a);            
        end       
        
        function RobotStatus(obj)
            filename = 'RobotStatus';
            a = zeros(obj.TotalRobotNumber,3);
            for i = 1:obj.TotalRobotNumber
                s1 = obj.RobotArray(i,1).Status1;
                s2 = obj.RobotArray(i,1).Status2;
                s3 = obj.RobotArray(i,1).Status3;
                a(i,1) = s1/(s1+s2+s3);
                a(i,2) = s2/(s1+s2+s3);
                a(i,3) = s3/(s1+s2+s3);
            end
            xlswrite(filename,a);  
        end
        
        function WorkerStatus(obj)
            filename = 'WorkerStatus';
            a = zeros(obj.TotalWorkerNumber,3);
            for i = 1:obj.TotalWorkerNumber
                s0 = obj.WorkerArray(i,1).Status0;
                s1 = obj.WorkerArray(i,1).Status1;
                s2 = obj.WorkerArray(i,1).Status2;
                a(i,1) = s0/(s0+s1+s2);
                a(i,2) = s1/(s0+s1+s2);
                a(i,3) = s2/(s0+s1+s2);
            end
            xlswrite(filename,a);  
        end
        
        function EveryTimeWorkerStatus(obj)
            filename = 'EveryTimeWorkerStatus';
            a = obj.StatusList;
            xlswrite(filename,a);
        end
        
%***********************************************************************************************
        
 
        function getAllWorkerOdom1(obj)
%             for i = 1:obj.TotalWorkerNumber
%                 obj.AllWorkerOdom1 = obj.AllWorkerOdom1 + obj.WorkerArray(i,1).getOdom1();
%             end
        end
        
        function getAllWorkerOdom2(obj)
%             for i = 1:obj.TotalWorkerNumber
%                 obj.AllWorkerOdom2 = obj.AllWorkerOdom2 + obj.WorkerArray(i,1).getOdom2();
%             end
        end
        
        function getAllRobotOdom(obj)
%             for i = 1:obj.TotalRobotNumber
%                 obj.AllRobotOdom = obj.AllRobotOdom + obj.RobotArray(i,1).getOdom();
%             end
        end
        
        function close(obj)
            obj.SystemOn = false;
        end
        
    end %end of methods
    
end %end of classdef


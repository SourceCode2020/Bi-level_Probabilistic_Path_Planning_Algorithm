% clc;
% clear;
a = Warehouse;
a.plotAll();

